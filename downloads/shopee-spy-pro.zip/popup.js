document.addEventListener('DOMContentLoaded', () => {
  const statusText = document.getElementById('status-text');
  const statusDesc = document.getElementById('status-plan-desc');
  const headerBadge = document.getElementById('header-badge');
  const hwidDisplay = document.getElementById('hwid-display');
  const copyHwidBtn = document.getElementById('copy-hwid-btn');
  const permissionsList = document.getElementById('permissions-list');
  const activateBtn = document.getElementById('activate-btn');
  const keyInput = document.getElementById('license-key-input');
  const msgEl = document.getElementById('activation-msg');
  const activationSection = document.getElementById('activation-section');
  const quotaCard = document.getElementById('quota-card');
  const quotaDisplay = document.getElementById('quota-display');
  const quotaBar = document.getElementById('quota-bar');
  const quotaFooter = document.getElementById('quota-footer');

  // Hardware Fingerprint Generator
  function getHardwareFingerprint() {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      let renderer = 'standard_gpu';
      if (gl) {
        const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
        if (debugInfo) {
          renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || 'generic_gpu';
        }
      }
      const raw = [
        renderer,
        screen.width + 'x' + screen.height,
        screen.colorDepth,
        navigator.hardwareConcurrency || 4,
        Intl.DateTimeFormat().resolvedOptions().timeZone
      ].join('###');

      let hash = 0;
      for (let i = 0; i < raw.length; i++) {
        hash = ((hash << 5) - hash) + raw.charCodeAt(i);
        hash |= 0;
      }
      return 'HWID_' + Math.abs(hash).toString(16).toUpperCase();
    } catch (e) {
      return 'HWID_SHOPEE_CORE';
    }
  }

  const currentHwid = getHardwareFingerprint();
  if (hwidDisplay) hwidDisplay.textContent = currentHwid;

  if (copyHwidBtn) {
    copyHwidBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(currentHwid).then(() => {
        copyHwidBtn.textContent = 'Copiado!';
        setTimeout(() => { copyHwidBtn.textContent = 'Copiar'; }, 2000);
      });
    });
  }

  // Load storage state
  chrome.storage.local.get(['melispy_is_pro', 'shopeespy_is_pro', 'melispy_hwid', 'melispy_license_key', 'melispy_plan', 'melispy_analyzed_items'], (res) => {
    try {
      let isPro = res.shopeespy_is_pro === true || res.melispy_is_pro === true;
      const storedKey = (res.melispy_license_key || '').toUpperCase();
      const effectiveHwid = res.melispy_hwid || currentHwid;
      if (hwidDisplay) hwidDisplay.textContent = effectiveHwid;

      let plan = 'vitalicio';
      if (storedKey.includes('STARTER')) plan = 'starter';
      else if (storedKey.includes('SCALE')) plan = 'scale';
      else if (storedKey.includes('VIP') || storedKey.includes('FOUNDER') || storedKey.includes('MATEUS') || storedKey.includes('SHOPEE') || storedKey.includes('PRO')) plan = 'vitalicio';

      if (isPro) {
        if (headerBadge) {
          headerBadge.textContent = '👑 VITALÍCIO';
          headerBadge.style.background = '#ee4d2d';
          headerBadge.style.color = '#fff';
        }
        if (statusText) {
          statusText.textContent = '👑 VITALÍCIO Founder Ativo';
          statusText.style.color = '#4ade80';
        }
        if (statusDesc) {
          statusDesc.textContent = `Chave: ${storedKey || 'SHOPEE-VITALICIO-FOUNDER'} • Análises Ilimitadas`;
        }

        if (quotaCard && quotaDisplay && quotaBar && quotaFooter) {
          quotaCard.style.display = 'block';
          quotaDisplay.textContent = 'Ilimitado (∞)';
          quotaDisplay.style.color = '#facc15';
          quotaBar.style.width = '100%';
          quotaBar.style.background = 'linear-gradient(90deg, #ff7043, #ee4d2d)';
          quotaFooter.textContent = 'Modo Fundador • Consultas e downloads de vídeos sem limites';
        }

        if (permissionsList) {
          permissionsList.innerHTML = `
            <li class="active" style="color: #4ade80;">✓ Vendas Reais dos Últimos 30 Dias (API Deep Scan)</li>
            <li class="active" style="color: #4ade80;">✓ Central UGC: Download de Vídeos de Avaliações em 4K</li>
            <li class="active" style="color: #4ade80;">✓ Calculadora Dupla (Modo Afiliado + Modo Dropshipper)</li>
            <li class="active" style="color: #4ade80;">✓ Sensor de Fornecedor Nacional & Estoque Real</li>
            <li class="active" style="color: #4ade80;">✓ Extrator de Palavras-Chave de Busca (SEO Shopee)</li>
            <li class="active" style="color: #4ade80;">✓ Atualizações Vitalícias e Ilimitadas Inclusas</li>
          `;
        }

        if (activationSection) {
          activationSection.innerHTML = `
            <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid #10b981; border-radius: 8px; padding: 10px; text-align: center;">
              <span style="font-size: 11px; color: #34d399; font-weight: 800;">🔑 Licença Ativa: <code>${storedKey || 'SHOPEE-FOUNDER-VITALICIO'}</code></span>
            </div>
          `;
        }
      } else {
        if (headerBadge) {
          headerBadge.textContent = 'BLOQUEADO';
          headerBadge.style.background = '#f87171';
        }
        if (statusText) {
          statusText.textContent = '🔒 Aguardando Ativação';
          statusText.style.color = '#f87171';
        }
        if (statusDesc) {
          statusDesc.textContent = 'Insira sua chave de licença oficial abaixo';
        }
      }
    } catch (err) {
      console.error('[ShopeeSpy Popup Error]', err);
    }
  });

  // Activate Handler
  if (activateBtn) {
    activateBtn.addEventListener('click', () => {
      const key = (keyInput.value || '').trim().toUpperCase();
      if (key && key.length >= 3) {
        let plan = 'vitalicio';
        if (key.includes('STARTER')) plan = 'starter';
        else if (key.includes('SCALE')) plan = 'scale';

        chrome.storage.local.set({
          shopeespy_is_pro: true,
          melispy_is_pro: true,
          melispy_hwid: currentHwid,
          melispy_license_key: key,
          melispy_plan: plan
        }, () => {
          if (msgEl) {
            msgEl.textContent = `✅ Licença Vitalícia Ativada com Sucesso!`;
            msgEl.style.color = '#4ade80';
          }
          setTimeout(() => location.reload(), 500);
        });
      } else {
        if (msgEl) {
          msgEl.textContent = '❌ Digite um código válido para ativar.';
          msgEl.style.color = '#f87171';
        }
      }
    });
  }
});
