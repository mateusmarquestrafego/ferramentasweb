/**
 * ShopeeSpy Pro - Background Service Worker
 * Gerencia downloads nativos de mídias e vídeos
 */

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'download' && message.url) {
    try {
      chrome.downloads.download({
        url: message.url,
        filename: message.filename || 'shopee_media.jpg',
        conflictAction: 'uniquify',
        saveAs: false
      }, (downloadId) => {
        if (chrome.runtime.lastError) {
          sendResponse({ success: false, error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ success: true, downloadId });
        }
      });
    } catch (e) {
      sendResponse({ success: false, error: e.message });
    }
    return true; // Mantém a porta assíncrona aberta
  }
});
