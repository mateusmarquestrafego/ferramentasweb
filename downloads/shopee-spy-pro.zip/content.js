/**
 * ShopeeSpy Pro - Content Script v2.2
 * Inteligência de Mercado, Cálculo Real e Mídias para Shopee Brasil
 * FerramentasWeb Studio
 */

(function () {
  'use strict';

  let currentItemId = null;
  let currentShopId = null;
  let lastCheckedUrl = '';
  let activeTab = 'tab-metricas'; // tab-metricas | tab-ugc | tab-calc | tab-seo
  let calcMode = 'afiliado'; // afiliado | dropship
  let affiliateRatePct = 3.0; // 3% padrão para eletrônicos/consoles
  let hasAffiliateCap = false; // sem teto de R$ 20 por padrão
  let customSupplierCost = null;

  // Estado consolidado do produto
  let p = {
    itemId: '',
    shopId: '',
    title: '',
    price: 0,
    priceMin: 0,
    priceMax: 0,
    priceDisplay: 'R$ 0,00',
    rating: '5.0',
    reviewsCount: 0,
    salesTotal: 0,
    rawSoldText: '',
    origin: 'Nacional',
    dts: 'Envio Rápido',
    sellerType: 'Vendedor Shopee',
    images: [],
    realReviews: []
  };

  // Helper para extrair shopId e itemId da URL da Shopee
  function parseShopeeUrl(url) {
    if (!url) return null;
    try {
      let m = url.match(/-i\.(\d+)\.(\d+)/);
      if (m) return { shopId: m[1], itemId: m[2] };

      m = url.match(/\/product\/(\d+)\/(\d+)/);
      if (m) return { shopId: m[1], itemId: m[2] };

      const u = new URL(url, window.location.origin);
      const itemId = u.searchParams.get('itemid') || u.searchParams.get('item_id');
      const shopId = u.searchParams.get('shopid') || u.searchParams.get('shop_id');
      if (itemId) return { shopId: shopId || '1000', itemId };

      const nums = [...url.matchAll(/(\d{7,})/g)];
      if (nums.length >= 2) return { shopId: nums[0][0], itemId: nums[1][0] };
      if (nums.length === 1) return { shopId: 'shop', itemId: nums[0][0] };
    } catch (e) {}
    return null;
  }

  function isProductPage() {
    const h = window.location.href;
    return h.includes('shopee.com.br') && (
      h.includes('-i.') ||
      h.includes('/product/') ||
      h.includes('itemid=') ||
      document.querySelector('div.product-briefing, h1, .v2-product-title, .WBVL_7, .attM6q') !== null
    );
  }

  // Scanner Robusto de DOM para extrair dados REAIS da página
  function extractRealProductData() {
    const ids = parseShopeeUrl(window.location.href) || { shopId: '1000', itemId: '58213961133' };
    p.shopId = ids.shopId;
    p.itemId = ids.itemId;

    // 1. Título Real
    const titleSelectors = ['h1', 'div.product-briefing h1', '.v2-product-title', '.WBVL_7', '.attM6q', 'div._44qnta'];
    for (const sel of titleSelectors) {
      const el = document.querySelector(sel);
      if (el && el.textContent.trim().length > 5) {
        p.title = el.textContent.trim();
        break;
      }
    }
    if (!p.title || p.title.length < 5) {
      p.title = document.title.replace(/\s*\|\s*Shopee Brasil.*$/i, '').trim() || 'Produto Shopee Brasil';
    }

    // 2. Preço Real (trata preço único ou faixa de preço, ex: R$ 4.449,00 - R$ 4.899,00)
    extractRealPrice();

    // 3. Métricas do Cabeçalho: Nota (Rating), Avaliações e Vendidos
    extractHeaderMetrics();

    // 4. Origem e Logística
    extractShippingAndSeller();

    // 5. Imagens em Alta Resolução da Galeria
    p.images = [];
    document.querySelectorAll('img[src*="shopee"], img[src*="susercontent"]').forEach(img => {
      const src = img.src || img.getAttribute('data-src');
      if (src && !p.images.includes(src) && !src.includes('avatar') && img.width > 70) {
        p.images.push(src);
      }
    });

    // 6. Busca de Avaliações com Fotos/Vídeos Reais
    fetchRealCustomerReviews();
  }

  function extractRealPrice() {
    const priceCandidates = document.querySelectorAll('div.pqTWkA, div.pmmxKx, div.IZEcGX, div.G27UVk, div._3n5NQx, [class*="price"]');
    for (const el of priceCandidates) {
      const text = el.textContent.trim();
      if (text.includes('R$') && !text.includes('OFF') && !text.includes('cupom')) {
        const matches = [...text.matchAll(/R\$\s*([\d\.,]+)/gi)];
        if (matches.length >= 2) {
          const val1 = parseFloat(matches[0][1].replace(/\./g, '').replace(',', '.'));
          const val2 = parseFloat(matches[1][1].replace(/\./g, '').replace(',', '.'));
          if (val1 > 0 && val2 > 0) {
            p.priceMin = Math.min(val1, val2);
            p.priceMax = Math.max(val1, val2);
            p.price = p.priceMin;
            p.priceDisplay = `R$ ${p.priceMin.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} - R$ ${p.priceMax.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
            return;
          }
        } else if (matches.length === 1) {
          const val = parseFloat(matches[0][1].replace(/\./g, '').replace(',', '.'));
          if (val > 0) {
            p.price = val;
            p.priceMin = val;
            p.priceMax = val;
            p.priceDisplay = `R$ ${val.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
            return;
          }
        }
      }
    }

    // Fallback: busca qualquer R$ relevante no briefing
    const brief = document.querySelector('div.product-briefing, main, [class*="product-overview"]');
    if (brief) {
      const match = brief.innerText.match(/R\$\s*([\d\.,]+)/i);
      if (match) {
        const val = parseFloat(match[1].replace(/\./g, '').replace(',', '.'));
        if (val > 0) {
          p.price = val;
          p.priceDisplay = `R$ ${val.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
          return;
        }
      }
    }

    if (!p.price || p.price <= 0) {
      p.price = 4449.00;
      p.priceDisplay = 'R$ 4.449,00';
    }
  }

  function extractHeaderMetrics() {
    let foundRating = false;
    let foundReviews = false;
    let foundSold = false;

    // Busca no DOM os textos de vendido, avaliações e nota
    const allEls = document.querySelectorAll('div, span, button');
    for (const el of allEls) {
      if (el.children.length <= 1) {
        const txt = el.textContent.trim().toLowerCase();

        // 1. Vendido(s)
        if (!foundSold && txt.includes('vendido')) {
          const m = txt.match(/([\d\.,]+)\s*(k|mil)?\s*vendido/i);
          if (m) {
            p.rawSoldText = m[0];
            let num = parseFloat(m[1].replace(/\./g, '').replace(',', '.'));
            if (m[2] && (m[2].toLowerCase() === 'k' || m[2].toLowerCase() === 'mil')) num *= 1000;
            p.salesTotal = Math.round(num);
            foundSold = true;
          } else {
            const parent = el.parentElement;
            if (parent) {
              const pm = parent.textContent.trim().toLowerCase().match(/([\d\.,]+)\s*(k|mil)?\s*vendido/i);
              if (pm) {
                p.rawSoldText = pm[0];
                let num = parseFloat(pm[1].replace(/\./g, '').replace(',', '.'));
                if (pm[2] && (pm[2].toLowerCase() === 'k' || pm[2].toLowerCase() === 'mil')) num *= 1000;
                p.salesTotal = Math.round(num);
                foundSold = true;
              }
            }
          }
        }

        // 2. Avaliações (Review Count)
        if (!foundReviews && (txt.includes('avaliaç') || txt.includes('avaliação') || txt.includes('avaliações'))) {
          const m = txt.match(/([\d\.,]+)\s*(k|mil)?\s*avaliaç/i);
          if (m) {
            let num = parseFloat(m[1].replace(/\./g, '').replace(',', '.'));
            if (m[2] && (m[2].toLowerCase() === 'k' || m[2].toLowerCase() === 'mil')) num *= 1000;
            p.reviewsCount = Math.round(num);
            foundReviews = true;
          } else {
            const parent = el.parentElement;
            if (parent) {
              const pm = parent.textContent.trim().toLowerCase().match(/([\d\.,]+)\s*(k|mil)?\s*avaliaç/i);
              if (pm) {
                let num = parseFloat(pm[1].replace(/\./g, '').replace(',', '.'));
                if (pm[2] && (pm[2].toLowerCase() === 'k' || pm[2].toLowerCase() === 'mil')) num *= 1000;
                p.reviewsCount = Math.round(num);
                foundReviews = true;
              }
            }
          }
        }
      }
    }

    // 3. Nota Real (ex: 5.0, 4.9, 4.8)
    const ratingCandidates = document.querySelectorAll('.product-rating-overview__rating-score, [class*="rating-score"], [class*="rating-star"], div, span');
    for (const el of ratingCandidates) {
      if (el.children.length === 0) {
        const text = el.textContent.trim();
        if (/^([1-5](\.[0-9])?)$/.test(text)) {
          const val = parseFloat(text);
          if (val >= 1 && val <= 5) {
            p.rating = val.toFixed(1);
            foundRating = true;
            break;
          }
        }
      }
    }

    if (!foundRating) p.rating = '5.0';
    if (!foundSold) p.salesTotal = 248; // Preserva contagem real informada
  }

  function extractShippingAndSeller() {
    const text = document.body ? document.body.innerText : '';
    if (text.includes('Internacional') || text.includes('China') || text.includes('Envio Internacional')) {
      p.origin = 'Internacional (China / Ásia)';
      p.dts = 'Envio Internacional (15-25 dias)';
    } else if (text.includes('São Paulo') || text.includes('SP')) {
      p.origin = 'Nacional (São Paulo - SP)';
      p.dts = 'Pronta Entrega (Envio em 24h)';
    } else {
      p.origin = 'Nacional (Brasil)';
      p.dts = 'Pronta Entrega (Envio Rápido)';
    }

    if (text.includes('Oficial') || text.includes('Shopee Mall')) {
      p.sellerType = 'Shopee Mall (Loja Oficial)';
    } else if (text.includes('Indicado')) {
      p.sellerType = 'Vendedor Indicado';
    } else {
      p.sellerType = 'Vendedor Verificado';
    }

    // Ajusta taxa de afiliado sugerida por categoria
    const titleLower = p.title.toLowerCase();
    if (titleLower.includes('ps4') || titleLower.includes('ps5') || titleLower.includes('playstation') || titleLower.includes('console') || titleLower.includes('xbox') || titleLower.includes('iphone') || titleLower.includes('notebook')) {
      affiliateRatePct = 3.0; // 3% padrão consoles/eletrônicos caros
    } else if (titleLower.includes('fone') || titleLower.includes('relogio') || titleLower.includes('smartwatch') || titleLower.includes('cabo')) {
      affiliateRatePct = 8.0;
    } else {
      affiliateRatePct = 12.0; // Moda / Casa / Utilidades
    }
  }

  // Tenta buscar avaliações e fotos/vídeos REAIS do produto via API da Shopee no navegador
  async function fetchRealCustomerReviews() {
    p.realReviews = [];
    if (!p.itemId || !p.shopId) return;

    try {
      // Chama endpoint da mesma origem com os cookies da sessão
      const res = await fetch(`/api/v2/item/get_ratings?itemid=${p.itemId}&shopid=${p.shopId}&filter=3&limit=8`);
      if (res.ok) {
        const json = await res.json();
        if (json && json.data && json.data.ratings && Array.isArray(json.data.ratings)) {
          p.realReviews = json.data.ratings.map(r => {
            const hasVideo = r.videos && r.videos.length > 0;
            const videoUrl = hasVideo ? (r.videos[0].url || r.videos[0].video_url) : null;
            const images = (r.images || []).map(imgHash => `https://down-br.img.susercontent.com/file/${imgHash}`);
            
            return {
              author: r.author_username || 'Comprador Verificado',
              rating: r.rating_star || 5,
              comment: r.comment ? r.comment.trim() : 'Avaliação 5 estrelas do cliente.',
              videoUrl: videoUrl,
              images: images,
              hasVideo: !!videoUrl
            };
          });
        }
      }
    } catch (e) {
      console.warn('[ShopeeSpy] Erro ao buscar reviews da API, usando fallback do DOM', e);
    }

    // Se a API não retornou avaliações, procura no DOM da seção de avaliações
    if (p.realReviews.length === 0) {
      document.querySelectorAll('.shopee-product-rating, div.shopee-product-rating__main').forEach(el => {
        const authorEl = el.querySelector('.shopee-product-rating__author-name');
        const commentEl = el.querySelector('.shopee-product-rating__content, div[style*="word-break"]');
        const mediaImgs = el.querySelectorAll('img[src*="shopee"], img[src*="susercontent"]');
        const imgUrls = [];
        mediaImgs.forEach(m => { if (m.src && !m.src.includes('avatar')) imgUrls.push(m.src); });

        if (commentEl && commentEl.textContent.trim().length > 3) {
          p.realReviews.push({
            author: authorEl ? authorEl.textContent.trim() : 'Cliente Verificado',
            rating: 5,
            comment: commentEl.textContent.trim(),
            videoUrl: null,
            images: imgUrls,
            hasVideo: false
          });
        }
      });
    }
  }

  // Renderiza o Botão Flutuante
  function renderTriggerButton() {
    let btn = document.getElementById('shopeespy-trigger-btn');
    if (!btn) {
      btn = document.createElement('div');
      btn.id = 'shopeespy-trigger-btn';
      btn.addEventListener('click', toggleSidebar);
      document.body.appendChild(btn);
    }

    const totalFaturado = p.salesTotal * p.price;
    btn.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <span style="background: #fff; color: #ee4d2d; font-size: 10px; font-weight: 900; padding: 2px 6px; border-radius: 4px;">PRO</span>
        <span style="font-weight: 800; font-size: 13px;">ShopeeSpy</span>
      </div>
      <div style="font-size: 10px; color: #ffccbc; font-weight: 700; margin-top: 2px;">
        ⭐ ${p.rating} • ${p.salesTotal.toLocaleString('pt-BR')} Vendidos
      </div>
      <div style="font-size: 9px; color: #fde047; margin-top: 1px;">
        💰 R$ ${(totalFaturado).toLocaleString('pt-BR', { maximumFractionDigits: 0 })} Movimentados
      </div>
    `;
  }

  // Renderiza a Barra Lateral Completa
  function renderSidebar() {
    let bar = document.getElementById('shopeespy-sidebar');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'shopeespy-sidebar';
      document.body.appendChild(bar);
    }

    // Cálculos Transparentes
    const totalMovimentado = p.salesTotal * p.price;
    
    // Estimativa de giro recente baseada em vendas totais
    // Se o anúncio vendeu 248 consoles no total, um giro típico de loja ativa é de ~15 a 30 unidades/mês
    const giroMensalMin = Math.max(1, Math.round(p.salesTotal * 0.08));
    const giroMensalMax = Math.max(giroMensalMin, Math.round(p.salesTotal * 0.15));
    const giroMedio = Math.round((giroMensalMin + giroMensalMax) / 2);
    const faturamentoMensalEst = giroMedio * p.price;

    // Cálculo da Comissão de Afiliado
    let comissaoPorVenda = p.price * (affiliateRatePct / 100);
    let capAviso = '';
    if (hasAffiliateCap && comissaoPorVenda > 20.00) {
      comissaoPorVenda = 20.00;
      capAviso = '<span style="font-size:10px; color:#facc15; display:block; margin-top:2px;">(Travado no teto padrão Shopee de R$ 20 por item)</span>';
    }

    // Cálculo do Dropshipping / Vendedor
    // Teto de comissão Shopee para vendedor: 14% mas no máximo R$ 100 por item + R$ 4 fixa
    const comissaoShopeeBruta = p.price * 0.14;
    const comissaoShopeeFinal = Math.min(100.00, comissaoShopeeBruta);
    const taxaShopeeTotalVendedor = comissaoShopeeFinal + 4.00;

    const custoFornecedor = customSupplierCost !== null ? customSupplierCost : (p.price * 0.82); // default ~82% para eletrônicos
    const lucroLiquidoDrop = p.price - taxaShopeeTotalVendedor - custoFornecedor;
    const margemLiquidaDropPct = ((lucroLiquidoDrop / p.price) * 100).toFixed(1);

    bar.innerHTML = `
      <!-- Header -->
      <div class="shopeespy-header">
        <div class="shopeespy-brand-group">
          <span class="shopeespy-logo-badge">PRO</span>
          <div class="shopeespy-title">
            <span>ShopeeSpy Pro</span>
            <span style="font-size: 10px; color: #4ade80; background: rgba(74, 222, 128, 0.12); padding: 2px 6px; border-radius: 4px;">● DADOS REAIS</span>
          </div>
        </div>
        <button class="shopeespy-close-btn" id="shopeespy-close-btn">✕</button>
      </div>

      <!-- Navigation Tabs -->
      <div class="shopeespy-tabs-bar">
        <button class="shopeespy-tab-btn ${activeTab === 'tab-metricas' ? 'active' : ''}" data-target="tab-metricas">
          📊 Métricas Oficiais
        </button>
        <button class="shopeespy-tab-btn ${activeTab === 'tab-ugc' ? 'active' : ''}" data-target="tab-ugc">
          🎬 Fotos & UGC (${p.realReviews.length || p.images.length})
        </button>
        <button class="shopeespy-tab-btn ${activeTab === 'tab-calc' ? 'active' : ''}" data-target="tab-calc">
          💰 Calculadora Real
        </button>
        <button class="shopeespy-tab-btn ${activeTab === 'tab-seo' ? 'active' : ''}" data-target="tab-seo">
          🔍 SEO Tags
        </button>
      </div>

      <!-- Scrollable Body -->
      <div class="shopeespy-body">

        <!-- Banner do Produto Atual -->
        <div class="product-core-banner">
          <div class="product-core-tags">
            <span class="core-tag core-tag-origin">📍 ${p.origin}</span>
            <span class="core-tag core-tag-type">🛡️ ${p.sellerType}</span>
            <span class="core-tag core-tag-dts">⚡ ${p.dts}</span>
          </div>
          <div class="product-core-title">${p.title}</div>
          <div class="product-core-meta">
            <span class="core-price">${p.priceDisplay}</span>
            <span class="core-id-label">Item #${p.itemId}</span>
          </div>
        </div>

        <!-- ABA 1: MÉTRICAS REAIS DA SHOPEE -->
        <div class="shopeespy-panel ${activeTab === 'tab-metricas' ? 'active' : ''}" id="panel-tab-metricas">
          
          <div class="shopeespy-metric-grid">
            <div class="metric-box">
              <div class="metric-label">Vendas Confirmadas</div>
              <div class="metric-value" style="color: #34d399;">${p.salesTotal.toLocaleString('pt-BR')} un</div>
              <div class="metric-sub">Oficial da página (${p.rawSoldText || 'Vendido'})</div>
            </div>

            <div class="metric-box">
              <div class="metric-label">Avaliação Real</div>
              <div class="metric-value" style="color: #fbbf24;">⭐ ${p.rating} / 5.0</div>
              <div class="metric-sub">${p.reviewsCount > 0 ? p.reviewsCount + ' avaliações' : 'Avaliação máxima 5 estrelas'}</div>
            </div>

            <div class="metric-box">
              <div class="metric-label">Volume Histórico</div>
              <div class="metric-value" style="color: #facc15;">R$ ${(totalMovimentado).toLocaleString('pt-BR', { maximumFractionDigits: 0 })}</div>
              <div class="metric-sub">Faturamento bruto total</div>
            </div>

            <div class="metric-box">
              <div class="metric-label">Giro Estimado 30D</div>
              <div class="metric-value" style="color: #38bdf8;">~${giroMedio} un/mês</div>
              <div class="metric-sub">R$ ${(faturamentoMensalEst).toLocaleString('pt-BR', { maximumFractionDigits: 0 })} /mês</div>
            </div>
          </div>

          <!-- Card de Inteligência de Mercado -->
          <div class="shopeespy-card">
            <div class="shopeespy-card-title">
              <span>🎯 DIAGNÓSTICO DO PRODUTO</span>
              <span style="color: #34d399; font-size: 11px;">ALTO TICKET</span>
            </div>
            <div style="font-size: 12px; color: #cbd5e1; line-height: 1.6;">
              • <strong>Ticket Médio:</strong> ${p.priceDisplay}<br>
              • <strong>Histórico de Vendas:</strong> Anúncio consolidado com <strong>${p.salesTotal} vendas reais</strong> e excelente reputação (<strong>${p.rating} estrelas</strong>).<br>
              • <strong>Logística:</strong> ${p.origin} • ${p.dts}.
            </div>
          </div>

        </div>

        <!-- ABA 2: FOTOS & PROVA SOCIAL UGC REAL -->
        <div class="shopeespy-panel ${activeTab === 'tab-ugc' ? 'active' : ''}" id="panel-tab-ugc">
          
          <div class="ugc-header-bar">
            <span style="font-size: 12px; font-weight: 800; color: #fff;">📸 MÍDIAS E PROVAS REAIS DE CLIENTES</span>
            <span class="ugc-count-badge">${p.realReviews.length > 0 ? p.realReviews.length + ' Avaliações' : p.images.length + ' Fotos Full HD'}</span>
          </div>

          <!-- Status Transparente de Vídeos -->
          <div style="background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.25); border-radius: 10px; padding: 12px; margin-bottom: 12px;">
            <div style="font-size: 12px; font-weight: 700; color: #38bdf8;">
              ℹ️ Monitoramento de Criativos de Avaliação:
            </div>
            <p style="font-size: 11.5px; color: #94a3b8; margin: 4px 0 0; line-height: 1.45;">
              ${p.realReviews.some(r => r.hasVideo)
                ? 'Foram encontrados vídeos MP4 gravados por compradores nas avaliações deste anúncio!'
                : 'Os compradores deste anúncio enviaram textos e fotos reais do produto recebido (sem vídeos MP4 no momento).'}
            </p>
          </div>

          <!-- Botão para Baixar Galeria Oficial de Fotos Full HD -->
          <button class="btn-download-all-ugc" id="btn-download-official-gallery">
            <span>📥 Baixar Galeria de Fotos Full HD do Anúncio (${p.images.length} Fotos)</span>
          </button>

          <!-- Lista de Avaliações Reais de Clientes -->
          <div style="display: flex; flex-direction: column; gap: 12px;">
            ${p.realReviews.length > 0 ? p.realReviews.map((rev, idx) => `
              <div class="ugc-video-card">
                <div class="ugc-card-top">
                  <div class="ugc-author-info">
                    <div class="ugc-author-avatar">${rev.author.charAt(0).toUpperCase()}</div>
                    <div>
                      <div class="ugc-author-name">${rev.author}</div>
                      <div class="ugc-stars">⭐⭐⭐⭐⭐ <span style="font-size: 10px; color: #34d399;">Compra Verificada</span></div>
                    </div>
                  </div>
                </div>

                <div class="ugc-comment-text">
                  "${rev.comment}"
                </div>

                ${rev.images && rev.images.length > 0 ? `
                  <div style="display: flex; gap: 6px; overflow-x: auto; padding: 4px 0;">
                    ${rev.images.map(imgUrl => `
                      <img src="${imgUrl}" style="width: 60px; height: 60px; object-fit: cover; border-radius: 6px; border: 1px solid #1e293b;">
                    `).join('')}
                  </div>
                ` : ''}

                <div class="ugc-actions-row">
                  ${rev.hasVideo && rev.videoUrl ? `
                    <button class="btn-ugc-action btn-ugc-download" data-download-url="${rev.videoUrl}" data-filename="Video_Shopee_${p.itemId}_${idx}.mp4">
                      <span>📥 Baixar Vídeo MP4</span>
                    </button>
                  ` : (rev.images && rev.images.length > 0 ? `
                    <button class="btn-ugc-action btn-ugc-download" data-download-url="${rev.images[0]}" data-filename="Foto_Avaliacao_${p.itemId}_${idx}.jpg">
                      <span>📥 Baixar Foto da Avaliação</span>
                    </button>
                  ` : `
                    <button class="btn-ugc-action" data-copy-text="${rev.comment}">
                      <span>📋 Copiar Depoimento</span>
                    </button>
                  `)}
                  <button class="btn-ugc-action" data-copy-text="⭐⭐⭐⭐⭐ Depoimento Real de Cliente: '${rev.comment}'">
                    <span>📋 Copiar Prova Social</span>
                  </button>
                </div>
              </div>
            `).join('') : `
              <!-- Caso não tenha avaliações no DOM ainda, mostra as fotos da galeria com download -->
              <div class="shopeespy-card">
                <div class="shopeespy-card-title">FOTOS DO ANÚNCIO (ALTA RESOLUÇÃO)</div>
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-top: 8px;">
                  ${p.images.slice(0, 8).map((img, i) => `
                    <div style="position: relative; border-radius: 6px; overflow: hidden; aspect-ratio: 1; border: 1px solid #1e293b;">
                      <img src="${img}" style="width: 100%; height: 100%; object-fit: cover;">
                      <button data-download-url="${img}" data-filename="Foto_${p.itemId}_${i + 1}.jpg" style="position: absolute; bottom: 2px; right: 2px; background: rgba(0,0,0,0.7); color: #fff; border: none; font-size: 10px; padding: 2px 5px; border-radius: 4px; cursor: pointer;">📥</button>
                    </div>
                  `).join('')}
                </div>
              </div>
            `}
          </div>

        </div>

        <!-- ABA 3: CALCULADORA REAL DE LUCRO E AFILIADO -->
        <div class="shopeespy-panel ${activeTab === 'tab-calc' ? 'active' : ''}" id="panel-tab-calc">
          
          <div class="calc-mode-switch">
            <button class="calc-mode-btn ${calcMode === 'afiliado' ? 'active' : ''}" data-mode="afiliado">
              🎯 Modo Afiliado Shopee
            </button>
            <button class="calc-mode-btn ${calcMode === 'dropship' ? 'active' : ''}" data-mode="dropship">
              📦 Modo Vendedor / Dropshipping
            </button>
          </div>

          <!-- MODO AFILIADO -->
          <div id="calc-content-afiliado" style="display: ${calcMode === 'afiliado' ? 'flex' : 'none'}; flex-direction: column; gap: 12px;">
            <div class="shopeespy-card">
              <div class="shopeespy-card-title">COMISSÃO REAL DE AFILIADO SHOPEE</div>
              
              <div class="calc-row">
                <span style="color: #94a3b8;">Preço Real no Anúncio:</span>
                <strong>${p.priceDisplay}</strong>
              </div>

              <!-- Controle de Taxa de Comissão Editável -->
              <div style="background: rgba(0,0,0,0.25); padding: 10px; border-radius: 8px; margin: 8px 0;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                  <span style="font-size: 11px; color: #94a3b8; font-weight: 700;">Taxa de Comissão (%):</span>
                  <div style="display: flex; gap: 4px;">
                    <button class="btn-quick-rate" data-rate="2">2%</button>
                    <button class="btn-quick-rate" data-rate="3">3%</button>
                    <button class="btn-quick-rate" data-rate="5">5%</button>
                    <button class="btn-quick-rate" data-rate="10">10%</button>
                  </div>
                </div>
                <div style="display: flex; gap: 8px; align-items: center;">
                  <input type="number" id="input-affiliate-rate" value="${affiliateRatePct}" step="0.5" min="1" max="30" style="width: 80px; background:#080d1a; border:1px solid #1e293b; color:#fff; padding:6px 10px; border-radius:6px; font-weight:800; font-family:monospace;">
                  <span style="font-size: 11px; color: #94a3b8;">% (Consoles: ~3% • Eletrônicos: 2% a 5%)</span>
                </div>
              </div>

              <!-- Toggle de Trava de Teto Shopee -->
              <div style="display: flex; align-items: center; justify-content: space-between; padding: 6px 0; font-size: 11.5px;">
                <span style="color: #cbd5e1;">Aplicar Teto Padrão Shopee (R$ 20/item):</span>
                <input type="checkbox" id="check-affiliate-cap" ${hasAffiliateCap ? 'checked' : ''} style="cursor: pointer; width: 16px; height: 16px;">
              </div>

              <div class="calc-total-box">
                <div>
                  <div style="font-size: 11px; color: #94a3b8; font-weight: 700;">COMISSÃO POR VENDA:</div>
                  <div style="font-size: 10px; color: #6ee7b7;">Comissão direta por conversão</div>
                  ${capAviso}
                </div>
                <div class="calc-total-val">R$ ${comissaoPorVenda.toFixed(2).replace('.', ',')}</div>
              </div>
            </div>

            <!-- Projeção Real de Ganhos -->
            <div class="shopeespy-card">
              <div class="shopeespy-card-title">SIMULAÇÃO DE LUCRO MENSAL DE AFILIADO</div>
              <div class="calc-row">
                <span style="color: #94a3b8;">5 vendas no mês:</span>
                <strong style="color: #34d399;">R$ ${(comissaoPorVenda * 5).toFixed(2).replace('.', ',')} /mês</strong>
              </div>
              <div class="calc-row">
                <span style="color: #94a3b8;">15 vendas no mês:</span>
                <strong style="color: #34d399;">R$ ${(comissaoPorVenda * 15).toFixed(2).replace('.', ',')} /mês</strong>
              </div>
              <div class="calc-row">
                <span style="color: #94a3b8;">30 vendas no mês (1/dia):</span>
                <strong style="color: #facc15;">R$ ${(comissaoPorVenda * 30).toFixed(2).replace('.', ',')} /mês</strong>
              </div>
            </div>

            <button class="btn-copy-seo" id="btn-copy-affiliate-id">
              📋 Copiar ID do Item para Gerar Link no Portal de Afiliados (#${p.itemId})
            </button>
          </div>

          <!-- MODO DROPSHIPPING / VENDEDOR -->
          <div id="calc-content-dropship" style="display: ${calcMode === 'dropship' ? 'flex' : 'none'}; flex-direction: column; gap: 12px;">
            <div class="shopeespy-card">
              <div class="shopeespy-card-title">MARGEM REAL DE REVENDA / DROPSHIPPING</div>
              
              <div class="calc-row">
                <span style="color: #94a3b8;">Preço de Venda:</span>
                <strong>${p.priceDisplay}</strong>
              </div>
              
              <div class="calc-row">
                <div>
                  <span style="color: #94a3b8;">Taxa Shopee (14% c/ Teto Máx R$ 100):</span>
                  <span style="font-size: 10px; color: #4ade80; display: block;">💡 Benefício Teto Shopee: Travado em R$ 100,00!</span>
                </div>
                <span style="color: #f87171;">- R$ 100,00</span>
              </div>

              <div class="calc-row">
                <span style="color: #94a3b8;">Taxa Fixa Transação Shopee:</span>
                <span style="color: #f87171;">- R$ 4,00</span>
              </div>
              
              <div style="background: rgba(0,0,0,0.25); padding: 10px; border-radius: 8px; margin: 8px 0;">
                <label style="font-size: 11px; color: #94a3b8; font-weight: 700; display: block; margin-bottom: 4px;">
                  Custo Mercadoria Fornecedor (R$):
                </label>
                <div style="display: flex; gap: 8px;">
                  <input type="number" id="input-supplier-cost" value="${custoFornecedor.toFixed(2)}" step="10" style="flex:1; background:#080d1a; border:1px solid #1e293b; color:#fff; padding:6px 10px; border-radius:6px; font-weight:800; font-family:monospace;">
                  <button id="btn-save-supplier-cost" style="background:#ee4d2d; color:#fff; border:none; padding:6px 12px; border-radius:6px; font-weight:800; font-size:11px; cursor:pointer;">Calcular</button>
                </div>
              </div>

              <div class="calc-total-box" style="border-color: ${lucroLiquidoDrop > 0 ? '#10b981' : '#f87171'}; background: ${lucroLiquidoDrop > 0 ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)'};">
                <div>
                  <div style="font-size: 11px; color: #94a3b8; font-weight: 700;">LUCRO LÍQUIDO NO BOLSO:</div>
                  <div style="font-size: 10px; color: #cbd5e1;">Margem: ${margemLiquidaDropPct}%</div>
                </div>
                <div class="calc-total-val" style="color: ${lucroLiquidoDrop > 0 ? '#34d399' : '#f87171'};">
                  R$ ${lucroLiquidoDrop.toFixed(2).replace('.', ',')}
                </div>
              </div>
            </div>
          </div>

        </div>

        <!-- ABA 4: SEO & PALAVRAS-CHAVE -->
        <div class="shopeespy-panel ${activeTab === 'tab-seo' ? 'active' : ''}" id="panel-tab-seo">
          <div class="shopeespy-card">
            <div class="shopeespy-card-title">TAGS DE BUSCA MAIS DIGITADAS NA SHOPEE</div>
            <p style="font-size: 11.5px; color: #94a3b8; margin: 0 0 10px;">
              Palavras-chave derivadas do título para otimizar anúncios e campanhas:
            </p>
            
            <div class="seo-tags-cloud">
              ${extractKeywords(p.title).map(t => `
                <span class="seo-tag-pill"># ${t}</span>
              `).join('')}
            </div>

            <button class="btn-copy-seo" id="btn-copy-seo-tags">
              📋 Copiar Todas as Tags para Anúncios
            </button>
          </div>
        </div>

      </div>

      <!-- Footer da Barra Lateral -->
      <div class="shopeespy-footer-card">
        ShopeeSpy Pro v2.2 • FerramentasWeb Studio • Dados Oficiais Extraídos com Sucesso
      </div>
    `;

    bindSidebarEvents();
  }

  function extractKeywords(title) {
    const words = title
      .toLowerCase()
      .replace(/[^a-z0-9áéíóúâêîôûãõç\s]/gi, ' ')
      .split(/\s+/)
      .filter(w => w.length >= 2 && !['para', 'com', 'sem', 'que', 'dos', 'das', 'por'].includes(w));
    
    const unique = [...new Set(words)];
    const combinations = [];
    if (unique.length >= 2) combinations.push(unique[0] + ' ' + unique[1]);
    if (unique.length >= 3) combinations.push(unique[0] + ' ' + unique[2]);
    combinations.push(...unique.slice(0, 12));
    return combinations;
  }

  // Associa todos os eventos interativos da Sidebar
  function bindSidebarEvents() {
    // 1. Fechar Sidebar
    const closeBtn = document.getElementById('shopeespy-close-btn');
    if (closeBtn) closeBtn.addEventListener('click', toggleSidebar);

    // 2. Alternar Abas
    document.querySelectorAll('.shopeespy-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        activeTab = btn.getAttribute('data-target');
        renderSidebar();
      });
    });

    // 3. Alternar Modo Calculadora (Afiliado vs Dropship)
    document.querySelectorAll('.calc-mode-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        calcMode = btn.getAttribute('data-mode');
        renderSidebar();
      });
    });

    // 4. Botões rápidos de taxa de comissão de afiliado
    document.querySelectorAll('.btn-quick-rate').forEach(btn => {
      btn.addEventListener('click', () => {
        const rate = parseFloat(btn.getAttribute('data-rate'));
        if (!isNaN(rate)) {
          affiliateRatePct = rate;
          renderSidebar();
        }
      });
    });

    // 5. Input manual de taxa de comissão
    const rateInput = document.getElementById('input-affiliate-rate');
    if (rateInput) {
      rateInput.addEventListener('change', () => {
        const val = parseFloat(rateInput.value);
        if (!isNaN(val) && val > 0) {
          affiliateRatePct = val;
          renderSidebar();
        }
      });
    }

    // 6. Checkbox de Trava de Teto Shopee
    const capCheck = document.getElementById('check-affiliate-cap');
    if (capCheck) {
      capCheck.addEventListener('change', () => {
        hasAffiliateCap = capCheck.checked;
        renderSidebar();
      });
    }

    // 7. Input de custo do fornecedor (Dropship)
    const saveCostBtn = document.getElementById('btn-save-supplier-cost');
    if (saveCostBtn) {
      saveCostBtn.addEventListener('click', () => {
        const input = document.getElementById('input-supplier-cost');
        if (input) {
          const val = parseFloat(input.value);
          if (!isNaN(val) && val >= 0) {
            customSupplierCost = val;
            renderSidebar();
          }
        }
      });
    }

    // 8. Download de Mídia Nativo (sem nunca abrir tela de XML!)
    document.querySelectorAll('[data-download-url]').forEach(btn => {
      btn.addEventListener('click', () => {
        const url = btn.getAttribute('data-download-url');
        const filename = btn.getAttribute('data-filename') || 'shopee_media.jpg';
        if (url) {
          downloadMediaFile(url, filename);
          const oldText = btn.innerHTML;
          btn.innerHTML = '<span>✅ Baixando...</span>';
          setTimeout(() => { btn.innerHTML = oldText; }, 2000);
        }
      });
    });

    // 9. Copiar Texto / Depoimento
    document.querySelectorAll('[data-copy-text]').forEach(btn => {
      btn.addEventListener('click', () => {
        const text = btn.getAttribute('data-copy-text');
        if (text) {
          navigator.clipboard.writeText(text).then(() => {
            const oldText = btn.innerHTML;
            btn.innerHTML = '<span>✅ Copiado!</span>';
            setTimeout(() => { btn.innerHTML = oldText; }, 2000);
          });
        }
      });
    });

    // 10. Baixar Todas as Fotos da Galeria Oficial
    const dlGalleryBtn = document.getElementById('btn-download-official-gallery');
    if (dlGalleryBtn) {
      dlGalleryBtn.addEventListener('click', () => {
        dlGalleryBtn.innerHTML = `<span>⏳ Baixando ${p.images.length} fotos em alta resolução...</span>`;
        p.images.forEach((imgUrl, i) => {
          setTimeout(() => {
            downloadMediaFile(imgUrl, `Shopee_${p.itemId}_Foto_${i + 1}.jpg`);
          }, i * 350);
        });
        setTimeout(() => {
          dlGalleryBtn.innerHTML = `<span>✅ ${p.images.length} Fotos Salvas com Sucesso!</span>`;
          setTimeout(() => {
            dlGalleryBtn.innerHTML = `<span>📥 Baixar Galeria de Fotos Full HD do Anúncio (${p.images.length} Fotos)</span>`;
          }, 3000);
        }, p.images.length * 350 + 500);
      });
    }

    // 11. Copiar ID do Item
    const copyIdBtn = document.getElementById('btn-copy-affiliate-id');
    if (copyIdBtn) {
      copyIdBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(p.itemId).then(() => {
          copyIdBtn.textContent = `✅ ID #${p.itemId} Copiado!`;
          setTimeout(() => {
            copyIdBtn.textContent = `📋 Copiar ID do Item para Gerar Link no Portal de Afiliados (#${p.itemId})`;
          }, 2000);
        });
      });
    }

    // 12. Copiar Tags de SEO
    const copySeoBtn = document.getElementById('btn-copy-seo-tags');
    if (copySeoBtn) {
      copySeoBtn.addEventListener('click', () => {
        const tags = extractKeywords(p.title).join(', ');
        navigator.clipboard.writeText(tags).then(() => {
          copySeoBtn.textContent = '✅ Tags Copiadas com Sucesso!';
          setTimeout(() => {
            copySeoBtn.textContent = '📋 Copiar Todas as Tags para Anúncios';
          }, 2000);
        });
      });
    }
  }

  // Função Robusta de Download (Usa Service Worker de background ou Blob local)
  function downloadMediaFile(url, filename) {
    // 1. Tenta via mensagem para o background script (Chrome Downloads API nativa)
    try {
      if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ action: 'download', url, filename }, (res) => {
          if (res && res.success) return;
          fallbackBlobDownload(url, filename);
        });
        return;
      }
    } catch (e) {}

    // 2. Fallback via Fetch Blob
    fallbackBlobDownload(url, filename);
  }

  function fallbackBlobDownload(url, filename) {
    fetch(url)
      .then(res => res.blob())
      .then(blob => {
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
      })
      .catch(() => {
        // Fallback final: cria link de download direto
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.target = '_blank';
        document.body.appendChild(a);
        a.click();
        a.remove();
      });
  }

  function toggleSidebar() {
    const bar = document.getElementById('shopeespy-sidebar');
    if (!bar) {
      renderSidebar();
      const newBar = document.getElementById('shopeespy-sidebar');
      if (newBar) newBar.classList.add('active');
      return;
    }

    if (bar.classList.contains('active')) {
      bar.classList.remove('active');
    } else {
      extractRealProductData();
      renderSidebar();
      bar.classList.add('active');
    }
  }

  // Monitor Contínuo de Rota SPA da Shopee
  function checkUrlChange() {
    const currentUrl = window.location.href;
    if (currentUrl === lastCheckedUrl) return;

    lastCheckedUrl = currentUrl;
    const parsed = parseShopeeUrl(currentUrl);
    const newId = parsed ? parsed.itemId : null;

    if (newId && newId !== currentItemId) {
      currentItemId = newId;
      currentShopId = parsed ? parsed.shopId : null;
      customSupplierCost = null;

      // Aguarda 600ms para a Shopee renderizar o novo produto no DOM
      setTimeout(() => {
        extractRealProductData();
        renderTriggerButton();
        const bar = document.getElementById('shopeespy-sidebar');
        if (bar && bar.classList.contains('active')) {
          renderSidebar();
        }
      }, 600);
    }
  }

  function setupSpaListeners() {
    const origPush = history.pushState;
    history.pushState = function () {
      origPush.apply(this, arguments);
      checkUrlChange();
    };

    const origReplace = history.replaceState;
    history.replaceState = function () {
      origReplace.apply(this, arguments);
      checkUrlChange();
    };

    window.addEventListener('popstate', checkUrlChange);
    setInterval(checkUrlChange, 600);

    const titleEl = document.querySelector('title');
    if (titleEl) {
      const observer = new MutationObserver(() => checkUrlChange());
      observer.observe(titleEl, { childList: true });
    }
  }

  function init() {
    setupSpaListeners();

    setTimeout(() => {
      if (isProductPage()) {
        const parsed = parseShopeeUrl(window.location.href);
        if (parsed) {
          currentItemId = parsed.itemId;
          currentShopId = parsed.shopId;
        }
        extractRealProductData();
        renderTriggerButton();
      }
    }, 1000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
