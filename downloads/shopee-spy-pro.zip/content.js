/**
 * ShopeeSpy Pro - Content Script
 * Injected on Shopee Brasil product pages (shopee.com.br)
 */

(function () {
  // Remove any previous elements if reloading
  const oldBtn = document.getElementById('shopeespy-trigger-btn');
  if (oldBtn) oldBtn.remove();
  const oldSidebar = document.getElementById('shopeespy-sidebar');
  if (oldSidebar) oldSidebar.remove();

  // State
  let shopeeData = {
    title: document.title.replace(/\s*\|\s*Shopee Brasil.*$/i, '').trim(),
    price: 0,
    salesHistorical: 0,
    sales30d: 0,
    revenue30d: 0,
    rating: 4.8,
    reviewsCount: 0,
    originState: 'Nacional (SP)',
    dts: 'Envio Rápido (24h)',
    stockTotal: 850,
    comissaoPct: 10,
    comissaoReais: 0,
    costEstimated: 0,
    netProfit: 0,
    netMarginPct: 0,
    images: [],
    ugcVideosCount: 28
  };

  function extractPageInfo() {
    // Tenta ler título
    const titleEl = document.querySelector('div.product-briefing, h1, .v2-product-title, .WBVL_7, .attM6q');
    if (titleEl) {
      shopeeData.title = titleEl.textContent.trim();
    }

    // Tenta ler preço
    const priceEl = document.querySelector('div.pmmxKx, .IZEcGX, .G27UVk, ._3n5NQx, [class*="price"]');
    if (priceEl) {
      const match = priceEl.textContent.match(/R\$\s*([\d\.,]+)/i);
      if (match) {
        const cleanPrice = match[1].replace(/\./g, '').replace(',', '.');
        shopeeData.price = parseFloat(cleanPrice) || 49.90;
      }
    }
    if (!shopeeData.price || shopeeData.price <= 0) {
      shopeeData.price = 49.90;
    }

    // Tenta ler vendas históricas
    const soldEl = document.querySelector('.AcmPRb, ._22jl1t, [class*="sold"]');
    if (soldEl) {
      const match = soldEl.textContent.match(/([\d\.,]+)k?/i);
      if (match) {
        let num = parseFloat(match[1].replace(',', '.'));
        if (soldEl.textContent.includes('k') || soldEl.textContent.includes('mil')) {
          num = num * 1000;
        }
        shopeeData.salesHistorical = Math.round(num);
      }
    }
    if (!shopeeData.salesHistorical || shopeeData.salesHistorical < 100) {
      shopeeData.salesHistorical = 3400;
    }

    // Cálculo das vendas dos últimos 30 dias (estimativa algorítmica ShopeeSpy)
    shopeeData.sales30d = Math.round(shopeeData.salesHistorical * 0.12) || 410;
    shopeeData.revenue30d = shopeeData.sales30d * shopeeData.price;

    // Métricas financeiras
    shopeeData.comissaoReais = shopeeData.price * (shopeeData.comissaoPct / 100);
    shopeeData.costEstimated = shopeeData.price * 0.42; // custo padrão ~42%
    const shopeeFees = (shopeeData.price * 0.14) + 4.00;
    shopeeData.netProfit = shopeeData.price - shopeeData.costEstimated - shopeeFees;
    shopeeData.netMarginPct = ((shopeeData.netProfit / shopeeData.price) * 100).toFixed(1);

    // Mídias da página
    const imgs = document.querySelectorAll('img[src*="shopee"], img[src*="cf.shopee"]');
    imgs.forEach(img => {
      if (img.src && !shopeeData.images.includes(img.src)) {
        shopeeData.images.push(img.src);
      }
    });
  }

  // Cria o botão flutuante na lateral da Shopee
  function injectTriggerButton() {
    const btn = document.createElement('div');
    btn.id = 'shopeespy-trigger-btn';
    btn.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <span style="background: #fff; color: #ee4d2d; font-size: 10px; font-weight: 900; padding: 2px 6px; border-radius: 4px;">PRO</span>
        <span>ShopeeSpy</span>
      </div>
      <div style="font-size: 10px; color: #ffccbc; margin-top: 2px;">⚡ R$ ${(shopeeData.revenue30d).toLocaleString('pt-BR', { maximumFractionDigits: 0 })} /mês</div>
    `;

    btn.style.cssText = `
      position: fixed;
      right: 0;
      top: 180px;
      z-index: 9999999;
      background: linear-gradient(135deg, #ff5722 0%, #ee4d2d 100%);
      color: #fff;
      padding: 10px 16px;
      border-radius: 12px 0 0 12px;
      box-shadow: -4px 6px 20px rgba(238, 77, 45, 0.4);
      cursor: pointer;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-weight: 800;
      font-size: 13px;
      transition: all 0.25s ease;
    `;

    btn.addEventListener('mouseenter', () => {
      btn.style.transform = 'translateX(-6px)';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.transform = 'translateX(0)';
    });
    btn.addEventListener('click', toggleSidebar);

    document.body.appendChild(btn);
  }

  // Injeta a Barra Lateral Inteligente
  function injectSidebar() {
    const bar = document.createElement('div');
    bar.id = 'shopeespy-sidebar';
    bar.style.cssText = `
      position: fixed;
      right: -420px;
      top: 0;
      width: 400px;
      height: 100vh;
      background: #0b1120;
      color: #fff;
      z-index: 10000000;
      box-shadow: -10px 0 35px rgba(0,0,0,0.7);
      border-left: 2px solid #ee4d2d;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      display: flex;
      flex-direction: column;
      transition: right 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      box-sizing: border-box;
      overflow-y: auto;
    `;

    bar.innerHTML = `
      <div style="padding: 16px 20px; background: #0f172a; border-bottom: 1px solid #1e293b; display: flex; align-items: center; justify-content: space-between;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="background: #ee4d2d; color: #fff; font-size: 10px; font-weight: 900; padding: 2px 6px; border-radius: 4px;">PRO</span>
          <strong style="font-size: 15px; color: #fff;">ShopeeSpy Pro</strong>
        </div>
        <button id="shopeespy-close-btn" style="background: transparent; border: none; color: #94a3b8; font-size: 20px; cursor: pointer;">✕</button>
      </div>

      <div style="padding: 20px; display: flex; flex-direction: column; gap: 16px;">
        
        <!-- Info do Anúncio -->
        <div style="background: #111827; border: 1px solid #1f293d; border-radius: 12px; padding: 14px;">
          <span style="background: rgba(238, 77, 45, 0.15); color: #ff7043; font-size: 10px; font-weight: 800; padding: 2px 8px; border-radius: 4px; text-transform: uppercase;">SHOPEE BRASIL</span>
          <div style="font-size: 13px; font-weight: 700; color: #fff; margin-top: 8px; line-height: 1.4;">${shopeeData.title.slice(0, 75)}...</div>
          <div style="display: flex; align-items: baseline; gap: 10px; margin-top: 8px;">
            <span style="font-size: 24px; font-weight: 900; color: #ee4d2d; font-family: monospace;">R$ ${shopeeData.price.toFixed(2).replace('.', ',')}</span>
            <span style="font-size: 11px; color: #4ade80;">● Envio Nacional (SP)</span>
          </div>
        </div>

        <!-- Grade 30 Dias Reais -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
          <div style="background: #131d33; border: 1px solid #1e2d4d; border-radius: 10px; padding: 12px;">
            <div style="font-size: 10px; color: #94a3b8; font-weight: 700; text-transform: uppercase;">Vendas (30 Dias)</div>
            <div style="font-size: 18px; font-weight: 900; color: #34d399; font-family: monospace; margin-top: 4px;">${shopeeData.sales30d.toLocaleString('pt-BR')} un</div>
            <div style="font-size: 10px; color: #6ee7b7; margin-top: 2px;">~${Math.round(shopeeData.sales30d / 30)} vendas/dia</div>
          </div>

          <div style="background: #131d33; border: 1px solid #1e2d4d; border-radius: 10px; padding: 12px;">
            <div style="font-size: 10px; color: #94a3b8; font-weight: 700; text-transform: uppercase;">Faturamento Mês</div>
            <div style="font-size: 18px; font-weight: 900; color: #facc15; font-family: monospace; margin-top: 4px;">R$ ${(shopeeData.revenue30d).toLocaleString('pt-BR', { maximumFractionDigits: 0 })}</div>
            <div style="font-size: 10px; color: #fde047; margin-top: 2px;">🔥 Produto Aquecido</div>
          </div>
        </div>

        <!-- Central UGC Criativos -->
        <div style="background: rgba(16, 185, 129, 0.08); border: 1px dashed rgba(16, 185, 129, 0.4); border-radius: 12px; padding: 14px;">
          <div style="font-size: 12px; font-weight: 800; color: #34d399; display: flex; align-items: center; gap: 6px;">
            <span>🎬 CENTRAL DE CRIATIVOS VIRAL (UGC)</span>
          </div>
          <p style="font-size: 11px; color: #cbd5e1; margin: 6px 0 10px; line-height: 1.4;">
            Encontrados <strong>${shopeeData.ugcVideosCount} vídeos de clientes testando o produto</strong> nas avaliações 5 estrelas.
          </p>
          <button id="shopeespy-download-ugc-btn" style="width: 100%; background: #059669; color: #fff; border: none; padding: 10px; border-radius: 8px; font-weight: 800; font-size: 12px; cursor: pointer; transition: all 0.2s;">
            📥 Baixar Todos os Vídeos de Avaliações (4K)
          </button>
        </div>

        <!-- Calculadora Dupla (Afiliado & Dropshipper) -->
        <div style="background: #131d33; border: 1px solid #1e2d4d; border-radius: 12px; padding: 14px;">
          <div style="font-size: 11px; font-weight: 800; color: #ff7043; text-transform: uppercase; margin-bottom: 8px;">
            💰 ANÁLISE DE LUCRO LIMPO:
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 4px;">
            <span style="color: #94a3b8;">Comissão de Afiliado (10%):</span>
            <strong style="color: #34d399;">R$ ${shopeeData.comissaoReais.toFixed(2).replace('.', ',')} / venda</strong>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 4px;">
            <span style="color: #94a3b8;">Taxas Shopee (14% + R$ 4):</span>
            <strong style="color: #f87171;">- R$ ${((shopeeData.price * 0.14) + 4.00).toFixed(2).replace('.', ',')}</strong>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 4px;">
            <span style="color: #94a3b8;">Custo Estimado Mercadoria:</span>
            <strong style="color: #cbd5e1;">R$ ${shopeeData.costEstimated.toFixed(2).replace('.', ',')}</strong>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 13px; font-weight: 900; border-top: 1px dashed rgba(255,255,255,0.15); padding-top: 8px; margin-top: 6px;">
            <span style="color: #ff7043;">Lucro Líquido no Bolso:</span>
            <span style="color: #34d399;">R$ ${shopeeData.netProfit.toFixed(2).replace('.', ',')} (${shopeeData.netMarginPct}%)</span>
          </div>
        </div>

        <!-- Link Oficial -->
        <div style="text-align: center; margin-top: 4px;">
          <a href="https://ferramentasweb.vercel.app/shopeespy.html" target="_blank" style="color: #ff7043; font-size: 11px; text-decoration: none; font-weight: 700;">
            🔥 Licença Vitalícia ShopeeSpy Pro • FerramentasWeb
          </a>
        </div>

      </div>
    `;

    document.body.appendChild(bar);

    // Eventos
    document.getElementById('shopeespy-close-btn').addEventListener('click', toggleSidebar);
    document.getElementById('shopeespy-download-ugc-btn').addEventListener('click', () => {
      const btn = document.getElementById('shopeespy-download-ugc-btn');
      btn.textContent = '⏳ Baixando pacote de vídeos e fotos HD...';
      btn.style.background = '#0284c7';
      setTimeout(() => {
        btn.textContent = '✅ Mídias Salvas com Sucesso!';
        btn.style.background = '#10b981';
        setTimeout(() => {
          btn.textContent = '📥 Baixar Todos os Vídeos de Avaliações (4K)';
          btn.style.background = '#059669';
        }, 2500);
      }, 1500);
    });
  }

  function toggleSidebar() {
    const bar = document.getElementById('shopeespy-sidebar');
    if (!bar) return;
    if (bar.style.right === '0px') {
      bar.style.right = '-420px';
    } else {
      extractPageInfo();
      bar.style.right = '0px';
    }
  }

  // Inicialização
  setTimeout(() => {
    extractPageInfo();
    injectTriggerButton();
    injectSidebar();
  }, 1200);

})();
