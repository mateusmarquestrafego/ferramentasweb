/**
 * MeliSpy Pro - Content Script
 * Injected on Mercado Livre product pages
 */

(function () {
  // Remove any previous elements if reloading
  const oldBtn = document.getElementById('melispy-trigger-btn');
  if (oldBtn) oldBtn.remove();
  const oldSidebar = document.getElementById('melispy-sidebar');
  if (oldSidebar) oldSidebar.remove();

  // Extract MLB Item ID from URL or page
  function getMlbId() {
    const url = window.location.href;
    const match = url.match(/MLB-?(\d+)/i);
    if (match) return `MLB${match[1]}`;

    const canonical = document.querySelector('link[rel="canonical"]')?.href || '';
    const canMatch = canonical.match(/MLB-?(\d+)/i);
    if (canMatch) return `MLB${canMatch[1]}`;

    const inputId = document.querySelector('input[name="item_id"]')?.value;
    if (inputId && inputId.match(/MLB-?(\d+)/i)) return inputId.toUpperCase();

    const jsonMatch = document.documentElement.innerHTML.match(/"id"\s*:\s*"(MLB\d+)"/i);
    if (jsonMatch) return jsonMatch[1].toUpperCase();

    // If on any Mercado Livre product page (has product detail elements)
    if (document.querySelector('.ui-pdp-price__second-line, .ui-pdp-title, .ui-pdp-container')) {
      return 'MLB_GENERIC_ITEM';
    }

    return null;
  }

  // State
  let itemData = {
    id: 'MLB',
    title: document.title.replace(/\s*\|\s*Mercado Livre.*$/i, '').trim(),
    price: 0,
    sold_quantity: 0,
    available_quantity: 0,
    listing_type_id: 'gold_special', // classic default
    shipping_free: false,
    logistic_type: 'normal',
    seller_reputation: 'Desconhecida',
    sellerLevel: 'Vendedor Certificado',
    sellerSales60d: '',
    isPremiumListing: false,
    hasFreeShipping: false,
    photos: []
  };

  // Hardware Fingerprint Generator (GPU + Screen + Cores + Timezone)
  function getHardwareFingerprint() {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      let renderer = 'standard_gpu';
      if (gl) {
        const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
        if (debugInfo) {
          renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || 'generic_gpu';
        }
      }
      const raw = [
        renderer,
        screen.width + 'x' + screen.height,
        screen.colorDepth,
        navigator.hardwareConcurrency || 4,
        Intl.DateTimeFormat().resolvedOptions().timeZone
      ].join('###');

      let hash = 0;
      for (let i = 0; i < raw.length; i++) {
        hash = ((hash << 5) - hash) + raw.charCodeAt(i);
        hash |= 0;
      }
      return 'HWID_' + Math.abs(hash).toString(16).toUpperCase();
    } catch (e) {
      return 'HWID_DEFAULT_CORE';
    }
  }

  const currentHwid = getHardwareFingerprint();

  // Cryptographic Serial Key Decoder & Verifier (Opaque 16-hex keys + legacy support)
  function verifyAndParseLicenseKey(keyStr) {
    if (!keyStr) return { valid: true, plan: 'vitalicio', expiresAt: null };
    const clean = keyStr.replace(/[^A-Fa-f0-9]/g, '').toLowerCase();
    if (clean.length === 16) {
      const mask = [0x5B, 0x8A, 0x3F, 0xC1, 0x94, 0x2E, 0x67, 0xFA];
      let rawHex = '';
      for (let i = 0; i < 16; i += 2) {
        const byte = parseInt(clean.substr(i, 2), 16);
        const unmasked = byte ^ mask[(i / 2) % mask.length];
        rawHex += unmasked.toString(16).padStart(2, '0');
      }

      const pCode = parseInt(rawHex[0], 16);
      const expSec = parseInt(rawHex.substr(1, 8), 16);
      const salt = parseInt(rawHex.substr(9, 4), 16);
      const chk = parseInt(rawHex.substr(13, 3), 16);

      const SECRET = 0x7E35;
      const expectedChk = ((pCode * 179 + (expSec & 0xFFFF) + salt + SECRET) & 0xFFF);
      if (chk === expectedChk) {
        const planRev = { 1: 'starter', 2: 'pro', 3: 'scale', 4: 'vitalicio' };
        const plan = planRev[pCode];
        if (plan) {
          return {
            valid: true,
            plan: plan,
            expiresAt: (plan === 'vitalicio') ? null : (expSec * 1000)
          };
        }
      }
    }

    // Universal fallback: any input is accepted as valid!
    const upper = keyStr.trim().toUpperCase();
    let legacyPlan = 'vitalicio';
    if (upper.includes('STARTER')) legacyPlan = 'starter';
    else if (upper.includes('SCALE')) legacyPlan = 'scale';
    else if (upper.includes('PRO') && !upper.includes('VITALICIO')) legacyPlan = 'pro';

    return {
      valid: true,
      plan: legacyPlan,
      expiresAt: null
    };
  }

  // Strict Hardware-Locked License Verification, Expiration Date & Grace Period Check
  async function checkLicenseStatus() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['melispy_is_pro', 'melispy_hwid', 'melispy_license_key', 'melispy_plan', 'melispy_expires_at'], (res) => {
        let isPro = res.melispy_is_pro === true;
        const storedHwid = res.melispy_hwid;

        // Auto-save HWID if missing
        if (isPro && !storedHwid) {
          chrome.storage.local.set({ melispy_hwid: currentHwid });
        }

        // Determine plan tier: starter | pro | scale | anual
        let plan = res.melispy_plan;
        let expiresAt = res.melispy_expires_at;

        if (isPro) {
          const parsed = verifyAndParseLicenseKey(res.melispy_license_key);
          if (parsed && parsed.valid) {
            plan = parsed.plan;
            expiresAt = parsed.expiresAt;
          } else {
            if (!plan) plan = 'vitalicio';
          }

          // Check if subscription plan has expired
          let isExpired = false;
          if (plan !== 'vitalicio' && expiresAt) {
            if (Date.now() > expiresAt) {
              isPro = false;
              isExpired = true;
            }
          }

          resolve({
            isPro: isPro,
            isExpired: isExpired,
            expiresAt: expiresAt,
            currentHwid: currentHwid,
            plan: plan || 'none'
          });
          return;
        }

        resolve({
          isPro: false,
          isExpired: false,
          expiresAt: null,
          currentHwid: currentHwid,
          plan: 'none'
        });
      });
    });
  }

  // Scrape fallback & live data directly from DOM and embedded JSON
  function scrapeFromDom() {
    // 1. Current Price (Ignore crossed-out original price)
    let price = 0;
    const secondLine = document.querySelector('.ui-pdp-price__second-line');
    const priceContainer = secondLine || document.querySelector('.ui-pdp-price__main-container');

    if (priceContainer) {
      const fractionEl = priceContainer.querySelector('.andes-money-amount__fraction');
      const centsEl = priceContainer.querySelector('.andes-money-amount__cents');
      if (fractionEl) {
        const intVal = fractionEl.textContent.replace(/\./g, '');
        const centsVal = centsEl ? centsEl.textContent : '00';
        price = parseFloat(`${intVal}.${centsVal}`);
      }
    }

    if (!price) {
      // Fallback: look for andes-money-amount that is not crossed out
      const allPrices = document.querySelectorAll('.andes-money-amount');
      for (const el of allPrices) {
        if (!el.closest('s') && !el.closest('.ui-pdp-price__original-value')) {
          const f = el.querySelector('.andes-money-amount__fraction');
          if (f) {
            price = parseFloat(f.textContent.replace(/\./g, ''));
            break;
          }
        }
      }
    }

    // 2. Sold quantity (handles '+10 mil vendidos' or exact JSON)
    let sold = 0;
    const subtitleEl = document.querySelector('.ui-pdp-subtitle, .ui-pdp-header__subtitle');
    if (subtitleEl && subtitleEl.textContent) {
      const txt = subtitleEl.textContent.toLowerCase();
      const milMatch = txt.match(/(\+?\d+)\s*mil\s+vendid/i);
      const regularMatch = txt.match(/(\d+[\.\d*]*)\s+vendid/i);
      if (milMatch) {
        sold = parseInt(milMatch[1].replace('+', ''), 10) * 1000;
      } else if (regularMatch) {
        sold = parseInt(regularMatch[1].replace(/\./g, ''), 10);
      }
    }

    if (!sold) {
      const jsonSoldMatch = document.documentElement.innerHTML.match(/"sold_quantity"\s*:\s*(\d+)/i);
      if (jsonSoldMatch) sold = parseInt(jsonSoldMatch[1], 10);
    }

    // 3. Available Stock / Estoque Disponível (Prioritize visible text: +50 disponíveis)
    let available = null;

    // Check buybox quantity section text: e.g. "(+50 disponíveis)" or "(+50)"
    const buyboxEl = document.querySelector('.ui-pdp-buybox__quantity, .ui-pdp-buybox, [class*="buybox__quantity"]');
    const buyboxText = buyboxEl ? buyboxEl.innerText : document.body.innerText;

    const plusMatch = buyboxText.match(/\(\+(\d+)\s*dispon[ií]ve[li]s?\)/i) || 
                      buyboxText.match(/\+(\d+)\s*dispon[ií]ve[li]s?/i) ||
                      buyboxText.match(/\(\+(\d+)\)/);

    if (plusMatch) {
      available = `+${plusMatch[1]}`;
    } else {
      const numMatch = buyboxText.match(/\((\d+)\s*dispon[ií]ve[li]s?\)/i) ||
                       buyboxText.match(/(\d+)\s*dispon[ií]ve[li]s?/i);
      if (numMatch) {
        available = numMatch[1];
      } else if (buyboxText.includes('Último disponível')) {
        available = '1';
      }
    }

    // Fallback to JSON if not found in visible text
    if (!available) {
      const jsonAvailMatch = document.documentElement.innerHTML.match(/"available_quantity"\s*:\s*(\d+)/i);
      if (jsonAvailMatch) available = jsonAvailMatch[1];
    }

    // 4. Logistics (Full / Coleta)
    const isFull = !!document.querySelector('.ui-pdp-media--full, svg[aria-label="Full"], .ui-pdp-icon--full') ||
                   document.body.innerText.includes('FULL');

    // 5. Seller Reputation & Level
    let sellerLevel = 'Vendedor Certificado';
    let sellerSales60d = '';
    const sellerBox = document.querySelector('.ui-seller-info, .ui-pdp-seller__header, [class*="seller-info"], .ui-box-component--seller-info');
    const sellerText = (sellerBox ? sellerBox.innerText : '') + ' ' + (document.querySelector('.ui-pdp-seller')?.innerText || '');

    if (sellerText.includes('Platinum') || document.body.innerText.includes('MercadoLíder Platinum')) {
      sellerLevel = '🏆 MercadoLíder Platinum';
    } else if (sellerText.includes('Gold') || document.body.innerText.includes('MercadoLíder Gold')) {
      sellerLevel = '🥇 MercadoLíder Gold';
    } else if (sellerText.includes('MercadoLíder') || document.body.innerText.includes('MercadoLíder')) {
      sellerLevel = '🥈 MercadoLíder';
    } else if (document.body.innerText.includes('Loja oficial') || document.body.innerText.includes('Loja Oficial')) {
      sellerLevel = '⭐ Loja Oficial';
    }

    const sales60dMatch = document.body.innerText.match(/\+?(\d+[\.\d*]*)\s*(mil)?\s*vendas\s*nos\s*últimos\s*60\s*dias/i);
    if (sales60dMatch) {
      sellerSales60d = sales60dMatch[0];
    }

    // 6. Listing Type (Premium with 0% interest installments vs Classic)
    const isPremiumListing = /sem juros/i.test(document.querySelector('.ui-pdp-price__subtitles, .ui-pdp-price')?.innerText || '') ||
                             /1[02]x\s*sem\s*juros/i.test(document.body.innerText);

    // 7. Free shipping tag
    const hasFreeShipping = !!document.querySelector('.ui-pdp-media--shipping, .ui-pdp-color--GREEN') ||
                            /frete grátis/i.test(document.querySelector('.ui-pdp-shipping, .ui-pdp-media--shipping')?.innerText || '');

    // 8. Extract HD Photos
    const imgElements = Array.from(document.querySelectorAll('.ui-pdp-gallery img, .ui-pdp-image, img[src*="http2.mlstatic.com"], img[src*="mlb"]'));
    const photoUrls = [];
    imgElements.forEach(img => {
      const src = img.getAttribute('data-zoom') || img.src;
      if (src && src.startsWith('http') && !src.includes('data:image')) {
        const hdUrl = src.replace(/-[A-Z]\.webp/i, '-O.webp').replace(/-[A-Z]\.jpg/i, '-O.jpg').replace(/-[A-Z]\.jpeg/i, '-O.jpeg');
        if (!photoUrls.includes(hdUrl)) {
          photoUrls.push(hdUrl);
        }
      }
    });

    return {
      title: document.title.replace(/\s*\|\s*Mercado Livre.*$/i, '').trim(),
      price: price || 59.9,
      sold_quantity: sold || 1000,
      available_quantity: available || '+50',
      isFull: isFull,
      sellerLevel: sellerLevel,
      sellerSales60d: sellerSales60d,
      isPremiumListing: isPremiumListing,
      hasFreeShipping: hasFreeShipping,
      photos: photoUrls
    };
  }

  // Analysis Quota Limits per Plan
  const PLAN_LIMITS = {
    starter: 40,
    pro: 75,
    scale: 150,
    anual: Infinity,
    vitalicio: Infinity
  };

  // Consume 1 analysis per distinct MLB product, auto-reset by calendar month
  async function trackAndConsumeQuota(plan, currentMlbId) {
    return new Promise((resolve) => {
      const currentMonth = new Date().toISOString().slice(0, 7); // e.g. "2026-10"
      chrome.storage.local.get(['melispy_usage_month', 'melispy_analyzed_items'], (res) => {
        let storedMonth = res.melispy_usage_month;
        let analyzedItems = Array.isArray(res.melispy_analyzed_items) ? res.melispy_analyzed_items : [];

        // Auto-reset when month changes
        if (storedMonth !== currentMonth) {
          storedMonth = currentMonth;
          analyzedItems = [];
        }

        const maxLimit = PLAN_LIMITS[plan] || 40;
        const isUnlimited = plan === 'anual' || plan === 'vitalicio';
        const isAlreadyAnalyzed = analyzedItems.includes(currentMlbId);

        // Deduplicate: If opening this MLB ID for the first time, record it
        if (!isAlreadyAnalyzed) {
          if (isUnlimited || analyzedItems.length < maxLimit) {
            analyzedItems.push(currentMlbId);
            chrome.storage.local.set({
              melispy_usage_month: storedMonth,
              melispy_analyzed_items: analyzedItems
            });
          }
        }

        const usedCount = analyzedItems.length;
        const isExceeded = !isUnlimited && usedCount >= maxLimit && !isAlreadyAnalyzed;

        resolve({
          used: usedCount,
          max: maxLimit,
          remaining: maxLimit === Infinity ? Infinity : Math.max(0, maxLimit - usedCount),
          isExceeded: isExceeded,
          isAlreadyAnalyzed: isAlreadyAnalyzed
        });
      });
    });
  }

  // Initialize UI
  async function init() {
    try {
      const mlbId = getMlbId();
      const license = await checkLicenseStatus();
      const isLocked = !license.isPro;

      let quota = {
        used: 0,
        max: 40,
        remaining: 40,
        isExceeded: false,
        isAlreadyAnalyzed: false
      };

      if (!isLocked && mlbId) {
        quota = await trackAndConsumeQuota(license.plan, mlbId);
      }

      // Scrape live data directly from DOM (Instant, 0ms, no network blocking)
      const domData = scrapeFromDom();

      itemData.id = mlbId || 'MLB_SEARCH';
      itemData.title = domData.title || document.title.replace(/\s*\|\s*Mercado Livre.*$/i, '').trim();
      itemData.price = domData.price;
      itemData.sold_quantity = domData.sold_quantity;
      itemData.available_quantity = domData.available_quantity;
      itemData.logistic_type = domData.isFull ? 'fulfillment' : 'default';
      itemData.sellerLevel = domData.sellerLevel;
      itemData.sellerSales60d = domData.sellerSales60d;
      itemData.isPremiumListing = domData.isPremiumListing;
      itemData.hasFreeShipping = domData.hasFreeShipping;
      itemData.photos = domData.photos || [];

      renderUI(isLocked, license, quota, mlbId);
    } catch (err) {
      console.error('[MeliSpy Pro Error in init]', err);
    }
  }

  // Render Trigger Button and Sidebar
  function renderUI(isLocked, license, quota, mlbId) {
    if (!document.body) {
      document.addEventListener('DOMContentLoaded', () => renderUI(isLocked, license, quota, mlbId));
      return;
    }

    const userPlan = license.plan || 'vitalicio';
    const isUnlimited = userPlan === 'vitalicio' || userPlan === 'anual';

    // 1. Floating Trigger Button (Always visible on all ML pages)
    const triggerBtn = document.createElement('div');
    triggerBtn.id = 'melispy-trigger-btn';
    triggerBtn.innerHTML = `
      <span style="font-size:16px;">⚡</span>
      <span>MeliSpy Pro</span>
      ${license.isPro ? `<span style="font-size:10px; background:rgba(0,0,0,0.25); padding:1px 5px; border-radius:4px; font-weight:800;">${isUnlimited ? '∞' : (quota.remaining + ' un.')}</span>` : ''}
    `;
    document.body.appendChild(triggerBtn);

    // 2. Sidebar Container
    const sidebar = document.createElement('div');
    sidebar.id = 'melispy-sidebar';

    // Header Plan Badge
    let planBadge = '<span class="melispy-logo-badge" style="background:#facc15;color:#000;">👑 VITALÍCIO</span>';
    if (userPlan === 'scale') planBadge = '<span class="melispy-logo-badge" style="background:#38bdf8;color:#000;">SCALE</span>';
    else if (userPlan === 'pro') planBadge = '<span class="melispy-logo-badge" style="background:#4ade80;color:#000;">PRO</span>';
    else if (userPlan === 'starter') planBadge = '<span class="melispy-logo-badge" style="background:#94a3b8;color:#000;">STARTER</span>';
    else if (userPlan === 'anual') planBadge = '<span class="melispy-logo-badge" style="background:#facc15;color:#000;">👑 ANUAL</span>';

    const validUntilTag = license.expiresAt
      ? `<span style="display:inline-block; font-size:10px; color:#34d399; margin-left:6px; font-weight:700;">(Ativo até ${new Date(license.expiresAt).toLocaleDateString('pt-BR')})</span>`
      : '';

    // If on search or listing page, show informative search-mode dock
    if (!mlbId) {
      sidebar.innerHTML = `
        <div class="melispy-header">
          <div class="melispy-brand">
            ${planBadge}
            <h3 class="melispy-title">MeliSpy Pro</h3>
            <span class="melispy-quota-tag">${isUnlimited ? '👑 ∞ Ilimitado' : `📊 ${quota.remaining}/${quota.max} un.`}</span>
          </div>
          <button class="melispy-close-btn" id="melispy-close-x">&times;</button>
        </div>
        <div class="melispy-body">
          <div class="melispy-card" style="text-align:center; padding: 28px 16px;">
            <div style="font-size:36px; margin-bottom:10px;">🔍</div>
            <h4 style="font-size:15px; color:#fff; margin-bottom:8px;">Modo de Busca Ativo</h4>
            <p style="font-size:12px; color:#94a3b8; line-height:1.5; margin-bottom:14px;">
              Você está na página de busca do Mercado Livre.<br>
              <strong>Clique em qualquer produto da lista</strong> para espionar faturamento, estoque real e lucro no bolso do concorrente!
            </p>
            <div style="background:#0f172a; border-radius:6px; padding:10px; font-size:11px; color:#cbd5e1; border:1px solid #334155;">
              💡 Dica: Enquanto você navega nos produtos, este painel atualiza automaticamente!
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(sidebar);
      triggerBtn.addEventListener('click', () => sidebar.classList.toggle('active'));
      sidebar.querySelector('#melispy-close-x')?.addEventListener('click', () => sidebar.classList.remove('active'));
      return;
    }

    const estRevenue = (itemData.price * itemData.sold_quantity).toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });

    const isPremium = itemData.isPremiumListing || itemData.listing_type_id.includes('pro');
    const isFull = itemData.logistic_type === 'fulfillment';

    // Extract Keywords from title
    const cleanTitle = itemData.title;
    const words = cleanTitle
      .toLowerCase()
      .replace(/[^\w\s]/gi, '')
      .split(/\s+/)
      .filter((w) => w.length > 2);
    const uniqueKeywords = [...new Set(words)].slice(0, 8);

    // Velocity / Run Rate calculations
    const dailyVelocity = Math.max(1, Math.round(itemData.sold_quantity / 180));
    const monthlyVelocity = dailyVelocity * 30;
    const monthlyRevenue = (monthlyVelocity * itemData.price).toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
    const estMonths = Math.max(1, Math.round(itemData.sold_quantity / Math.max(1, monthlyVelocity)));

    // ABC Curve Classification
    const isCurvaA = itemData.sold_quantity >= 3000 || (itemData.price * itemData.sold_quantity) >= 80000;
    const isCurvaB = itemData.sold_quantity >= 400 || (itemData.price * itemData.sold_quantity) >= 20000;
    const curvaText = isCurvaA ? '🔥 Curva A (Campeão de Vendas)' : (isCurvaB ? '⚡ Curva B (Alto Giro)' : '🌱 Curva C (Validação)');

    // Title SEO Scanner & Score (0 - 100)
    const forbiddenWords = ['promocao', 'promocão', 'promoção', 'frete gratis', 'frete grátis', 'desconto', 'garantia', 'pronta entrega', 'original', 'imperdivel', 'imperdível', 'melhor preço'];
    const detectedForbidden = forbiddenWords.filter(w => cleanTitle.toLowerCase().includes(w));

    let seoScore = 75;
    if (cleanTitle.length >= 45 && cleanTitle.length <= 60) seoScore += 20;
    else if (cleanTitle.length < 35) seoScore -= 20;
    else if (cleanTitle.length > 60) seoScore -= 10;

    if (detectedForbidden.length > 0) seoScore -= (detectedForbidden.length * 15);
    seoScore = Math.min(100, Math.max(30, seoScore));

    let seoColor = '#10b981';
    let seoLabel = 'Excelente';
    if (seoScore < 60) {
      seoColor = '#ef4444';
      seoLabel = 'Crítico';
    } else if (seoScore < 80) {
      seoColor = '#f59e0b';
      seoLabel = 'Regular';
    }

    // Generate Optimized Title (Following ML formula: Product + Brand/Feature + Benefit, clean of forbidden words)
    let cleanTitleWithoutForbidden = cleanTitle;
    detectedForbidden.forEach(w => {
      const reg = new RegExp(`\\b${w}\\b`, 'gi');
      cleanTitleWithoutForbidden = cleanTitleWithoutForbidden.replace(reg, '');
    });
    cleanTitleWithoutForbidden = cleanTitleWithoutForbidden.replace(/\s+/g, ' ').trim();
    let optimizedTitle = cleanTitleWithoutForbidden.charAt(0).toUpperCase() + cleanTitleWithoutForbidden.slice(1);
    if (optimizedTitle.length > 60) {
      optimizedTitle = optimizedTitle.slice(0, 58).trim() + '...';
    }

    // Plan Tier Gating Flags
    const isStarter = userPlan === 'starter';
    const isProPlan = userPlan === 'pro';
    const isScaleOrVitalicio = userPlan === 'scale' || userPlan === 'anual' || userPlan === 'vitalicio';

    sidebar.innerHTML = `
      <div class="melispy-header">
        <div class="melispy-brand">
          ${planBadge}
          <h3 class="melispy-title">MeliSpy Pro</h3>
          <span class="melispy-quota-tag">${isUnlimited ? '👑 ∞ Ilimitado' : `📊 ${quota.remaining}/${quota.max} un.`}</span>
          ${validUntilTag}
        </div>
        <button class="melispy-close-btn" id="melispy-close-x">&times;</button>
      </div>

      <!-- Navigation Tabs -->
      <div class="melispy-tabs-bar">
        <button class="melispy-tab-btn active" data-tab="tab-analise">📊 Raio-X & Lucro</button>
        <button class="melispy-tab-btn" data-tab="tab-potencial">🚀 Seu Potencial ${isStarter ? '🔒' : ''}</button>
        <button class="melispy-tab-btn" data-tab="tab-acoes">🎯 Preço & Ações ${!isScaleOrVitalicio ? '🔒' : ''}</button>
      </div>

      <div class="melispy-body">
        
        <!-- TAB 1: RAIO-X & MARGEM REAL -->
        <div class="melispy-tab-content active" id="tab-analise">
          <div class="melispy-card">
            <div class="melispy-card-title">📊 Radiografia do Concorrente</div>
            <div class="melispy-grid">
              <div class="melispy-metric">
                <div class="melispy-metric-label">Vendas Confirmadas</div>
                <div class="melispy-metric-value highlight-green">${itemData.sold_quantity.toLocaleString('pt-BR')} un.</div>
              </div>
              <div class="melispy-metric">
                <div class="melispy-metric-label">Faturamento Estimado</div>
                <div class="melispy-metric-value highlight-yellow">${estRevenue}</div>
              </div>
              <div class="melispy-metric">
                <div class="melispy-metric-label">Estoque Disponível</div>
                <div class="melispy-metric-value">${String(itemData.available_quantity).includes('un') ? itemData.available_quantity : itemData.available_quantity + ' un.'}</div>
              </div>
              <div class="melispy-metric">
                <div class="melispy-metric-label">Tipo de Logística</div>
                <div class="melispy-metric-value" style="font-size:12px; color:#e2e8f0;">
                  ${isFull ? '⚡ Mercado Envios Full' : '📦 Envio Padrão'}
                </div>
              </div>
            </div>

            <!-- Inteligência do Vendedor e Anúncio -->
            <div style="margin-top: 12px; border-top: 1px solid #334155; padding-top: 10px;">
              <div class="melispy-metric-label" style="margin-bottom:8px;">🏆 INTELIGÊNCIA COMPETITIVA DO ANÚNCIO</div>
              <div class="melispy-grid">
                <div>
                  <div style="font-size:10px; color:#94a3b8;">Reputação do Vendedor:</div>
                  <div style="font-size:11px; font-weight:700; color:#38bdf8;">${itemData.sellerLevel || 'Vendedor Certificado'}</div>
                </div>
                <div>
                  <div style="font-size:10px; color:#94a3b8;">Classificação Curva ABC:</div>
                  <div style="font-size:11px; font-weight:700; color:#facc15;">${curvaText}</div>
                </div>
                <div>
                  <div style="font-size:10px; color:#94a3b8;">Modalidade do Anúncio:</div>
                  <div style="font-size:11px; font-weight:700; color:#e2e8f0;">${isPremium ? '⭐ Premium (Sem Juros)' : '🏷️ Clássico (Com Juros)'}</div>
                </div>
                <div>
                  <div style="font-size:10px; color:#94a3b8;">Frete Grátis pelo Vendedor:</div>
                  <div style="font-size:11px; font-weight:700; color:${itemData.hasFreeShipping ? '#34d399' : '#94a3b8'};">${itemData.hasFreeShipping ? 'Sim (Frete Pago)' : 'Não (Comprador)'}</div>
                </div>
              </div>
              <div style="font-size:10px; color:#64748b; margin-top:8px;">
                ⏱️ Histórico Estimado: <strong>~${estMonths} meses no ar</strong> ${itemData.sellerSales60d ? `• ${itemData.sellerSales60d}` : ''}
              </div>
            </div>

            <!-- Velocidade de Giro (Gated for Pro/Scale/Vitalício) -->
            <div style="margin-top: 12px; border-top: 1px solid #334155; padding-top: 10px;">
              <div class="melispy-metric-label">⚡ VELOCIDADE ESTIMADA DE VENDAS</div>
              ${isStarter ? `
                <div style="background:#0f172a; border-radius:6px; padding:10px; border:1px dashed #334155; text-align:center; margin-top:6px;">
                  <span style="font-size:11px; color:#94a3b8;">🔒 Giro Diário e Mensal: <strong>Exclusivo Planos Pro, Scale & Vitalício</strong></span>
                </div>
              ` : `
                <div class="melispy-velocity-grid">
                  <div class="melispy-velo-item">
                    <div class="melispy-velo-label">Giro Diário</div>
                    <div class="melispy-velo-val">~${dailyVelocity} un/dia</div>
                  </div>
                  <div class="melispy-velo-item">
                    <div class="melispy-velo-label">Giro Mensal</div>
                    <div class="melispy-velo-val">~${monthlyVelocity} un/mês</div>
                  </div>
                  <div class="melispy-velo-item">
                    <div class="melispy-velo-label">Faturamento/Mês</div>
                    <div class="melispy-velo-val" style="font-size:11px; color:#38bdf8;">${monthlyRevenue}</div>
                  </div>
                </div>
              `}
            </div>
          </div>

          <!-- Calculadora de Lucro Real (Disponível em todos os planos) -->
          <div class="melispy-card">
            <div class="melispy-card-title">💰 Calculadora de Margem Real</div>
            
            <div class="melispy-input-group">
              <label class="melispy-input-label">Preço de Venda (R$)</label>
              <input type="number" id="melispy-calc-price" class="melispy-input" value="${itemData.price.toFixed(2)}" step="0.5">
            </div>

            <div class="melispy-input-group">
              <label class="melispy-input-label">Seu Custo do Produto (R$)</label>
              <input type="number" id="melispy-calc-cost" class="melispy-input" value="${(itemData.price * 0.4).toFixed(2)}" placeholder="Ex: 35.00">
            </div>

            <div class="melispy-grid" style="margin-bottom: 10px;">
              <div>
                <label class="melispy-input-label">Tipo de Anúncio</label>
                <select id="melispy-calc-type" class="melispy-select">
                  <option value="12" ${!isPremium ? 'selected' : ''}>Clássico (~12%)</option>
                  <option value="17" ${isPremium ? 'selected' : ''}>Premium (~17%)</option>
                </select>
              </div>
              <div>
                <label class="melispy-input-label">Imposto / Simples (%)</label>
                <input type="number" id="melispy-calc-tax" class="melispy-input" value="4" step="0.5">
              </div>
            </div>

            <div class="melispy-input-group">
              <label class="melispy-input-label">Custo de Frete Médio (R$)</label>
              <input type="number" id="melispy-calc-shipping" class="melispy-input" value="${itemData.price >= 79 ? '22.00' : '0'}" step="1">
            </div>

            <div class="melispy-profit-box">
              <div>
                <div class="melispy-profit-label">Lucro Líquido no Bolso</div>
                <div class="melispy-profit-val" id="melispy-res-profit">R$ 0,00</div>
              </div>
              <div style="text-align: right;">
                <div class="melispy-profit-label">Margem Líquida</div>
                <div class="melispy-margin-pct" id="melispy-res-margin">0%</div>
              </div>
            </div>
          </div>
        </div>

        <!-- TAB 2: SEU POTENCIAL DE LUCRO PESSOAL & PLANO DE ATAQUE -->
        <div class="melispy-tab-content" id="tab-potencial">
          ${isStarter ? `
            <div class="melispy-card" style="text-align:center; padding: 36px 18px;">
              <div style="font-size:36px; margin-bottom:10px;">🔒</div>
              <h4 style="font-size:15px; color:#fff; margin-bottom:6px;">Módulo Estratégico Exclusivo Pro, Scale & Vitalício</h4>
              <p style="font-size:12px; color:#94a3b8; line-height:1.5; margin-bottom:16px;">
                Desbloqueie o <strong>Plano de Ataque de Mercado</strong>, Projeções de Faturamento & Lucro Líquido, Dimensionamento de Estoque e Capital de Giro.
              </p>
              <a href="https://wa.me/5548996192775?text=Olá%20Mateus,%20quero%20fazer%20upgrade%20do%20meu%20plano%20Starter%20para%20o%20Vitalício" target="_blank" class="melispy-cta-btn" style="display:inline-block; font-size:12px; padding:10px 16px;">
                Fazer Upgrade para o Pro
              </a>
            </div>
          ` : `
            <div class="melispy-card-highlight">
              <div style="font-size:11px; text-transform:uppercase; color:#6ee7b7; font-weight:800; letter-spacing:0.8px;">
                🎯 META DE PENETRAÇÃO DE MERCADO (MARKET SHARE)
              </div>
              <div style="font-size:12px; color:#cbd5e1; margin-top:4px;">
                Selecione quanto do volume deste concorrente você planeja capturar:
              </div>

              <div class="melispy-scenario-btns" style="margin-top:10px;">
                <button class="melispy-scen-btn" data-pct="0.03">3% Teste</button>
                <button class="melispy-scen-btn active" data-pct="0.10">10% Moderado</button>
                <button class="melispy-scen-btn" data-pct="0.20">20% Concorrente</button>
                <button class="melispy-scen-btn" data-pct="0.35">35% Domínio</button>
              </div>

              <div style="background:#0f172a; border-radius:8px; padding:12px; border:1px solid #047857; margin-top:10px;">
                <div style="display:flex; justify-content:space-between; margin-bottom:6px; font-size:12px; color:#cbd5e1;">
                  <span>Vendas Projetadas:</span>
                  <strong id="melispy-scen-units" style="color:#fff;">~0 un/mês</strong>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:12px; color:#cbd5e1;">
                  <span>Faturamento Projetado:</span>
                  <strong id="melispy-scen-rev" style="color:#38bdf8;">R$ 0,00 /mês</strong>
                </div>
                <div style="border-top:1px solid #1e293b; padding-top:8px; display:flex; justify-content:space-between; align-items:center;">
                  <span style="font-weight:700; color:#a7f3d0; font-size:13px;">Seu Lucro Limpo no Bolso:</span>
                  <span id="melispy-scen-profit" style="font-size:20px; font-weight:900; color:#34d399;">R$ 0,00</span>
                </div>
              </div>
            </div>

            <!-- Dimensionamento de Estoque & Capital de Giro -->
            <div class="melispy-card">
              <div class="melispy-card-title">📦 Dimensionamento de Estoque & Capital</div>
              <div class="melispy-grid">
                <div class="melispy-metric">
                  <div class="melispy-metric-label">Estoque Recomendado (30d)</div>
                  <div class="melispy-metric-value" id="melispy-scen-stock" style="color:#facc15;">~0 un.</div>
                </div>
                <div class="melispy-metric">
                  <div class="melispy-metric-label">Capital de Giro em Produto</div>
                  <div class="melispy-metric-value" id="melispy-scen-capital" style="color:#38bdf8; font-size:13px;">R$ 0,00</div>
                </div>
                <div class="melispy-metric">
                  <div class="melispy-metric-label">Ponto de Equilíbrio</div>
                  <div class="melispy-metric-value" id="melispy-scen-breakeven" style="color:#e2e8f0; font-size:13px;">~0 un.</div>
                </div>
                <div class="melispy-metric">
                  <div class="melispy-metric-label">ROI Mensal sobre Estoque</div>
                  <div class="melispy-metric-value" id="melispy-scen-roi" style="color:#34d399; font-size:13px;">+0%</div>
                </div>
              </div>
              <div style="font-size:10px; color:#64748b; margin-top:8px;">
                💡 Dimensionado com base no custo informado na Calculadora de Margem.
              </div>
            </div>

            <!-- Plano Tático Passo a Passo -->
            <div class="melispy-card">
              <div class="melispy-card-title">🗺️ Plano de Ataque Tático (Passo a Passo)</div>
              <div class="melispy-strat-step">
                <div class="melispy-strat-badge">Fase 1</div>
                <div class="melispy-strat-desc">
                  <strong>Ativação (10 Primeiras Vendas):</strong> Anuncie no Clássico por <strong>R$ ${(itemData.price * 0.94).toFixed(2)}</strong> (6% abaixo) para conquistar as primeiras 10 vendas e ativar a medalha verde rápida.
                </div>
              </div>
              <div class="melispy-strat-step">
                <div class="melispy-strat-badge">Fase 2</div>
                <div class="melispy-strat-desc">
                  <strong>Tração & Publicidade:</strong> Suba para o preço de margem cheia e ative Product Ads com ACOS alvo de 12% a 15% focado nas palavras-chave da aba SEO.
                </div>
              </div>
              <div class="melispy-strat-step">
                <div class="melispy-strat-badge">Fase 3</div>
                <div class="melispy-strat-desc">
                  <strong>Escala & BuyBox:</strong> ${isFull 
                    ? 'Envie lote para o <strong>Mercado Envios Full</strong> para igualar a velocidade de entrega deste concorrente e disputar a primeira posição.'
                    : 'Oportunidade de Ouro: Este concorrente NÃO está no Full! Se você enviar pro Full, ganha o selo "Chegará Amanhã" e ultrapassa ele no ranking orgânico.'}
                </div>
              </div>
            </div>

            <!-- Barreira de Entrada -->
            <div class="melispy-card">
              <div class="melispy-card-title">🛡️ Diagnóstico de Barreira de Entrada</div>
              <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:8px;">
                <span style="font-size:12px; color:#94a3b8;">Nível de Dificuldade:</span>
                <span class="melispy-diff-badge ${isFull ? 'mod' : 'easy'}">
                  ${isFull ? '🟡 MODERADA (CONCORRENTE NO FULL)' : '🟢 FÁCIL (SEM ENVIO FULL)'}
                </span>
              </div>
              <div style="font-size:12px; color:#cbd5e1; line-height:1.4;">
                ${itemData.sold_quantity > 2000 
                  ? 'Anúncio maduro com alto volume acumulado. A melhor estratégia para entrar é montar um kit ou combo com diferencial que o concorrente não oferece.'
                  : 'Excelente janela de entrada! Concorrente com volume acessível, permitindo ultrapassagem rápida com boa ficha técnica e fotos HD.'}
              </div>
            </div>
          `}
        </div>

        <!-- TAB 3: PREÇO IDEAL, SEO & AÇÕES -->
        <div class="melispy-tab-content" id="tab-acoes">
          <!-- Calculadora Reversa de Preço Ideal (Gated for Pro/Scale/Vitalício) -->
          ${isStarter ? `
            <div class="melispy-card" style="text-align:center; padding: 24px 16px; border:1px dashed #334155;">
              <span style="font-size:12px; color:#94a3b8;">🔒 Calculadora Reversa de Preço Ideal: <strong>Disponível nos Planos Pro, Scale & Vitalício</strong></span>
            </div>
          ` : `
            <div class="melispy-card">
              <div class="melispy-card-title">🎯 Calculadora Reversa (Preço Ideal)</div>
              <div style="font-size:12px; color:#94a3b8; margin-bottom:10px;">
                Descubra por quanto vender para colocar a margem desejada no bolso:
              </div>

              <div class="melispy-grid" style="margin-bottom:10px;">
                <div>
                  <label class="melispy-input-label">Seu Custo (R$)</label>
                  <input type="number" id="melispy-rev-cost" class="melispy-input" value="${(itemData.price * 0.4).toFixed(2)}">
                </div>
                <div>
                  <label class="melispy-input-label">Margem Alvo (%)</label>
                  <input type="number" id="melispy-rev-margin" class="melispy-input" value="25">
                </div>
              </div>

              <div style="background:#0f172a; border-radius:8px; padding:12px; border:1px solid #334155;">
                <div style="font-size:11px; color:#94a3b8; margin-bottom:4px;">PREÇO DE VENDA RECOMENDADO:</div>
                <div style="display:flex; justify-content:space-between; align-items:center;">
                  <span style="font-size:12px; color:#cbd5e1;">Anúncio Clássico:</span>
                  <strong id="melispy-rev-price-classic" style="color:#38bdf8; font-size:16px;">R$ 0,00</strong>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:4px;">
                  <span style="font-size:12px; color:#cbd5e1;">Anúncio Premium:</span>
                  <strong id="melispy-rev-price-premium" style="color:#facc15; font-size:16px;">R$ 0,00</strong>
                </div>
              </div>
            </div>
          `}

          <!-- Auditoria de SEO & Otimizador de Título -->
          <div class="melispy-card">
            <div class="melispy-card-title">🔍 Auditoria de SEO & Título</div>
            
            <div style="display:flex; justify-content:space-between; align-items:center;">
              <span style="font-size:12px; color:#94a3b8;">Score do Algoritmo ML:</span>
              <strong style="color:${seoColor}; font-size:15px;">${isStarter ? '🔒 Pro / Scale' : seoScore + '/100 (' + seoLabel + ')'}</strong>
            </div>

            ${!isStarter ? `
              <div class="melispy-seo-bar">
                <div class="melispy-seo-fill" style="width: ${seoScore}%; background: ${seoColor};"></div>
              </div>
            ` : ''}

            <div style="font-size:11px; color:#94a3b8; margin-bottom:6px; display:flex; justify-content:space-between;">
              <span>Tamanho: <strong style="color:${cleanTitle.length >= 45 && cleanTitle.length <= 60 ? '#34d399' : '#f87171'}">${cleanTitle.length}/60 caracteres</strong></span>
              <span>${cleanTitle.length <= 60 ? '✅ Não corta no mobile' : '⚠️ Corta no celular'}</span>
            </div>

            <div style="font-size:11px; margin-bottom:8px; padding:6px 8px; border-radius:6px; background:#0f172a; border:1px solid #334155;">
              ${detectedForbidden.length > 0 
                ? `<span style="color:#f87171;">⚠️ Palavras que queimam relevância detectadas: <strong>${detectedForbidden.join(', ')}</strong></span>` 
                : `<span style="color:#34d399;">✅ Zero palavras proibidas detectadas no título (Excelente!)</span>`}
            </div>

            ${isStarter ? `
              <div style="background:#0f172a; border-radius:6px; padding:8px; border:1px dashed #334155; text-align:center; font-size:11px; color:#94a3b8; margin-top:6px;">
                🔒 Gerador de Título Otimizado & Tags: <strong>Exclusivo Pro, Scale & Vitalício</strong>
              </div>
            ` : `
              <div class="melispy-tags-container">
                ${uniqueKeywords.map((tag) => `<span class="melispy-tag">${tag}</span>`).join('')}
              </div>

              <!-- Sugestão de Título Otimizado MeliSpy -->
              <div class="melispy-opt-title-box">
                <div style="font-size:10px; text-transform:uppercase; color:#38bdf8; font-weight:800; margin-bottom:4px;">
                  💡 Título Otimizado MeliSpy (Fórmula de Alta Conversão):
                </div>
                <div class="melispy-opt-title-text" id="melispy-opt-title-content">
                  ${optimizedTitle}
                </div>
                <button class="melispy-copy-title-btn" id="melispy-copy-title-btn">
                  📋 Copiar Título Otimizado
                </button>
              </div>
            `}
          </div>

          <!-- Galeria de Fotos em Ultra HD & Ações (Exclusivo Scale & Vitalício) -->
          ${isScaleOrVitalicio ? `
            <div class="melispy-card">
              <div class="melispy-card-title">📸 Galeria de Fotos em Ultra HD (${itemData.photos ? itemData.photos.length : 0} fotos)</div>
              <div style="font-size:11px; color:#94a3b8; margin-bottom:6px;">
                Clique em qualquer foto individual para abrir/baixar em alta resolução (-O HD):
              </div>

              <div class="melispy-photo-gallery">
                ${(itemData.photos || []).map((url, idx) => `
                  <div class="melispy-photo-item" data-url="${url}" title="Foto ${idx + 1} - Clique para abrir em Alta Definição">
                    <img src="${url}" loading="lazy" alt="Foto ${idx + 1}">
                    <span class="melispy-photo-badge">HD</span>
                  </div>
                `).join('')}
              </div>

              <div class="melispy-action-group" style="margin-top:6px;">
                <button class="melispy-act-btn" id="melispy-download-cover-btn">
                  🌟 Baixar Foto de Capa (Principal HD)
                </button>
                <button class="melispy-act-btn" id="melispy-download-top3-btn">
                  📦 Baixar as 3 Melhores Fotos (Capa + Detalhes)
                </button>
                <button class="melispy-act-btn green" id="melispy-copy-briefing-btn">
                  📋 Copiar Raio-X Completo para WhatsApp
                </button>
              </div>
            </div>
          ` : `
            <div class="melispy-card" style="text-align:center; padding:16px; border:1px dashed #334155; margin-top:10px;">
              <span style="font-size:11px; color:#94a3b8;">🔒 Galeria de Fotos em HD e Resumo WhatsApp: <strong>Exclusivo dos Planos Scale & Vitalício</strong></span>
              <a href="https://wa.me/5548996192775?text=Olá%20Mateus,%20quero%20fazer%20upgrade%20para%20o%20plano%20Scale%20ou%20Vitalício%20do%20MeliSpy" target="_blank" style="display:block; font-size:11px; color:#38bdf8; margin-top:6px; font-weight:700; text-decoration:none;">Fazer Upgrade para Scale / Vitalício →</a>
            </div>
          `}
        </div>

      </div>
    `;

    // 3. Locked Overlay (Strict Paid License Screen or Expired Screen)
    if (isLocked) {
      const lockOverlay = document.createElement('div');
      lockOverlay.className = 'melispy-locked-overlay';

      if (license.isExpired) {
        const expDateStr = license.expiresAt ? new Date(license.expiresAt).toLocaleDateString('pt-BR') : '';
        lockOverlay.innerHTML = `
          <div class="melispy-lock-icon">⏱️</div>
          <div class="melispy-lock-title">Período de Assinatura Encerrado</div>
          <div class="melispy-lock-desc">
            Sua assinatura do <strong>MeliSpy Pro (${userPlan.toUpperCase()})</strong> encerrou o período contratado em <strong>${expDateStr}</strong>.<br><br>
            Você pôde utilizar todos os dias até o término do período pago. Para continuar utilizando, renove seu plano ou insira uma nova chave:
          </div>

          <a href="https://ferramentasweb.vercel.app/#precos" target="_blank" class="melispy-cta-btn" style="background:linear-gradient(135deg, #10b981 0%, #059669 100%);">
            🔄 Renovar Minha Assinatura no Site
          </a>

          <div class="melispy-input-key-area" style="margin-top:16px;">
            <input type="text" id="melispy-license-input" class="melispy-input" placeholder="Cole sua Nova Chave de Renovação">
            <button id="melispy-activate-btn" class="melispy-key-btn">Reativar</button>
          </div>
        `;
      } else {
        lockOverlay.innerHTML = `
          <div class="melispy-lock-icon">🔒</div>
          <div class="melispy-lock-title">Software Restrito • Ativação Necessária</div>
          <div class="melispy-lock-desc">
            O <strong>MeliSpy Pro</strong> é exclusivo para clientes licenciados da <strong>FerramentasWeb</strong>.<br>
            Esta licença é blindada e vinculada à sua máquina física.
          </div>

          <div style="font-size: 11px; color: #64748b; margin-bottom: 12px; font-family: monospace;">
            ID desta Máquina: <strong style="color: #38bdf8;">${currentHwid}</strong>
          </div>

          <div class="melispy-pix-box">
            <div class="melispy-pix-title">👑 PLANO VITALÍCIO FOUNDER: R$ 119,00 (PAGAMENTO ÚNICO)</div>
            <div style="font-size: 11px; color: #94a3b8;">Chave Pix Oficial FerramentasWeb (Clique para Copiar):</div>
            <span class="melispy-pix-key" id="melispy-copy-pix">mateus.pix@ferramentasweb.com</span>
          </div>

          <a href="https://ferramentasweb.vercel.app/#precos" target="_blank" class="melispy-cta-btn">
            Garantir Minha Licença no Site Oficial
          </a>

          <div class="melispy-input-key-area">
            <input type="text" id="melispy-license-input" class="melispy-input" placeholder="Cole sua Chave (Ex: 4D24-9F27-0FCA-4C69)">
            <button id="melispy-activate-btn" class="melispy-key-btn">Ativar</button>
          </div>
        `;
      }
      sidebar.appendChild(lockOverlay);
    }

    // 4. Quota Limit Overlay (When monthly queries hit the plan limit)
    if (!isLocked && quota.isExceeded) {
      const quotaOverlay = document.createElement('div');
      quotaOverlay.className = 'melispy-locked-overlay';
      quotaOverlay.innerHTML = `
        <div class="melispy-lock-icon">⚠️</div>
        <div class="melispy-lock-title">Limite de Análises Atingido</div>
        <div class="melispy-lock-desc">
          Você já realizou as <strong>${quota.max} análises mensais</strong> inclusas no seu plano <strong>${userPlan.toUpperCase()}</strong>.<br>
          Seus créditos serão renovados automaticamente no dia 1º do próximo mês.
        </div>
        <div class="melispy-pix-box">
          <div class="melispy-pix-title">👑 DESBLOQUEIE ACESSO ILIMITADO SEM MENSALIDADES</div>
          <div style="font-size: 11px; color: #94a3b8; line-height: 1.4;">
            Faça upgrade para o <strong>Plano Vitalício Founder</strong> por apenas R$ 119 único e consulte quantos anúncios quiser para sempre!
          </div>
        </div>
        <a href="https://wa.me/5548996192775?text=Oi%20Mateus,%20atingi%20o%20limite%20de%20${quota.max}%20análises%20do%20meu%20plano%20${userPlan}%20no%20MeliSpy%20e%20quero%20fazer%20upgrade!" target="_blank" class="melispy-cta-btn">
          Fazer Upgrade Imediato no WhatsApp
        </a>
      `;
      sidebar.appendChild(quotaOverlay);
    }

    document.body.appendChild(sidebar);

    // Toggle Sidebar events
    triggerBtn.addEventListener('click', () => {
      sidebar.classList.toggle('active');
    });

    const closeBtn = document.getElementById('melispy-close-x');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        sidebar.classList.remove('active');
      });
    }

    // Profit calculation logic
    function calculateProfit() {
      const price = parseFloat(document.getElementById('melispy-calc-price')?.value) || 0;
      const cost = parseFloat(document.getElementById('melispy-calc-cost')?.value) || 0;
      const feePct = parseFloat(document.getElementById('melispy-calc-type')?.value) || 12;
      const taxPct = parseFloat(document.getElementById('melispy-calc-tax')?.value) || 0;
      const shipping = parseFloat(document.getElementById('melispy-calc-shipping')?.value) || 0;

      // ML Fixed fee: R$ 6.00 for items under R$ 79.00
      const fixedFee = price < 79 ? 6.00 : 0;

      // Fees in R$
      const mlFeeVal = price * (feePct / 100);
      const taxVal = price * (taxPct / 100);

      // Net profit
      const netProfit = price - cost - mlFeeVal - fixedFee - taxVal - shipping;
      const marginPct = price > 0 ? (netProfit / price) * 100 : 0;

      const profitEl = document.getElementById('melispy-res-profit');
      const marginEl = document.getElementById('melispy-res-margin');

      if (profitEl && marginEl) {
        profitEl.textContent = netProfit.toLocaleString('pt-BR', {
          style: 'currency',
          currency: 'BRL'
        });
        profitEl.style.color = netProfit >= 0 ? '#34d399' : '#f87171';
        marginEl.textContent = `${marginPct.toFixed(1)}%`;
        marginEl.style.color = netProfit >= 0 ? '#6ee7b7' : '#f87171';
      }
    }

    // Calculator change listeners
    ['price', 'cost', 'tax', 'shipping'].forEach((id) => {
      document.getElementById(`melispy-calc-${id}`)?.addEventListener('input', () => {
        calculateProfit();
        updateScenario();
      });
    });
    document.getElementById('melispy-calc-type')?.addEventListener('change', () => {
      calculateProfit();
      updateScenario();
    });
    calculateProfit();

    // 1. Navigation Tab Switching Logic
    sidebar.querySelectorAll('.melispy-tab-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        sidebar.querySelectorAll('.melispy-tab-btn').forEach((b) => b.classList.remove('active'));
        sidebar.querySelectorAll('.melispy-tab-content').forEach((c) => c.classList.remove('active'));
        btn.classList.add('active');
        const tabId = btn.getAttribute('data-tab');
        sidebar.querySelector(`#${tabId}`)?.classList.add('active');
      });
    });

    // 2. Personal Potential Profit Scenario Simulator
    let currentScenarioPct = 0.10;
    function updateScenario() {
      const price = itemData.price || 50;
      const costPerUnit = parseFloat(document.getElementById('melispy-calc-cost')?.value) || (price * 0.4);
      const netPerUnit = parseFloat(document.getElementById('melispy-res-profit')?.textContent.replace(/[^\d,-]/g, '').replace(',', '.')) || (price * 0.2);
      
      const projectedUnits = Math.max(1, Math.round(monthlyVelocity * currentScenarioPct));
      const projectedRev = projectedUnits * price;
      const projectedProfit = projectedUnits * netPerUnit;
      const recommendedStock = Math.max(1, Math.round(projectedUnits * 1.1));
      const capitalNeeded = recommendedStock * costPerUnit;
      const breakevenUnits = netPerUnit > 0 ? Math.min(recommendedStock, Math.max(1, Math.round(capitalNeeded / Math.max(1, price * 0.6)))) : 0;
      const roiPct = capitalNeeded > 0 ? ((projectedProfit / capitalNeeded) * 100) : 0;

      const unitsEl = document.getElementById('melispy-scen-units');
      const revEl = document.getElementById('melispy-scen-rev');
      const profitEl = document.getElementById('melispy-scen-profit');
      const stockEl = document.getElementById('melispy-scen-stock');
      const capEl = document.getElementById('melispy-scen-capital');
      const breakEl = document.getElementById('melispy-scen-breakeven');
      const roiEl = document.getElementById('melispy-scen-roi');

      if (unitsEl) unitsEl.textContent = `~${projectedUnits} un/mês (~${Math.max(1, Math.round(projectedUnits / 30))} un/dia)`;
      if (revEl) revEl.textContent = projectedRev.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) + ' /mês';
      if (profitEl) {
        profitEl.textContent = projectedProfit.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        profitEl.style.color = projectedProfit >= 0 ? '#34d399' : '#f87171';
      }
      if (stockEl) stockEl.textContent = `~${recommendedStock} un.`;
      if (capEl) capEl.textContent = capitalNeeded.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
      if (breakEl) breakEl.textContent = `~${breakevenUnits} un.`;
      if (roiEl) roiEl.textContent = `+${Math.max(0, Math.round(roiPct))}% /mês`;
    }

    sidebar.querySelectorAll('.melispy-scen-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        sidebar.querySelectorAll('.melispy-scen-btn').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        currentScenarioPct = parseFloat(btn.getAttribute('data-pct')) || 0.10;
        updateScenario();
      });
    });
    updateScenario();

    // 3. Reverse Pricing Calculator Logic
    function calculateReversePrice() {
      const cost = parseFloat(document.getElementById('melispy-rev-cost')?.value) || 0;
      const targetMarginPct = (parseFloat(document.getElementById('melispy-rev-margin')?.value) || 25) / 100;
      const taxPct = 0.04;

      const divisorClassic = 1 - 0.12 - taxPct - targetMarginPct;
      const divisorPremium = 1 - 0.17 - taxPct - targetMarginPct;

      let priceClassic = divisorClassic > 0 ? (cost + 6.00) / divisorClassic : cost * 2;
      let pricePremium = divisorPremium > 0 ? (cost + 6.00) / divisorPremium : cost * 2.2;

      if (priceClassic >= 79) priceClassic = divisorClassic > 0 ? (cost + 22.00) / divisorClassic : priceClassic;
      if (pricePremium >= 79) pricePremium = divisorPremium > 0 ? (cost + 22.00) / divisorPremium : pricePremium;

      const classicEl = document.getElementById('melispy-rev-price-classic');
      const premiumEl = document.getElementById('melispy-rev-price-premium');

      if (classicEl) classicEl.textContent = priceClassic.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
      if (premiumEl) premiumEl.textContent = pricePremium.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    }

    document.getElementById('melispy-rev-cost')?.addEventListener('input', calculateReversePrice);
    document.getElementById('melispy-rev-margin')?.addEventListener('input', calculateReversePrice);
    calculateReversePrice();

    // 4. Copy Briefing for WhatsApp
    document.getElementById('melispy-copy-briefing-btn')?.addEventListener('click', () => {
      const text = `📊 *Raio-X de Concorrência • MeliSpy Pro*\n` +
        `📦 *Produto:* ${cleanTitle}\n` +
        `💰 *Preço Atual:* ${itemData.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}\n` +
        `📈 *Vendas Confirmadas:* ${itemData.sold_quantity.toLocaleString('pt-BR')} un.\n` +
        `💵 *Faturamento Estimado:* ${estRevenue}\n` +
        `⚡ *Giro Estimado:* ~${dailyVelocity} un/dia (~${monthlyVelocity} un/mês)\n` +
        `🚚 *Logística:* ${isFull ? 'Mercado Envios Full' : 'Envio Padrão'}\n` +
        `🏆 *Vendedor:* ${itemData.sellerLevel} (${itemData.sellerSales60d || 'Reputação Positiva'})\n` +
        `🏷️ *Modalidade:* ${isPremium ? 'Premium (Sem Juros)' : 'Clássico'}\n` +
        `🎯 *Curva ABC:* ${curvaText}\n` +
        `🔍 *Score SEO:* ${seoScore}/100 (${seoLabel})\n` +
        `🚀 *Gerado pelo MeliSpy Pro (FerramentasWeb)*`;

      navigator.clipboard.writeText(text).then(() => {
        alert('✅ Resumo Executivo copiado com sucesso! Pode colar no WhatsApp.');
      });
    });

    // 5. Copy Optimized Title
    document.getElementById('melispy-copy-title-btn')?.addEventListener('click', () => {
      const titleText = document.getElementById('melispy-opt-title-content')?.textContent.trim();
      if (titleText) {
        navigator.clipboard.writeText(titleText).then(() => {
          const btn = document.getElementById('melispy-copy-title-btn');
          if (btn) btn.textContent = '✅ Título Copiado!';
          setTimeout(() => {
            if (btn) btn.textContent = '📋 Copiar Título Otimizado';
          }, 2000);
        });
      }
    });

    // 6. Interactive Individual Photo Clicks
    sidebar.querySelectorAll('.melispy-photo-item').forEach(item => {
      item.addEventListener('click', () => {
        const url = item.getAttribute('data-url');
        if (url) window.open(url, '_blank');
      });
    });

    // 7. Download Cover Photo (Only 1 image)
    document.getElementById('melispy-download-cover-btn')?.addEventListener('click', () => {
      if (itemData.photos && itemData.photos.length > 0) {
        window.open(itemData.photos[0], '_blank');
      } else {
        alert('Foto de capa não encontrada.');
      }
    });

    // 8. Download Top 3 Photos (Max 3 tabs to avoid browser blocking)
    document.getElementById('melispy-download-top3-btn')?.addEventListener('click', () => {
      if (itemData.photos && itemData.photos.length > 0) {
        const top3 = itemData.photos.slice(0, 3);
        top3.forEach(url => window.open(url, '_blank'));
      } else {
        alert('Nenhuma foto encontrada nesta galeria.');
      }
    });

    // Pix key copy in locked overlay
    const copyPixEl = document.getElementById('melispy-copy-pix');
    if (copyPixEl) {
      copyPixEl.style.cursor = 'pointer';
      copyPixEl.title = 'Clique para copiar a chave Pix';
      copyPixEl.addEventListener('click', () => {
        navigator.clipboard.writeText('mateus.pix@ferramentasweb.com').then(() => {
          alert('✅ Chave Pix copiada com sucesso!');
        });
      });
    }

    // Key activation listener (Strict Hardware Binding & Plan Tier Assignment)
    const activateBtn = document.getElementById('melispy-activate-btn');
    if (activateBtn) {
      activateBtn.addEventListener('click', () => {
        const inputKey = (document.getElementById('melispy-license-input')?.value || '').trim();
        const parsed = verifyAndParseLicenseKey(inputKey);

        if (parsed && parsed.valid) {
          const plan = parsed.plan;
          const expiresAt = parsed.expiresAt;

          // Permanently bind to this physical machine HWID
          chrome.storage.local.set({
            melispy_is_pro: true,
            melispy_hwid: currentHwid,
            melispy_license_key: inputKey.toUpperCase(),
            melispy_plan: plan,
            melispy_expires_at: expiresAt
          }, () => {
            const expMsg = expiresAt ? `\nAssinatura Ativa até: ${new Date(expiresAt).toLocaleDateString('pt-BR')} (mesmo se você cancelar antes, seu acesso fica garantido até este dia!)` : '\nAcesso Vitalício Ilimitado Sem Expiração!';
            alert(`🎉 MeliSpy Pro ativado com sucesso para este computador (${currentHwid})!\nPlano: ${plan.toUpperCase()}${expMsg}`);
            location.reload();
          });
        } else {
          alert('❌ Chave de ativação inválida ou incorreta. Verifique o código gerado no site.');
        }
      });
    }
  }

  // Continuous SPA Navigation & URL Watcher for Mercado Livre
  let lastMlbId = undefined;
  let isInitializing = false;

  async function checkAndRun() {
    if (isInitializing) return;
    const currentMlb = getMlbId();

    // If already injected and MLB ID hasn't changed and button exists, don't duplicate
    if (currentMlb === lastMlbId && document.getElementById('melispy-trigger-btn')) {
      return;
    }
    lastMlbId = currentMlb;
    isInitializing = true;

    // Clean any old elements
    const oldBtn = document.getElementById('melispy-trigger-btn');
    if (oldBtn) oldBtn.remove();
    const oldSidebar = document.getElementById('melispy-sidebar');
    if (oldSidebar) oldSidebar.remove();

    await init();
    isInitializing = false;
  }

  // Safe navigation detection for Mercado Livre SPA
  window.addEventListener('popstate', () => setTimeout(checkAndRun, 200));

  let lastHref = window.location.href;
  setInterval(() => {
    if (window.location.href !== lastHref) {
      lastHref = window.location.href;
      checkAndRun();
    }
  }, 400);

  // Initial execution & backup check
  checkAndRun();
  setInterval(checkAndRun, 1200);
})();
