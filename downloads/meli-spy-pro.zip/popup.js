document.addEventListener('DOMContentLoaded', () => {
  const statusText = document.getElementById('status-text');
  const statusDesc = document.getElementById('status-plan-desc');
  const headerBadge = document.getElementById('header-badge');
  const hwidDisplay = document.getElementById('hwid-display');
  const copyHwidBtn = document.getElementById('copy-hwid-btn');
  const permissionsList = document.getElementById('permissions-list');
  const activateBtn = document.getElementById('activate-btn');
  const keyInput = document.getElementById('license-key-input');
  const msgEl = document.getElementById('activation-msg');
  const activationSection = document.getElementById('activation-section');
  const switchPlanArea = document.getElementById('switch-plan-area');
  const toggleSwitchBtn = document.getElementById('toggle-switch-key-btn');

  // Hardware Fingerprint Generator (Matches content.js)
  function getHardwareFingerprint() {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      let renderer = 'standard_gpu';
      if (gl) {
        const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
        if (debugInfo) {
          renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || 'generic_gpu';
        }
      }
      const raw = [
        renderer,
        screen.width + 'x' + screen.height,
        screen.colorDepth,
        navigator.hardwareConcurrency || 4,
        Intl.DateTimeFormat().resolvedOptions().timeZone
      ].join('###');

      let hash = 0;
      for (let i = 0; i < raw.length; i++) {
        hash = ((hash << 5) - hash) + raw.charCodeAt(i);
        hash |= 0;
      }
      return 'HWID_' + Math.abs(hash).toString(16).toUpperCase();
    } catch (e) {
      return 'HWID_DEFAULT_CORE';
    }
  }

  const currentHwid = getHardwareFingerprint();
  if (hwidDisplay) hwidDisplay.textContent = currentHwid;

  if (copyHwidBtn) {
    copyHwidBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(currentHwid).then(() => {
        copyHwidBtn.textContent = 'Copiado!';
        setTimeout(() => { copyHwidBtn.textContent = 'Copiar'; }, 2000);
      });
    });
  }

  const quotaCard = document.getElementById('quota-card');
  const quotaDisplay = document.getElementById('quota-display');
  const quotaBar = document.getElementById('quota-bar');
  const quotaFooter = document.getElementById('quota-footer');
  const resetQuotaBtn = document.getElementById('reset-quota-btn');

  // Load storage state
  chrome.storage.local.get(['melispy_is_pro', 'melispy_hwid', 'melispy_license_key', 'melispy_plan', 'melispy_analyzed_items'], (res) => {
    try {
      let isPro = res.melispy_is_pro === true;
      const storedKey = (res.melispy_license_key || '').toUpperCase();
      const effectiveHwid = res.melispy_hwid || currentHwid;
      if (hwidDisplay) hwidDisplay.textContent = effectiveHwid;

      // Determine plan
      let plan = res.melispy_plan;
    if (isPro) {
      if (storedKey.includes('STARTER')) plan = 'starter';
      else if (storedKey.includes('SCALE')) plan = 'scale';
      else if (storedKey.includes('VIP') || storedKey.includes('FOUNDER') || storedKey.includes('MATEUS')) plan = 'vitalicio';
      else if (storedKey.includes('PRO')) plan = 'pro';
      else plan = plan || 'vitalicio';
    }

    const analyzedItems = Array.isArray(res.melispy_analyzed_items) ? res.melispy_analyzed_items : [];
    const usedCount = analyzedItems.length;

    const PLAN_LIMITS = {
      starter: 40,
      pro: 75,
      scale: 150,
      vitalicio: Infinity
    };
    const maxLimit = PLAN_LIMITS[plan] || 40;

    if (isPro && plan) {
      // Update Quota Card
      if (quotaCard && quotaDisplay && quotaBar && quotaFooter) {
        quotaCard.style.display = 'block';
        if (plan === 'vitalicio') {
          quotaDisplay.textContent = 'Ilimitado (∞)';
          quotaDisplay.style.color = '#facc15';
          quotaBar.style.width = '100%';
          quotaBar.style.background = 'linear-gradient(90deg, #facc15, #eab308)';
          quotaFooter.textContent = `${usedCount} produtos analisados • Consultas ilimitadas`;
        } else {
          const remaining = Math.max(0, maxLimit - usedCount);
          const pct = Math.min(100, Math.round((usedCount / maxLimit) * 100));
          quotaDisplay.textContent = `${usedCount} / ${maxLimit}`;
          quotaDisplay.style.color = remaining > 0 ? '#38bdf8' : '#f87171';
          quotaBar.style.width = `${pct}%`;
          quotaBar.style.background = pct >= 90 ? '#f87171' : (pct >= 70 ? '#facc15' : '#38bdf8');
          quotaFooter.textContent = remaining > 0
            ? `Restam ${remaining} análises este mês (${pct}% consumido)`
            : `⚠️ Limite de ${maxLimit} consultas atingido este mês!`;
        }
      }

      // Configure UI by Plan
      if (plan === 'starter') {
        headerBadge.textContent = 'STARTER';
        headerBadge.style.background = '#94a3b8';
        statusText.textContent = '📊 Plano STARTER Ativo';
        statusText.style.color = '#cbd5e1';
        statusDesc.textContent = 'Até 40 análises mensais • Licença individual';
        permissionsList.innerHTML = `
          <li class="active">✓ Radiografia Completa (Vendas & Estoque)</li>
          <li class="active">✓ Calculadora de Margem Real & Taxas</li>
          <li class="locked">✗ Giro Diário e Mensal de Vendas (Requer Pro)</li>
          <li class="locked">✗ Simulador de Potencial & Termômetro (Requer Pro)</li>
          <li class="locked">✗ Download de Fotos HD & WhatsApp (Requer Scale)</li>
        `;
      } else if (plan === 'pro') {
        headerBadge.textContent = 'PRO';
        headerBadge.style.background = '#4ade80';
        statusText.textContent = '🚀 Plano PRO Ativo';
        statusText.style.color = '#4ade80';
        statusDesc.textContent = 'Até 75 análises mensais • Inteligência avançada';
        permissionsList.innerHTML = `
          <li class="active">✓ Radiografia Completa (Vendas & Estoque)</li>
          <li class="active">✓ Calculadora de Margem Real & Taxas</li>
          <li class="active">✓ Giro Diário & Faturamento Mensal</li>
          <li class="active">✓ Simulador de Potencial & Termômetro</li>
          <li class="active">✓ Calculadora Reversa de Preço & SEO</li>
          <li class="locked">✗ Download de Fotos HD & WhatsApp (Requer Scale)</li>
        `;
      } else if (plan === 'scale') {
        headerBadge.textContent = 'SCALE';
        headerBadge.style.background = '#38bdf8';
        statusText.textContent = '⚡ Plano SCALE Ativo';
        statusText.style.color = '#38bdf8';
        statusDesc.textContent = 'Até 150 análises mensais • 100% Liberado';
        permissionsList.innerHTML = `
          <li class="active">✓ Todas as métricas e calculadoras liberadas</li>
          <li class="active">✓ Simulador de Potencial & Giro diário</li>
          <li class="active">✓ Calculadora Reversa de Preço & SEO</li>
          <li class="active">✓ Download de Todas as Fotos do Anúncio (HD)</li>
          <li class="active">✓ Copiar Resumo Executivo para WhatsApp</li>
        `;
      } else {
        // Vitalício Founder
        headerBadge.textContent = '👑 VITALÍCIO';
        headerBadge.style.background = '#facc15';
        headerBadge.style.color = '#000';
        statusText.textContent = '👑 VITALÍCIO Founder Ativo';
        statusText.style.color = '#facc15';
        statusDesc.textContent = '🔥 Análises Ilimitadas • Zero Mensalidades';
        permissionsList.innerHTML = `
          <li class="active">✓ 100% das ferramentas liberadas sem restrições</li>
          <li class="active">✓ Consultas Ilimitadas no Mercado Livre</li>
          <li class="active">✓ Download de Fotos em HD + WhatsApp Briefing</li>
          <li class="active">✓ Todas as futuras ferramentas incluídas grátis</li>
        `;
      }

      // Hide activation form, show current key and switch button
      activationSection.style.display = 'none';
      switchPlanArea.style.display = 'flex';

    } else {
      if (quotaCard) quotaCard.style.display = 'none';
      headerBadge.textContent = 'BLOQUEADO';
      headerBadge.style.background = '#f87171';
      headerBadge.style.color = '#fff';
      statusText.textContent = '🔒 Não Ativado (Requer Licença)';
      statusText.style.color = '#f87171';
      statusDesc.textContent = 'Adquira sua licença oficial na FerramentasWeb';
      permissionsList.innerHTML = `
        <li class="locked">✗ Todas as funções bloqueadas</li>
        <li style="color:#94a3b8; font-size:10px;">Ative sua chave recebida no WhatsApp para desbloquear.</li>
      `;
      activationSection.style.display = 'block';
      switchPlanArea.style.display = 'none';
    }
  } catch (err) {
    console.error('[MeliSpy Popup Error]', err);
  }
});

  // Reset Quota for testing
  if (resetQuotaBtn) {
    resetQuotaBtn.addEventListener('click', () => {
      chrome.storage.local.set({ melispy_analyzed_items: [] }, () => {
        alert('🔄 Contador de análises zerado para testes!');
        location.reload();
      });
    });
  }

  // Toggle switch key form
  if (toggleSwitchBtn) {
    toggleSwitchBtn.addEventListener('click', () => {
      activationSection.style.display = activationSection.style.display === 'none' ? 'block' : 'none';
    });
  }

  // Activate / Change Key Handler
  if (activateBtn) {
    activateBtn.addEventListener('click', () => {
      const key = (keyInput.value || '').trim().toUpperCase();
      if (key && key.startsWith('MELI-') && key.length >= 10) {
        let plan = 'vitalicio';
        if (key.includes('STARTER')) plan = 'starter';
        else if (key.includes('SCALE')) plan = 'scale';
        else if (key.includes('VIP') || key.includes('FOUNDER') || key.includes('MATEUS')) plan = 'vitalicio';
        else if (key.includes('PRO')) plan = 'pro';

        chrome.storage.local.set({
          melispy_is_pro: true,
          melispy_hwid: currentHwid,
          melispy_license_key: key,
          melispy_plan: plan
        }, () => {
          msgEl.textContent = `✅ Licença ativada! Plano: ${plan.toUpperCase()}`;
          msgEl.style.color = '#4ade80';
          setTimeout(() => location.reload(), 800);
        });
      } else {
        msgEl.textContent = '❌ Chave inválida. Formato: MELI-XXXX-...';
        msgEl.style.color = '#f87171';
      }
    });
  }
});

