# 🚀 MeliSpy Pro - Manual do Proprietário & Guia de Distribuição

O **MeliSpy Pro** é o Micro-SaaS flagship da **FerramentasWeb** empacotado como Extensão do Chrome / Edge para vendedores do Mercado Livre. Ele espiona vendas de concorrentes, calcula margem líquida real, simula faturamento potencial, calcula preço ideal reverso e audita SEO.

---

## 💎 Sistema de Planos & Funcionalidades Gated

O software possui 4 níveis de acesso funcionais, controlados pelo tipo de chave ativada:

| Funcionalidade / Recurso | Starter (R$ 35/mês) | Pro (R$ 55/mês) | Scale (R$ 89/mês) | Vitalício Founder (R$ 97 único) |
| :--- | :---: | :---: | :---: | :---: |
| **Limite de Consultas** | 40 / mês | 75 / mês | 150 / mês | 🔥 **ILIMITADO PARA SEMPRE** |
| **Radiografia Concorrente** (Vendas & Faturamento) | ✅ Sim | ✅ Sim | ✅ Sim | ✅ Sim |
| **Estoque Disponível & Tipo Logística** | ✅ Sim | ✅ Sim | ✅ Sim | ✅ Sim |
| **Calculadora de Margem Real & Taxas ML** | ✅ Sim | ✅ Sim | ✅ Sim | ✅ Sim |
| **Giro Diário & Mensal de Vendas (Velocidade)** | 🔒 Bloqueado | ✅ Sim | ✅ Sim | ✅ Sim |
| **Simulador de Fatias de Mercado (5%, 15%, 30%)** | 🔒 Bloqueado | ✅ Sim | ✅ Sim | ✅ Sim |
| **Veredito Estratégico de Entrada & Dicas Buy Box**| 🔒 Bloqueado | ✅ Sim | ✅ Sim | ✅ Sim |
| **Calculadora Reversa de Preço Ideal** | 🔒 Bloqueado | ✅ Sim | ✅ Sim | ✅ Sim |
| **Auditoria de SEO & Extração de Palavras-Chave** | 🔒 Bloqueado | ✅ Sim | ✅ Sim | ✅ Sim |
| **Download de Todas as Fotos do Anúncio em HD** | 🔒 Bloqueado | 🔒 Bloqueado | ✅ Sim | ✅ Sim |
| **Copiar Resumo Executivo para WhatsApp** | 🔒 Bloqueado | 🔒 Bloqueado | ✅ Sim | ✅ Sim |
| **Badge Visual no Dock e Popup** | `STARTER` (Cinza) | `PRO` (Verde) | `SCALE` (Ciano) | `👑 VITALÍCIO` (Dourado) |

---

## 🔑 Como Gerar Chaves para Cada Plano (Cheat-Sheet)

O algoritmo de validação lê as palavras-chave contidas no código da chave:

* **Plano Starter:** Qualquer chave com `STARTER` e no mínimo 10 caracteres.
  * Exemplos: `MELI-STARTER-01`, `MELI-STARTER-4921`, `MELI-STARTER-CLIENTE`
* **Plano Pro:** Qualquer chave com `PRO` (sem scale/starter/vip) e no mínimo 10 caracteres.
  * Exemplos: `MELI-PRO-849201`, `MELI-PRO-710394`, `MELI-PRO-2026`
* **Plano Scale:** Qualquer chave com `SCALE` e no mínimo 10 caracteres.
  * Exemplos: `MELI-SCALE-9102`, `MELI-SCALE-TURBO`, `MELI-SCALE-PLUS`
* **Plano Vitalício Founder (Sua Chave & Clientes VIP):** Qualquer chave com `VIP`, `FOUNDER`, `MATEUS` ou `VITALICIO`.
  * Exemplos: `MELI-PRO-MATEUS-VIP`, `MELI-VIP-FOUNDER`, `MELI-VITALICIO-01`

---

## 🔒 Blindagem por Máquina Física (HWID Anti-Pirataria)

Cada computador possui um identificador de hardware único (HWID), gerado pela GPU, resolução e threads do processador.
* Assim que o cliente ativa a chave, o MeliSpy amarra a licença permanentemente ao HWID daquela máquina física.
* Se ele tentar copiar a pasta da extensão ou passar para outra pessoa, o software **bloqueia imediatamente** no outro computador.

---

## 🛠️ Como Testar Você Mesmo no Navegador

1. Abra o Chrome ou Edge e acesse `chrome://extensions`.
2. Ative o **"Modo do desenvolvedor"** no canto superior direito.
3. Se já tiver carregado a extensão, clique no botão de atualizar (ícone de recarregar) no card do MeliSpy Pro.
4. Para testar trocar de plano:
   * Abra o ícone da extensão no topo do Chrome e clique em **"Trocar Chave / Alterar Plano"**.
   * Teste com `MELI-STARTER-01` -> Veja que o dock fica cinza e bloqueia os módulos Pro/Scale.
   * Teste com `MELI-PRO-01` -> Veja que libera o giro e os cenários, mas trava fotos HD.
   * Teste com `MELI-PRO-MATEUS-VIP` -> Veja que tudo fica 100% liberado com badge dourada 👑 VITALÍCIO!

---

## 📢 Script Orgânico de Alta Conversão (Grupos de Facebook / WhatsApp)

> **Título:** *"Cansado de pagar R$ 200/mês para espionar faturamento no Mercado Livre? Criei uma extensão leve e direta ao ponto."*
>
> **Texto:**
> *"Pessoal, desenvolvi uma extensão para Chrome chamada **MeliSpy Pro** pensada especialmente para quem vende ou quer começar a vender no Mercado Livre.
>
> Enquanto você navega em qualquer anúncio, ela abre um dock e te mostra:
> 1. Faturamento total acumulado e vendas reais confirmadas;
> 2. Estoque real disponível do concorrente e se ele usa Full;
> 3. Calculadora de margem que desconta na hora comissão (12% ou 17%), taxa fixa de R$ 6 e Simples;
> 4. Simulador de fatias de mercado (quanto você ganha se roubar 5%, 15% ou 30% desse anúncio);
> 5. Download de todas as fotos em alta resolução em 1 clique.
>
> Criei um lote de fundadores com **acesso vitalício por R$ 97 único (sem mensalidade)** para as primeiras 25 pessoas.
>
> Quem quiser testar o simulador no site ou ver como funciona, só mandar um salve aqui no privado que eu envio o link!"*

