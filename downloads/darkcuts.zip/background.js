/**
 * DarkCuts - Background Service Worker
 * Gerencia downloads nativos e licenciamento
 */

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    darkcuts_is_pro: true,
    darkcuts_plan: 'founder_vitalicio',
    darkcuts_license_key: 'DARKCUTS-VITALICIO-FOUNDER',
    darkcuts_analyzed_count: 0
  });
  console.log('[DarkCuts] Extensão instalada e ativada como Vitalício Founder!');
});

// Listener de downloads nativos para vídeos e roteiros
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'download' && message.url) {
    try {
      chrome.downloads.download({
        url: message.url,
        filename: message.filename || 'darkcut_clip.mp4',
        conflictAction: 'uniquify',
        saveAs: false
      }, (downloadId) => {
        if (chrome.runtime.lastError) {
          sendResponse({ success: false, error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ success: true, downloadId });
        }
      });
    } catch (e) {
      sendResponse({ success: false, error: e.message });
    }
    return true; // Mantém o canal aberto para resposta assíncrona
  }
});
