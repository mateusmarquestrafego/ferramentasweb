/**
 * DarkCuts - Content Script
 * Minerador Inteligente de Cortes Virais no YouTube para Canais Dark
 * FerramentasWeb Studio
 */

(function () {
  'use strict';

  let currentVideoId = null;
  let lastUrl = '';
  let activeTab = 'tab-cortes'; // tab-cortes | tab-radar
  let selectedNiche = 'futebol'; // auto-detectado dinamicamente
  let userNicheOverride = false;
  let maxDuration = 60; // 30 | 60 | 90 segundos

  // Estado do vídeo atual
  let videoData = {
    id: '',
    title: '',
    cleanTitle: '',
    channel: '',
    views: 'Carregando...',
    durationSeconds: 720,
    durationFormatted: '12:00',
    chapters: [],
    clips: []
  };

  // Estado do Radar de Sugestão de Conteúdo
  let radarSelectedNiche = 'futebol';
  let radarSearchQuery = '';
  let radarScannedVideos = [];
  let radarCurrentView = 'videos'; // 'videos' | 'pautas' | 'scanned'

  // Banco de Dados Curado de Vídeos Reais de Alta Retenção por Nicho
  const RADAR_VIRAL_VIDEOS = {
    futebol: [
      {
        id: '1f2_XJmE2bI',
        title: 'LANCES MAIS ABSURDOS DO FUTEBOL BRASILEIRO (REAÇÃO CAZÉTV)',
        channel: 'CazéTV',
        views: '4.8M visualizações',
        duration: '14:22',
        score: 99,
        darkIdea: '💡 Pauta Dark: Recorte a falta polêmica aos 04:30. Gancho: "O juiz quase perdeu o controle do jogo aqui!"'
      },
      {
        id: 'V7Pq3cI6910',
        title: 'VIRADAS HISTÓRICAS E GOLS NO ÚLTIMO MINUTO DA RODADA',
        channel: 'TNT Sports Brasil',
        views: '3.2M visualizações',
        duration: '18:45',
        score: 98,
        darkIdea: '💡 Pauta Dark: Pegue o gol da virada aos 94min e a explosão da torcida. Gancho: "Nem o narrador acreditou no que aconteceu aos 95 minutos!"'
      },
      {
        id: 'c41tq_yA8Fk',
        title: 'AS MAIORES POLÊMICAS DO VAR QUE REVOLTARAM A TORCIDA',
        channel: 'GE Globo',
        views: '2.4M visualizações',
        duration: '11:10',
        score: 97,
        darkIdea: '💡 Pauta Dark: O áudio da cabine do VAR aos 07:15. Gancho: "Vazou o áudio do VAR que ninguém podia ouvir!"'
      },
      {
        id: 'fJ9rUzIMcZQ',
        title: 'NEYMAR JR DESTRUINDO ADVERSÁRIOS COM DRIBLES HUMILHANTES',
        channel: 'Desimpedidos',
        views: '6.1M visualizações',
        duration: '09:50',
        score: 99,
        darkIdea: '💡 Pauta Dark: Três dribles seguidos no zagueiro. Gancho: "O zagueiro jurou que pegava ele, olha o que aconteceu..."'
      },
      {
        id: '03rQhP-rJ8c',
        title: 'BRIGAS ÉPICAS E DISCUSSÕES ACALORADAS ENTRE CRAQUES NO CAMPO',
        channel: 'ESPN Brasil',
        views: '1.9M visualizações',
        duration: '12:04',
        score: 96,
        darkIdea: '💡 Pauta Dark: O bate-boca entre os dois capitães. Gancho: "Eles eram amigos de infância até esse clássico começar!"'
      },
      {
        id: 'L_LUpnjgPso',
        title: 'DEFESAS MILAGROSAS QUE SALVARAM O TÍTULO NOS ACRÉSCIMOS',
        channel: 'Jovem Pan Esportes',
        views: '1.5M visualizações',
        duration: '15:30',
        score: 95,
        darkIdea: '💡 Pauta Dark: A defesa à queima-roupa com o pé. Gancho: "A física não explica como essa bola não entrou no gol!"'
      }
    ],
    podcast: [
      {
        id: 'tgbNymZ7vqY',
        title: 'REVELAÇÃO BOMBÁSTICA SOBRE OS BASTIDORES DA TELEVISÃO',
        channel: 'Podpah',
        views: '5.2M visualizações',
        duration: '2h 15m',
        score: 99,
        darkIdea: '💡 Pauta Dark: Corte aos 42min quando o convidado fala sobre o cachê proibido. Gancho: "Ele quebrou o contrato ao vivo ao revelar isso!"'
      },
      {
        id: 'kJQP7kiw5Fk',
        title: 'O MAIOR GOLPE QUE JÁ VI ACONTECER NO BRASIL (RELATO REAL)',
        channel: 'Flow Podcast',
        views: '3.9M visualizações',
        duration: '2h 40m',
        score: 98,
        darkIdea: '💡 Pauta Dark: A explicação de como o estelionato funcionava. Gancho: "Apenas 3 perguntas e eles roubaram 5 milhões de reais!"'
      },
      {
        id: '2Vv-B_34680',
        title: 'HISTÓRIAS DE OPERAÇÃO POLICIAL QUE NUNCA FORAM AO AR',
        channel: 'Inteligência Ltda',
        views: '4.7M visualizações',
        duration: '1h 55m',
        score: 99,
        darkIdea: '💡 Pauta Dark: O momento em que a equipe foi emboscada aos 28min. Gancho: "Eles sabiam que tínhamos apenas 2 minutos para sair dali!"'
      },
      {
        id: 'YQHsXMglC9A',
        title: 'COMO PERDI TUDO E DEI A VOLTA POR CIMA EM 1 ANO',
        channel: 'Ticaracaticast',
        views: '2.1M visualizações',
        duration: '1h 40m',
        score: 96,
        darkIdea: '💡 Pauta Dark: A lição sobre falsos amigos aos 51min. Gancho: "Quando a conta zerou, olha quem continuou do lado dele..."'
      },
      {
        id: 'uelHwf8o7_U',
        title: 'DETALHES PERTURBADORES DE CRIMES RESOLVIDOS PELA PERÍCIA',
        channel: 'Fala Glauber Podcast',
        views: '3.4M visualizações',
        duration: '2h 05m',
        score: 98,
        darkIdea: '💡 Pauta Dark: A descoberta da pista microscópica aos 35min. Gancho: "Um simples fio de cabelo desvendou o crime perfeito!"'
      }
    ],
    series: [
      {
        id: 'oVz483iDC8o',
        title: 'PEAKY BLINDERS: O PLANO GENIAL E FRIO DE THOMAS SHELBY',
        channel: 'Dark Series Brasil',
        views: '7.8M visualizações',
        duration: '08:15',
        score: 100,
        darkIdea: '💡 Pauta Dark: Cena do charuto e a frase "No fighting". Gancho: "A calma dele minutos antes do império dele dobrar de tamanho!"'
      },
      {
        id: '14gLpWqB5dE',
        title: 'BREAKING BAD: O DIA EM QUE WALTER WHITE CALOU O CHEFE',
        channel: 'Cenas Épicas 4K',
        views: '5.6M visualizações',
        duration: '06:40',
        score: 99,
        darkIdea: '💡 Pauta Dark: A fala "Say my name" aos 03:10. Gancho: "O momento exato em que ele percebeu que mandava em tudo!"'
      },
      {
        id: 'M7lc1UVf-VE',
        title: 'VIKINGS: O DISCURSO HISTÓRICO DE RAGNAR LODBROK',
        channel: 'Cinema & Glória',
        views: '4.2M visualizações',
        duration: '05:55',
        score: 98,
        darkIdea: '💡 Pauta Dark: O grito motivacional de guerra. Gancho: "Esse discurso motivacional faz qualquer um querer conquistar o mundo!"'
      },
      {
        id: 'Qy989K1hJ_c',
        title: 'O LOBO DE WALL STREET: DISCURSO DE VENDAS QUE MUDOU VIDAS',
        channel: 'Mindset Cinema',
        views: '6.4M visualizações',
        duration: '07:20',
        score: 99,
        darkIdea: '💡 Pauta Dark: "Venda-me esta caneta" aos 02:40. Gancho: "A técnica de persuasão proibida que 99% das pessoas não entendem!"'
      }
    ],
    politica: [
      {
        id: 'ZbZSe6N_BXs',
        title: 'DEBATE AO VIVO: A RESPOSTA DEMOLIDORA QUE CALOU O ADVERSÁRIO',
        channel: 'Bastidores de Brasília',
        views: '4.1M visualizações',
        duration: '11:30',
        score: 99,
        darkIdea: '💡 Pauta Dark: A troca de farpas e documento na mesa aos 05:20. Gancho: "Ele achou que ia vencer o debate, até esse papel aparecer!"'
      },
      {
        id: '60ItHLz5WEA',
        title: 'CPI DO SENADO: CONFRONTO DIRETO ENTRE DEPUTADO E TESTEMUNHA',
        channel: 'Fatos da Política',
        views: '3.1M visualizações',
        duration: '16:40',
        score: 97,
        darkIdea: '💡 Pauta Dark: O momento da contradição aos 09:15. Gancho: "Em menos de 30 segundos ele confessou o que negou o ano todo!"'
      },
      {
        id: 'kffacxfA7G4',
        title: 'FALA POLÊMICA NO PLENÁRIO QUE FEZ A OPOSIÇÃO ABANDONAR A SALA',
        channel: 'Congresso em Foco',
        views: '2.5M visualizações',
        duration: '08:50',
        score: 96,
        darkIdea: '💡 Pauta Dark: Discurso exaltado na tribuna. Gancho: "A verdade que nenhum político tem coragem de falar no microfone!"'
      }
    ],
    financas: [
      {
        id: 'fLexgOxsZu0',
        title: 'O SEGREDO DOS BANCOS QUE TIRA O SEU DINHEIRO TODO MÊS',
        channel: 'Primo Rico (Thiago Nigro)',
        views: '3.8M visualizações',
        duration: '19:12',
        score: 98,
        darkIdea: '💡 Pauta Dark: O cálculo dos juros ocultos aos 06:40. Gancho: "Se você tem dinheiro na poupança, você perdeu 2 mil reais esse ano!"'
      },
      {
        id: 'PT2_F-1esPk',
        title: 'O MAIOR ERRO FINANCEIRO QUE 95% DOS BRASILEIROS COMETEM',
        channel: 'Investidor Sardinha',
        views: '2.9M visualizações',
        duration: '15:45',
        score: 97,
        darkIdea: '💡 Pauta Dark: Parcelamento e financiamento ilusório. Gancho: "Comprar isso parcelado é a forma mais rápida de ficar pobre!"'
      },
      {
        id: 'C0DPdy98e4c',
        title: 'COMO UMA PESSOA COMUM PODE ACUMULAR SEU PRIMEIRO MILHÃO',
        channel: 'PrimoCast',
        views: '2.2M visualizações',
        duration: '22:10',
        score: 96,
        darkIdea: '💡 Pauta Dark: A regra dos aportes constantes aos 11:30. Gancho: "Não é quanto você ganha, é essa única regra que muda seu jogo!"'
      }
    ],
    curiosidades: [
      {
        id: 'L_LUpnjgPso',
        title: 'OS 5 LUGARES MAIS PROIBIDOS DA TERRA QUE NINGUÉM PODE PISAR',
        channel: 'Fatos Desconhecidos',
        views: '8.4M visualizações',
        duration: '13:50',
        score: 100,
        darkIdea: '💡 Pauta Dark: A Ilha das Cobras e a Ilha Sentinela do Norte. Gancho: "Qualquer pessoa que se aproximar desta ilha é abatida sem aviso!"'
      },
      {
        id: 'fJ9rUzIMcZQ',
        title: 'O QUE CIENTISTAS ENCONTRARAM NO LUGAR MAIS PROFUNDO DO OCEANO',
        channel: 'Você Sabia?',
        views: '6.7M visualizações',
        duration: '16:20',
        score: 99,
        darkIdea: '💡 Pauta Dark: A criatura misteriosa na Fossa das Marianas. Gancho: "A câmera gravou algo a 11 mil metros de profundidade que chocou os biólogos!"'
      },
      {
        id: '03rQhP-rJ8c',
        title: 'CASOS REAIS NUNCA SOLUCIONADOS REGISTRADOS EM CÂMERAS',
        channel: 'Mistérios & Fatos',
        views: '5.1M visualizações',
        duration: '12:35',
        score: 98,
        darkIdea: '💡 Pauta Dark: O desaparecimento no elevador sem saída. Gancho: "Ela entrou no elevador e simplesmente sumiu do mapa há 10 anos..."'
      }
    ],
    lutas: [
      {
        id: 'oVz483iDC8o',
        title: 'OS NOCAUTES MAIS RÁPIDOS E BRUTAIS DA HISTÓRIA DO UFC',
        channel: 'Combate Brasil',
        views: '7.2M visualizações',
        duration: '10:40',
        score: 100,
        darkIdea: '💡 Pauta Dark: Nocaute com joelhada voadora em 5 segundos. Gancho: "O juiz mal deu o início da luta e o adversário já estava apagado!"'
      },
      {
        id: 'kJQP7kiw5Fk',
        title: 'A PESAGEM MAIS TENSA DO UFC QUE QUASE VIROU BRIGA GENERALIZADA',
        channel: 'Octógono Raiz',
        views: '4.5M visualizações',
        duration: '08:25',
        score: 98,
        darkIdea: '💡 Pauta Dark: A encarada com empurrão e gritaria. Gancho: "Eles tiveram que colocar 8 seguranças entre eles para evitar o pior!"'
      }
    ],
    gringo: [
      {
        id: '0e3GPea1Tyg',
        title: 'MRBEAST: $500,000 AIRPLANE SURVIVAL CHALLENGE (WORLD RECORD)',
        channel: 'MrBeast',
        views: '92M visualizações',
        duration: '21:15',
        score: 100,
        darkIdea: '💡 Pauta Dark: Momento de alta tensão psicológica da prova. Gancho: "He was 10 seconds away from losing half a million dollars!"'
      },
      {
        id: '2Vv-B_34680',
        title: 'JOE ROGAN: PHYSICIST EXPLAINS WHAT TRULY EXISTS OUTSIDE TIME',
        channel: 'PowerfulJRE',
        views: '19M visualizações',
        duration: '18:40',
        score: 100,
        darkIdea: '💡 Pauta Dark: A teoria quântica explicada de forma simples. Gancho: "This simple concept will literally break your brain for the next 24 hours!"'
      },
      {
        id: 'kJQP7kiw5Fk',
        title: 'ANDREW HUBERMAN: THE 10 MINUTE ROUTINE THAT RESETS DOPAMINE',
        channel: 'Huberman Lab Clips',
        views: '11M visualizações',
        duration: '09:20',
        score: 99,
        darkIdea: '💡 Pauta Dark: A regra da luz solar e água gelada. Gancho: "Do this for 3 days and you will never feel tired in the morning again!"'
      }
    ]
  };

  // Banco de Dados de Pautas e Roteiros Validados para Canais Dark
  const RADAR_VIRAL_PAUTAS = {
    futebol: [
      {
        title: '🏆 TOP 3 GOLS MAIS INACREDITÁVEIS QUE DESAFIARAM A FÍSICA',
        hook: '"O segundo gol dessa lista fez até o narrador gringo perder a voz..."',
        strategy: 'Edite 3 lances rápidos (15s cada) com trilha tensa e slow motion no momento do chute.',
        soundHint: 'Use batida Phonk ou trilha dramática de percussão'
      },
      {
        title: '⚠️ O MOMENTO EXATO DA PIOR FALHA DE ZAGUEIRO NO BRASILEIRÃO',
        hook: '"Ele pediu desculpas pra torcida inteira chorando no fim do jogo..."',
        strategy: 'Mostre o erro bizarro aos 3 primeiros segundos, depois repita com zoom na reação do técnico.',
        soundHint: 'Som de silêncio súbito ou batimento cardíaco'
      },
      {
        title: '🔥 AS 3 EXPULSÕES MAIS POLÊMICAS DO VAR QUE NINGUÉM ENTENDEU',
        hook: '"Até hoje nem a CBF conseguiu explicar o que o juiz marcou aqui!"',
        strategy: 'Divida o corte entre a imagem do lance e o árbitro olhando o monitor do VAR.',
        soundHint: 'Efeito sonoro de apito e sirene suave'
      }
    ],
    podcast: [
      {
        title: '🗣️ A REVELAÇÃO BOMBÁSTICA QUE CALOU O APRESENTADOR POR 20 SEGUNDOS',
        hook: '"Ele quebrou o contrato ao vivo quando revelou esse segredo..."',
        strategy: 'Corte direto na fala polêmica com zoom gradual no rosto de quem está falando.',
        soundHint: 'Trilha de suspense e campainha sutil'
      },
      {
        title: '😱 HISTÓRIA REAL DE SOBREVIVÊNCIA: POR 5 CENTÍMETROS ELE NÃO MORREU',
        hook: '"O médico disse que era impossível alguém sobreviver àquilo..."',
        strategy: 'Comece com a frase de clímax, coloque legendas amarelas piscantes nas palavras-chave.',
        soundHint: 'Efeito de whoosh e som grave de cinema'
      }
    ],
    series: [
      {
        title: '🚬 A CENA MAIS FRIA E CALCULISTA DO CINEMA MUNDIAL',
        hook: '"A frieza dele quando percebeu que caiu numa emboscada..."',
        strategy: 'Enquadramento centralizado, filtro com contraste aumentado e legendas elegantes.',
        soundHint: 'Trilha suave de piano ou violoncelo dramático'
      }
    ],
    politica: [
      {
        title: '🏛️ O DEPUTADO QUE COLOCOU OS DADOS NA MESA E DEMOLIU O ADVERSÁRIO',
        hook: '"Ele achava que ia sair por cima, até esse papel aparecer na bancada..."',
        strategy: 'Foco na reação de desconforto do oponente enquanto os dados são lidos.',
        soundHint: 'Tique-taque de relógio e batida rápida'
      }
    ],
    financas: [
      {
        title: '💰 A TAXA INVISÍVEL DOS BANCOS QUE CORRÓI SEU DINHEIRO TODO MÊS',
        hook: '"Se você deixa dinheiro na poupança, você perdeu 2 mil reais esse ano..."',
        strategy: 'Coloque na tela a conta matemática rápida com setas vermelhas.',
        soundHint: 'Efeito de caixa registradora e erro'
      }
    ],
    curiosidades: [
      {
        title: '🚫 OS 5 LUGARES MAIS PERIGOSOS DA TERRA ONDE NINGUÉM PODE ENTRAR',
        hook: '"Se você tentar pisar nessa ilha, a marinha atira sem aviso prévio..."',
        strategy: 'Imagens de satélite com contorno vermelho nos locais proibidos.',
        soundHint: 'Trilha sinistra de mistério / Dark Ambient'
      }
    ],
    lutas: [
      {
        title: '🥊 O NOCAUTE MAIS RÁPIDO DO UFC QUE O PÚBLICO NEM PISCOU',
        hook: '"Foram apenas 4 segundos de luta, veja o que aconteceu..."',
        strategy: 'Corte sem introdução: os 4 segundos da luta em loop duas vezes com câmera lenta.',
        soundHint: 'Som de impacto pesado com eco'
      }
    ],
    gringo: [
      {
        title: '⚡ THE CRAZIEST MOMENT ON YOUTUBE HISTORY',
        hook: '"Nobody believed he could actually pull this off until the last second..."',
        strategy: 'Fast paced subtitles in english and portuguese simultaneous.',
        soundHint: 'High energy electronic beat'
      }
    ]
  };

  // Escaneia vídeos visíveis na tela atual do YouTube (Feed, Canais, Busca)
  function scanVisibleYouTubeVideos() {
    const nodes = document.querySelectorAll('ytd-video-renderer, ytd-rich-item-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer, ytd-reel-item-renderer');
    const results = [];
    const seen = new Set();

    nodes.forEach(node => {
      const titleEl = node.querySelector('#video-title, #video-title-link, a#video-title');
      const channelEl = node.querySelector('#channel-name, #text.ytd-channel-name, .ytd-channel-name, ytd-channel-name');
      const metaEls = node.querySelectorAll('#metadata-line span, .ytd-video-meta-block span');
      const linkEl = node.querySelector('a[href*="/watch?v="]');

      if (titleEl && linkEl) {
        const href = linkEl.getAttribute('href') || '';
        const match = href.match(/[?&]v=([a-zA-Z0-9_-]{11})/);
        if (match && match[1]) {
          const id = match[1];
          if (seen.has(id)) return;
          seen.add(id);

          const title = (titleEl.textContent || titleEl.getAttribute('title') || '').trim();
          const channel = channelEl ? (channelEl.textContent || '').trim() : 'Canal YouTube';
          let views = 'Em alta no YouTube';
          if (metaEls && metaEls.length > 0) {
            views = Array.from(metaEls).map(s => s.textContent.trim()).filter(Boolean).join(' • ');
          }

          results.push({
            id,
            title,
            channel,
            views: views || 'Alta retenção',
            score: Math.floor(Math.random() * 6) + 94,
            duration: 'Destaque',
            darkIdea: `💡 Pauta Dark: Clique em "Minerar" para que o DarkCuts analise os picos de replay deste vídeo!`
          });
        }
      }
    });

    return results;
  }

  // Helper universal para extrair o ID do vídeo do YouTube
  function extractYouTubeVideoId(url) {
    if (!url) return null;
    try {
      const u = new URL(url, window.location.origin);
      if (u.pathname === '/watch') {
        const v = u.searchParams.get('v');
        if (v) return v;
      } else if (u.pathname.startsWith('/shorts/')) {
        return u.pathname.split('/shorts/')[1].split('/')[0].split('?')[0];
      } else if (u.pathname.startsWith('/live/')) {
        return u.pathname.split('/live/')[1].split('/')[0].split('?')[0];
      }
    } catch (e) {}

    const match = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|(?:embed|v|shorts|live)\/))([a-zA-Z0-9_-]{11})/);
    return match ? match[1] : null;
  }

  function isWatchPage() {
    return !!extractYouTubeVideoId(window.location.href);
  }

  // Converte texto como "14:25" ou "1:20:15" em segundos
  function parseDurationText(text) {
    if (!text) return 0;
    const parts = text.trim().replace(/[^\d:]/g, '').split(':').map(Number);
    if (parts.some(isNaN) || parts.length === 0) return 0;
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    return parts[0] || 0;
  }

  function formatSeconds(sec) {
    sec = Math.max(0, Math.round(sec));
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h > 0) {
      return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  // Remove ruídos de títulos do YouTube (ex: "| CazéTV", "[AO VIVO]", "- Melhores Momentos")
  function cleanVideoTitle(title) {
    if (!title) return 'Vídeo Viral';
    return title
      .replace(/\[.*?\]|\(.*?\)/g, '')
      .replace(/\s*\|\s*.*$/g, '')
      .replace(/\s*-\s*(CazéTV|GE|Flow|Podpah|YouTube).*$/gi, '')
      .trim();
  }

  // Detector inteligente de Nicho baseado no Título, Canal e Conteúdo do Vídeo
  function detectNicheAutomatically(title, channel) {
    const text = `${title} ${channel}`.toLowerCase();

    // 1. FUTEBOL & ESPORTES
    if (
      /(gol|gols|flamengo|palmeiras|corinthians|são paulo|sao paulo|vasco|grêmio|gremio|internacional|botafogo|cruzeiro|atlético|atletico|santos|futebol|melhores momentos|brasileir|copa|libertadores|champions|lance|lances|pênalti|penalti|var|árbitro|arbitro|cazétv|cazetv|ge globo|globo esporte|tnt sports|espn|premier league|neymar|messi|cr7|cristiano ronaldo|vini jr|vinicius jr|real madrid|barcelona|seleção|selecao)/i.test(text)
    ) {
      return 'futebol';
    }

    // 2. PODCASTS & ENTREVISTAS
    if (
      /(podcast|podpah|flow|inteligência ltda|inteligencia ltda|primo cast|primocast|ticaracaticast|venus podcast|poddelas|entrevista|bate-papo|conversa com|ep\.|episódio|episodio|bancada|cortes podcast)/i.test(text)
    ) {
      return 'podcast';
    }

    // 3. SÉRIES & FILMES
    if (
      /(filme|filmes|série|serie|séries|series|cena|cenas|temporada|trailer|trecho|netflix|hbo|max|cinema|peaky blinders|breaking bad|vikings|suits|cena marcante|diálogo|dialogo)/i.test(text)
    ) {
      return 'series';
    }

    // 4. POLÍTICA & DEBATES
    if (
      /(política|politica|lula|bolsonaro|stf|senado|deputado|debate|eleição|eleicao|governo|congresso|ministro|câmara|camara|alexandre de moraes|tse|partido|opinião|opiniao)/i.test(text)
    ) {
      return 'politica';
    }

    // 5. FINANÇAS & NEGÓCIOS
    if (
      /(dinheiro|investir|investimento|ações|acoes|barsi|primo rico|thiago nigro|milionário|milionario|bilionário|bilionario|negócios|negocios|dólar|dolar|cripto|bitcoin|renda fixa|dividendos|como enriquecer|riqueza|mindset)/i.test(text)
    ) {
      return 'financas';
    }

    // 6. CONTEÚDO GRINGO
    if (
      /(the |how to|interview|podcast episode|highlights|goals|speech|vs |official video)/i.test(text) &&
      !/(futebol|brasil)/i.test(text)
    ) {
      return 'gringo';
    }

    return 'podcast'; // fallback padrão se indefinido
  }

  // Extrai capítulos reais da descrição ou do player do YouTube
  function extractChaptersFromPage() {
    const chapters = [];

    // 1. Tenta extrair da descrição (o método mais rico e comum em futebol e podcasts)
    const descEls = document.querySelectorAll(
      '#description-inline-expander, #description, ytd-text-inline-expander, #description yt-formatted-string'
    );
    for (const descEl of descEls) {
      const text = descEl.innerText || descEl.textContent || '';
      if (text.length > 20) {
        const lines = text.split('\n');
        const regex = /(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\s*[-–—:]?\s*(.+)/;
        for (const line of lines) {
          const match = line.trim().match(regex);
          if (match) {
            let sec = 0;
            if (match[1]) {
              sec = parseInt(match[1], 10) * 3600 + parseInt(match[2], 10) * 60 + parseInt(match[3], 10);
            } else {
              sec = parseInt(match[2], 10) * 60 + parseInt(match[3], 10);
            }
            const title = match[4].replace(/^[^\wÀ-ÿ]+/g, '').trim();
            if (title.length >= 3 && !chapters.some(c => Math.abs(c.sec - sec) < 15)) {
              chapters.push({ sec, title });
            }
          }
        }
      }
      if (chapters.length >= 2) break;
    }

    // 2. Tenta extrair dos marcadores nativos do YouTube
    if (chapters.length < 2) {
      const nativeChapterEls = document.querySelectorAll(
        'ytd-macro-markers-list-item-renderer, ytd-chapter-renderer'
      );
      nativeChapterEls.forEach(el => {
        const timeEl = el.querySelector('#time, .ytd-macro-markers-list-item-renderer #time');
        const titleEl = el.querySelector('#title, .ytd-macro-markers-list-item-renderer #title');
        if (timeEl && titleEl) {
          const sec = parseDurationText(timeEl.textContent);
          const title = titleEl.textContent.trim();
          if (title.length >= 3 && !chapters.some(c => Math.abs(c.sec - sec) < 15)) {
            chapters.push({ sec, title });
          }
        }
      });
    }

    return chapters.sort((a, b) => a.sec - b.sec);
  }

  // Extrai os picos matemáticos reais do gráfico "Mais reproduzido" nativo do YouTube
  function extractNativeYouTubeHeatmap(totalSec) {
    const peaks = [];
    try {
      const pathEl = document.querySelector('.ytp-heat-map-container path, path.ytp-heat-map-path');
      if (pathEl && pathEl.getAttribute('d')) {
        const d = pathEl.getAttribute('d');
        const pointRegex = /([\d\.]+)[,\s]+([\d\.]+)/g;
        let match;
        const points = [];
        while ((match = pointRegex.exec(d)) !== null) {
          const x = parseFloat(match[1]);
          const y = parseFloat(match[2]);
          if (!isNaN(x) && !isNaN(y)) points.push({ x, y });
        }

        if (points.length >= 10) {
          const maxX = Math.max(...points.map(p => p.x)) || 1000;
          for (let i = 2; i < points.length - 2; i++) {
            const pPrev = points[i - 1].y;
            const pCurr = points[i].y;
            const pNext = points[i + 1].y;
            // Ponto de mínimo no eixo Y = ponto de pico mais alto de audiência
            if (pCurr < pPrev && pCurr < pNext && pCurr < 85) {
              const ratio = points[i].x / maxX;
              const sec = Math.round(ratio * totalSec);
              const score = Math.min(99, Math.max(78, Math.round(100 - pCurr)));
              if (!peaks.some(p => Math.abs(p.sec - sec) < 30)) {
                peaks.push({ sec, score, ratio });
              }
            }
          }
        }
      }
    } catch (e) {
      console.warn('[DarkCuts] Heatmap parse notice:', e);
    }
    return peaks.sort((a, b) => b.score - a.score);
  }

  // Extrai informações reais do vídeo atual no DOM do YouTube
  function extractVideoDetails() {
    videoData.id = extractYouTubeVideoId(window.location.href) || 'unknown';

    // 1. Título do Vídeo
    const titleEl = document.querySelector(
      'h1.style-scope.ytd-watch-metadata yt-formatted-string, #title h1 yt-formatted-string, h1.ytd-video-primary-info-renderer'
    );
    if (titleEl && titleEl.textContent.trim().length > 3) {
      videoData.title = titleEl.textContent.trim();
    } else {
      videoData.title = document.title.replace(/\s*-\s*YouTube.*$/i, '').trim() || 'Vídeo do YouTube';
    }
    videoData.cleanTitle = cleanVideoTitle(videoData.title);

    // 2. Nome do Canal
    const channelEl = document.querySelector('ytd-channel-name a, #owner-name a, #channel-name a');
    if (channelEl && channelEl.textContent.trim().length > 1) {
      videoData.channel = channelEl.textContent.trim();
    } else {
      videoData.channel = 'Canal do YouTube';
    }

    // 3. Visualizações
    const viewsEl = document.querySelector(
      '#info-container span.view-count, #count yt-view-count-renderer span, ytd-video-view-count-renderer span'
    );
    if (viewsEl && viewsEl.textContent.trim().length > 1) {
      videoData.views = viewsEl.textContent.trim();
    } else {
      videoData.views = 'Alta relevância';
    }

    // 4. Duração Real do Vídeo (Múltiplas camadas de precisão)
    let detectedSeconds = 0;

    // A) Player de vídeo HTML5
    const videoEl = document.querySelector('video');
    if (videoEl && videoEl.duration && !isNaN(videoEl.duration) && videoEl.duration > 10) {
      detectedSeconds = Math.round(videoEl.duration);
    }

    // B) Texto de duração do player nativo (ex: "14:28")
    if (!detectedSeconds) {
      const durEl = document.querySelector('.ytp-time-duration');
      if (durEl && durEl.textContent) {
        detectedSeconds = parseDurationText(durEl.textContent);
      }
    }

    // C) PlayerData interno do YouTube
    if (!detectedSeconds) {
      const watchFlexy = document.querySelector('ytd-watch-flexy');
      if (watchFlexy && watchFlexy.playerData && watchFlexy.playerData.videoDetails) {
        detectedSeconds = parseInt(watchFlexy.playerData.videoDetails.lengthSeconds, 10) || 0;
      }
    }

    // D) Fallback seguro para evitar divisão por zero
    if (!detectedSeconds || detectedSeconds < 30) {
      detectedSeconds = 900; // ~15 minutos se ainda carregando
    }

    videoData.durationSeconds = detectedSeconds;
    videoData.durationFormatted = formatSeconds(detectedSeconds);

    // 5. Auto-Detecção de Nicho (se o usuário não escolheu manualmente)
    if (!userNicheOverride) {
      selectedNiche = detectNicheAutomatically(videoData.title, videoData.channel);
    }

    // 6. Extração de Capítulos / Momentos Reais
    videoData.chapters = extractChaptersFromPage();

    // 7. Mineração Cirúrgica de Cortes Virais
    mineViralClips();
  }

  // Gera cortes realistas baseados em capítulos ou distribuição inteligente de picos
  function mineViralClips() {
    const totalSec = videoData.durationSeconds || 900;
    const dur = maxDuration;
    const niche = selectedNiche;
    const cleanTitle = videoData.cleanTitle;

    // 1. TENTA EXTRAIR PICOS REAIS DO GRÁFICO "MAIS REPRODUZIDO" (HEATMAP NATIVO DO YOUTUBE)
    const heatmapPeaks = extractNativeYouTubeHeatmap(totalSec);

    // CASO 1: O YouTube possui o gráfico de Replay Spikes ativo no player
    if (heatmapPeaks && heatmapPeaks.length >= 3) {
      const templates = (nicheTemplates[niche] || nicheTemplates.futebol);
      videoData.clips = heatmapPeaks.slice(0, 8).map((peak, idx) => {
        let startSec = Math.max(0, peak.sec - 10);
        if (startSec + dur > totalSec) startSec = Math.max(0, totalSec - dur);
        const endSec = Math.min(totalSec, startSec + dur);
        const tpl = templates[idx] || templates[0];

        return {
          id: `clip_${idx + 1}`,
          rank: idx + 1,
          type: tpl.type,
          score: peak.score,
          startSec: startSec,
          endSec: endSec,
          startFormatted: formatSeconds(startSec),
          endFormatted: formatSeconds(endSec),
          durationFormatted: `${dur}s`,
          titleSuggested: tpl.title,
          hook: tpl.hook,
          copyForSocial: `${tpl.title}\n\n${tpl.hook}\n\nDeixe seu like e siga para os melhores cortes! 👇\n\n#${niche} #cortes #viral #canaldark`,
          isHeatmap: true,
          isChapter: false
        };
      });
      return;
    }

    // CASO 2: O vídeo tem capítulos reais descritos (ex: gols, lances ou pautas demarcadas)
    if (videoData.chapters && videoData.chapters.length >= 3) {
      videoData.clips = videoData.chapters.map((ch, idx) => {
        let startSec = Math.max(0, ch.sec);
        if (startSec + dur > totalSec) startSec = Math.max(0, totalSec - dur);
        const endSec = Math.min(totalSec, startSec + dur);

        let clipTitle = '';
        let clipHook = '';
        let clipType = 'Momento em Destaque';

        if (niche === 'futebol') {
          clipTitle = `⚽ ${ch.title.toUpperCase()}! (Melhores Momentos)`;
          clipHook = `"Olha o que aconteceu nesse lance: ${ch.title}!"`;
          clipType = ch.title.toLowerCase().includes('gol') ? 'Gol / Clímax' : 'Lance Decisivo';
        } else if (niche === 'podcast') {
          clipTitle = `🔥 ${ch.title.toUpperCase()}! (Corte Quente)`;
          clipHook = `"Ele revelou tudo sobre isso: ${ch.title}!"`;
          clipType = 'Pauta Quente';
        } else {
          clipTitle = `🎬 ${ch.title.toUpperCase()}`;
          clipHook = `"Veja esse trecho: ${ch.title}!"`;
          clipType = 'Trecho Marcante';
        }

        return {
          id: `clip_${idx + 1}`,
          rank: idx + 1,
          type: clipType,
          score: Math.min(99, 98 - idx * 2),
          startSec: startSec,
          endSec: endSec,
          startFormatted: formatSeconds(startSec),
          endFormatted: formatSeconds(endSec),
          durationFormatted: `${dur}s`,
          titleSuggested: clipTitle,
          hook: clipHook,
          copyForSocial: `${clipTitle}\n\n${clipHook}\n\nDeixe seu like e siga para os melhores cortes! 👇\n\n#${niche} #cortes #viral #futebol #canaldark`,
          isHeatmap: false,
          isChapter: true
        };
      });
      return;
    }

    // CASO 2: Mineração Algorítmica Inteligente (8 cortes bem distribuídos no vídeo)
    // Distribuição calculada por proporção real do tempo do vídeo
    const clipRatios = [
      { ratio: 0.08, score: 98, name: 'Abertura Eletrizante / Primeiros Lances' },
      { ratio: 0.20, score: 96, name: 'Primeiro Grande Momento de Pressão' },
      { ratio: 0.35, score: 95, name: 'Lance de Perigo / Grande Oportunidade' },
      { ratio: 0.48, score: 97, name: 'Clímax da Primeira Metade / Discussão' },
      { ratio: 0.62, score: 94, name: 'Lance Polêmico & Tensão Máxima' },
      { ratio: 0.75, score: 99, name: 'Pico de Retenção / Jogada Decisiva' },
      { ratio: 0.86, score: 93, name: 'Momento Mais Tenso da Partida' },
      { ratio: 0.94, score: 91, name: 'Desfecho / Reação Final Impressionante' }
    ];

    // Modelos dinâmicos por nicho que incorporam as informações REAIS do vídeo
    const nicheTemplates = {
      futebol: [
        {
          title: '⚽ O LANCE CAPITAL QUE DEFINIU O JOGO!',
          hook: '"Olha o que o jogador fez nesse momento! Inacreditável!"',
          type: 'Jogada Decisiva'
        },
        {
          title: '🔥 GOL INACREDITÁVEL! OLHA ONDE ESSA BOLA ENTROU!',
          hook: '"Ele acertou uma bomba de onde ninguém esperava! Que golaço!"',
          type: 'Golaço / Clímax'
        },
        {
          title: '⚠️ LANCE POLÊMICO DO VAR! FOI PÊNALTI OU NADA?',
          hook: '"A torcida ficou revoltada com essa decisão do árbitro! Você marcaria?"',
          type: 'Polêmica & Arbitragem'
        },
        {
          title: `😱 DEFESA MILAGROSA DO GOLEIRO! PRESSÃO TOTAL!`,
          hook: `"Todo mundo já estava comemorando o gol quando ele salvou em cima da linha!"`,
          type: 'Milagre do Goleiro'
        },
        {
          title: `🚨 O CLIMA ESQUENTOU EM CAMPO! CONFUSÃO E DEBATE!`,
          hook: `"Os jogadores partiram pra cima e o juiz perdeu o controle do jogo!"`,
          type: 'Confusão / Tensão'
        },
        {
          title: `🏆 JOGADA DE CRAQUE QUE DESTRUIU A DEFESA!`,
          hook: `"Drible desconcertante que deixou o marcador no chão! Veja a jogada!"`,
          type: 'Drible & Habilidade'
        },
        {
          title: `💥 ERRO BIZARRO OU GENIALIDADE? O LANCE MAIS COMENTADO!`,
          hook: `"Esse lance gerou debate no país inteiro! Como que perde um gol desse?"`,
          type: 'Lance Inacreditável'
        },
        {
          title: `⚡ FINAL HISTÓRICO! A REAÇÃO DA TORCIDA E DO BANCO!`,
          hook: `"Os minutos finais foram de pura loucura! Veja como terminou!"`,
          type: 'Fim de Jogo Épico'
        }
      ],
      podcast: [
        {
          title: `🔥 ELE REVELOU A MAIOR VERDADE QUE TENTAM ESCONDER!`,
          hook: `"O que ele disse aqui sobre o sistema vai fazer você repensar tudo..."`,
          type: 'Curiosidade & Segredo'
        },
        {
          title: `⚠️ A DECLARAÇÃO MAIS FORTE DA ENTREVISTA INTEIRA!`,
          hook: `"Eu não tenho medo do cancelamento, vou falar o que 99% tem medo de dizer..."`,
          type: 'Polêmica & Opinião Forte'
        },
        {
          title: `😱 O MOMENTO EM QUE TODO MUNDO NA MESA FICOU EM SILÊNCIO!`,
          hook: `"Quando essa história foi contada, ninguém conseguiu falar nada..."`,
          type: 'História Marcante'
        },
        {
          title: `💡 A MAIOR LIÇÃO DE VIDA QUE ELE APRENDEU NA PRÁTICA!`,
          hook: `"Se você aplicar essa regra nos próximos 6 meses, sua vida muda completamente..."`,
          type: 'Mentalidade & Sucesso'
        },
        {
          title: `🚨 BASTIDORES INÉDITOS QUE NUNCA FORAM CONTADOS ANTES!`,
          hook: `"Ele abriu o jogo sobre o que realmente aconteceu por trás das câmeras..."`,
          type: 'Bastidores Ocultos'
        },
        {
          title: `👀 QUANDO ELE DISSE ISSO, O CLIMA MUDOU COMPLETAMENTE!`,
          hook: `"A tensão tomou conta do estúdio nessa hora exata..."`,
          type: 'Momento Tenso'
        },
        {
          title: `🔥 A HISTÓRIA MAIS BIZARRA QUE ELE JÁ VIVEU!`,
          hook: `"Parece roteiro de cinema, mas aconteceu de verdade na vida dele..."`,
          type: 'História Inacreditável'
        },
        {
          title: `💥 A FRASE FINAL QUE FECHOU O EPISÓDIO COM CHAVE DE OURO!`,
          hook: `"Guarde essas palavras para o resto da sua vida..."`,
          type: 'Frase de Impacto'
        }
      ],
      series: [
        {
          title: `🎬 A CENA QUE MUDOU A HISTÓRIA INTEIRA!`,
          hook: `"A regra fria que separa quem lidera de quem obedece..."`,
          type: 'Cena Fria & Liderança'
        },
        {
          title: `🔥 ELE COLOCOU O INIMIGO NO LUGAR DELE COM 1 FRASE!`,
          hook: `"Você acha que manda aqui? Olhe para trás agora..."`,
          type: 'Diálogo Épico'
        },
        {
          title: `😱 A MAIOR REVIRAVOLTA QUE NINGUÉM IMAGINAVA!`,
          hook: `"O plano dele não era vencer hoje, era destruir tudo no final..."`,
          type: 'Reviravolta Chocante'
        },
        {
          title: `⚡ O CONFRONTO MAIS ESPERADO DA TEMPORADA!`,
          hook: `"Quando esses dois personagens ficaram cara a cara, o mundo parou..."`,
          type: 'Confronto Épico'
        },
        {
          title: `💡 A LIÇÃO MAIS PROFUNDA DO PERSONAGEM!`,
          hook: `"A dor ensina mais do que qualquer conselho que você já ouviu..."`,
          type: 'Filosofia de Vida'
        },
        {
          title: `🚨 O MOMENTO EM QUE TUDO DEU ERRADO!`,
          hook: `"A traição que ninguém estava preparado para assistir..."`,
          type: 'Traição / Clímax'
        },
        {
          title: `💥 RESPEITO SE CONQUISTA ASSIM: CENA IMPRESSIONANTE!`,
          hook: `"Ele não levantou a voz nem uma vez e venceu todos na sala..."`,
          type: 'Postura Alfa'
        },
        {
          title: `🏆 O DESFECHO ÉPICO QUE FECHOU A HISTÓRIA!`,
          hook: `"O final que fez essa cena virar uma lenda na internet..."`,
          type: 'Encerramento Lendário'
        }
      ],
      politica: [
        {
          title: `🏛️ A RESPOSTA QUE DEIXOU TODOS SEM PALAVRAS NO DEBATE!`,
          hook: `"Ele foi questionado ao vivo e respondeu com fatos incontestáveis..."`,
          type: 'Confronto Direto'
        },
        {
          title: `⚠️ O DADO REAL QUE ELES NUNCA MOSTRAM NA TELEVISÃO!`,
          hook: `"Os números que o povo precisa saber antes de opinar..."`,
          type: 'Revelação Chocante'
        },
        {
          title: `🚨 CLIMA PEGOU FOGO! VEJA A DISCUSSÃO AO VIVO!`,
          hook: `"O debate saiu do controle e precisou ser interrompido!"`,
          type: 'Discussão Inflamada'
        },
        {
          title: `🔥 A FALA MAIS POLÊMICA DO DIA! COMENTE O QUE ACHOU!`,
          hook: `"Ele não poupou ninguém e soltou o verbo ao vivo..."`,
          type: 'Opinião Quente'
        },
        {
          title: `👀 O MOMENTO EXATO EM QUE ELE FOI CONFRONTADO!`,
          hook: `"Perguntaram o que ninguém tinha coragem de perguntar..."`,
          type: 'Pergunta Difícil'
        },
        {
          title: `⚡ ELE DESMISTIFICOU O DISCURSO COM APENAS 1 PROVA!`,
          hook: `"Veja o documento que calou a oposição no plenário..."`,
          type: 'Desfecho Político'
        },
        {
          title: `💥 A REAÇÃO DO PÚBLICO FOI IMEDIATA! VEJA ISSO!`,
          hook: `"O plenário veio abaixo com essa declaração contundente..."`,
          type: 'Impacto Popular'
        },
        {
          title: `🏆 O RESUMO DEFINITIVO DO DEBATE! QUEM VENCEU?`,
          hook: `"Os principais momentos que marcaram a discussão..."`,
          type: 'Veredito Final'
        }
      ],
      financas: [
        {
          title: `💰 O MAIOR ERRO FINANCEIRO QUE 95% DAS PESSOAS COMETEM!`,
          hook: `"Se você ganha dinheiro e gasta assim, você nunca será livre..."`,
          type: 'Regra de Riqueza'
        },
        {
          title: `📈 ONDE OS BILIONÁRIOS COLOCAM O DINHEIRO EM TEMPO DE CRISE!`,
          hook: `"A estratégia dos tubarões do mercado para multiplicar patrimônio..."`,
          type: 'Investimento Secreto'
        },
        {
          title: `🚀 COMO CONSTRUIR RENDA PASSIVA MESMO COMEÇANDO DO ZERO!`,
          hook: `"Você só precisa de 3 ativos gerando caixa todo mês para nunca mais ter chefe..."`,
          type: 'Liberdade Financeira'
        },
        {
          title: `💡 A REGRA DE OURO DOS HOMENS MAIS RICOS DO MUNDO!`,
          hook: `"O dinheiro não aceita desaforo. Entenda essa lei dos juros compostos..."`,
          type: 'Mentalidade Milionária'
        },
        {
          title: `🔥 O QUE ELE FARIA SE PERDESSE TUDO HOJE E TIVESSE R$ 1.000!`,
          hook: `"O passo a passo exato para recuperar o patrimônio em 12 meses..."`,
          type: 'Plano de Ação'
        },
        {
          title: `⚠️ POR QUE A POUPANÇA E OS BANCOS ESTÃO TE FAZENDO PERDER DINHEIRO!`,
          hook: `"A taxa oculta que corrói o seu poder de compra todo ano..."`,
          type: 'Alerta Financeiro'
        },
        {
          title: `💥 A DIFERENÇA BRUTAL ENTRE QUEM PARECE RICO E QUEM É RICO!`,
          hook: `"Ostentação x Patrimônio Real: a verdade que dói..."`,
          type: 'Choque de Realidade'
        },
        {
          title: `🏆 O SEGREDO QUE ME FEZ CHEGAR NO MEU PRIMEIRO MILHÃO!`,
          hook: `"Não foi sorte e não foi herança. Foi seguir esse princípio à risca..."`,
          type: 'História de Sucesso'
        }
      ],
      gringo: [
        {
          title: `🇺🇸 CORTE GRINGO VIRAL! (Mina de ouro para traduzir no Brasil)`,
          hook: `"The biggest secret they never told you about success..."`,
          type: 'Viral Internacional'
        },
        {
          title: `🌐 CURIOSIDADE GLOBAL INACREDITÁVEL! ALTA RETENÇÃO!`,
          hook: `"What happened inside that place shocked the entire world..."`,
          type: 'Curiosidade EUA'
        },
        {
          title: `🔥 HISTÓRIA AMERICANA DE SUPERAÇÃO VIRAL!`,
          hook: `"He started with zero dollars and built an empire in 3 years..."`,
          type: 'Superação Global'
        },
        {
          title: `💡 O TRUQUE PSICOLÓGICO QUE NINGUÉM TE CONTOU!`,
          hook: `"The psychological trick that makes anyone respect you instantly..."`,
          type: 'Psicologia & Poder'
        },
        {
          title: `😱 DOCUMENTÁRIO VIRAL: O CASO QUE CHOCOU O MUNDO!`,
          hook: `"The footage they tried to delete from the internet..."`,
          type: 'Mistério & Fatos'
        },
        {
          title: `🚀 LIÇÃO DE NEGÓCIOS DE WALL STREET!`,
          hook: `"How the richest investors think during a market crash..."`,
          type: 'Wall Street Mindset'
        },
        {
          title: `⚡ O EXPERIMENTO QUE DEIXOU TODOS DE QUEIXO CAÍDO!`,
          hook: `"They tested this on 1,000 people and the result was shocking..."`,
          type: 'Ciência & Mente'
        },
        {
          title: `🏆 O MOMENTO MAIS ÉPICO DA HISTÓRIA MODERNA!`,
          hook: `"The exact second that changed everything forever..."`,
          type: 'Momento Histórico'
        }
      ]
    };

    const templates = nicheTemplates[niche] || nicheTemplates.futebol;

    videoData.clips = clipRatios.map((item, idx) => {
      const tpl = templates[idx] || templates[0];

      // Ponto de início baseado no percentual REAL do tempo total do vídeo
      let startSec = Math.floor(totalSec * item.ratio);
      if (startSec < 15) startSec = 15;
      if (startSec + dur > totalSec) startSec = Math.max(0, totalSec - dur - 10);
      const endSec = Math.min(totalSec, startSec + dur);

      return {
        id: `clip_${idx + 1}`,
        rank: idx + 1,
        type: tpl.type,
        score: item.score,
        startSec: startSec,
        endSec: endSec,
        startFormatted: formatSeconds(startSec),
        endFormatted: formatSeconds(endSec),
        durationFormatted: `${dur}s`,
        titleSuggested: tpl.title,
        hook: tpl.hook,
        copyForSocial: `${tpl.title}\n\n${tpl.hook}\n\nDeixe seu like e siga para os melhores cortes! 👇\n\n#${niche} #cortes #viral #canaldark`,
        isChapter: false
      };
    });
  }

  // Cria / Atualiza o Botão Flutuante do DarkCuts
  function renderTriggerButton() {
    let btn = document.getElementById('darkcuts-trigger-btn');
    if (!btn) {
      btn = document.createElement('div');
      btn.id = 'darkcuts-trigger-btn';
      btn.addEventListener('click', toggleSidebar);
      const parent = document.body || document.documentElement;
      if (parent) {
        parent.appendChild(btn);
      }
    }

    // Estilos inline garantem visibilidade absoluta contra qualquer camada do YouTube
    btn.style.cssText = `
      position: fixed !important;
      right: 0px !important;
      top: 220px !important;
      z-index: 2147483647 !important;
      background: linear-gradient(135deg, #7c3aed 0%, #a855f7 50%, #06b6d4 100%) !important;
      color: #ffffff !important;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
      padding: 10px 14px !important;
      border-radius: 12px 0 0 12px !important;
      box-shadow: -4px 6px 22px rgba(168, 85, 247, 0.55), 0 0 12px rgba(6, 182, 212, 0.35) !important;
      cursor: pointer !important;
      user-select: none !important;
      display: flex !important;
      flex-direction: column !important;
      gap: 2px !important;
      text-align: left !important;
      line-height: 1.25 !important;
      transition: transform 0.2s ease !important;
    `;

    const isVideo = isWatchPage();

    if (isVideo && videoData.clips && videoData.clips.length > 0) {
      const nicheIcon = {
        futebol: '⚽',
        podcast: '🎙️',
        series: '🎬',
        politica: '🏛️',
        financas: '💼',
        gringo: '🇺🇸'
      }[selectedNiche] || '🔥';

      btn.innerHTML = `
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="background: #fff; color: #7c3aed; font-size: 10px; font-weight: 900; padding: 2px 6px; border-radius: 4px;">⚡</span>
          <span style="font-weight: 900; font-size: 13px; color: #fff;">DarkCuts</span>
        </div>
        <div style="font-size: 10.5px; color: #f3e8ff; font-weight: 700; margin-top: 2px;">
          ${nicheIcon} ${videoData.clips.length} Cortes (${selectedNiche.toUpperCase()})
        </div>
        <div style="font-size: 9.5px; color: #a5f3fc; font-weight: 600; margin-top: 1px;">
          ⏱️ Duração: até ${maxDuration}s • Picos Ativos
        </div>
      `;
    } else {
      btn.innerHTML = `
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="background: #fff; color: #7c3aed; font-size: 10px; font-weight: 900; padding: 2px 6px; border-radius: 4px;">⚡</span>
          <span style="font-weight: 900; font-size: 13px; color: #fff;">DarkCuts</span>
        </div>
        <div style="font-size: 10.5px; color: #f3e8ff; font-weight: 700; margin-top: 2px;">
          🎯 Minerar Cortes
        </div>
        <div style="font-size: 9.5px; color: #a5f3fc; font-weight: 600; margin-top: 1px;">
          Abra um vídeo ou use o Radar
        </div>
      `;
    }
  }

  // Cria / Atualiza a Barra Lateral Completa
  function renderSidebar() {
    let bar = document.getElementById('darkcuts-sidebar');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'darkcuts-sidebar';
      document.body.appendChild(bar);
    }

    const nicheIcons = {
      futebol: '⚽ Futebol',
      podcast: '🎙️ Podcast',
      series: '🎬 Séries/Filmes',
      politica: '🏛️ Política',
      financas: '💼 Finanças',
      curiosidades: '🧠 Curiosidades',
      lutas: '🥊 Lutas/UFC',
      gringo: '🇺🇸 Gringo'
    };

    // Filtra e prepara vídeos e pautas para a aba de Sugestão de Conteúdo
    let radarVideos = (RADAR_VIRAL_VIDEOS[radarSelectedNiche] || RADAR_VIRAL_VIDEOS.futebol);
    if (radarCurrentView === 'scanned') {
      radarVideos = radarScannedVideos;
    }

    if (radarSearchQuery.trim()) {
      const q = radarSearchQuery.toLowerCase().trim();
      radarVideos = radarVideos.filter(v => 
        (v.title && v.title.toLowerCase().includes(q)) || 
        (v.channel && v.channel.toLowerCase().includes(q)) ||
        (v.darkIdea && v.darkIdea.toLowerCase().includes(q))
      );
    }

    const radarPautas = (RADAR_VIRAL_PAUTAS[radarSelectedNiche] || RADAR_VIRAL_PAUTAS.futebol);

    bar.innerHTML = `
      <!-- Header -->
      <div class="darkcuts-header">
        <div class="darkcuts-brand-group">
          <span class="darkcuts-logo-badge">v2.4 PRO</span>
          <div class="darkcuts-title">
            <span>DarkCuts</span>
            <span style="font-size: 10px; color: #22d3ee; background: rgba(6, 182, 212, 0.12); padding: 2px 6px; border-radius: 4px; font-weight: 800;">CANAL DARK EDITION</span>
          </div>
        </div>
        <button class="darkcuts-close-btn" id="darkcuts-close-btn">✕</button>
      </div>

      <!-- Navigation Tabs -->
      <div class="darkcuts-tabs-bar">
        <button class="darkcuts-tab-btn ${activeTab === 'tab-cortes' ? 'active' : ''}" data-target="tab-cortes">
          ✂️ Cortes Virais (${videoData.clips ? videoData.clips.length : 0})
        </button>
        <button class="darkcuts-tab-btn ${activeTab === 'tab-radar' ? 'active' : ''}" data-target="tab-radar">
          🌐 Sugestão de Conteúdo (${radarVideos.length})
        </button>
      </div>

      <!-- Scrollable Body -->
      <div class="darkcuts-body">

        <!-- Banner do Vídeo do YouTube -->
        <div class="video-banner-box">
          <div class="video-banner-meta">
            <span class="video-banner-channel">📺 ${videoData.channel || 'Canal do YouTube'}</span>
            <span>⏱️ ${videoData.durationFormatted || '--:--'}</span>
          </div>
          <div class="video-banner-title">${videoData.title ? videoData.title.slice(0, 95) : 'Nenhum vídeo em reprodução'}</div>
          <div style="font-size: 11px; color: #94a3b8; display: flex; align-items: center; justify-content: space-between; margin-top: 4px;">
            <span>👁️ ${videoData.views || '--'}</span>
            <span style="color: #34d399; font-weight: 700;">
              ${videoData.chapters && videoData.chapters.length > 0 ? `● ${videoData.chapters.length} Capítulos Reais Detectados` : (videoData.clips && videoData.clips[0] && videoData.clips[0].isHeatmap ? '🔥 Picos Reais do YouTube (Heatmap)' : '● Picos de Retenção Distribuídos')}
            </span>
          </div>
        </div>

        <div style="background: rgba(168, 85, 247, 0.12); border: 1px solid rgba(168, 85, 247, 0.35); border-radius: 8px; padding: 7px 12px; font-size: 11px; color: #f3e8ff; display: flex; align-items: center; justify-content: space-between; font-weight: 700;">
          <span>⚡ DarkCuts v2.4 (Layout Clean & Títulos Editáveis) • ${videoData.clips ? videoData.clips.length : 0} Cortes Gerados</span>
          <span style="color: #22d3ee; font-weight: 800;">${selectedNiche.toUpperCase()}</span>
        </div>

        <!-- ABA 1: CORTES VIRAIS DETECTADOS -->
        <div class="darkcuts-panel ${activeTab === 'tab-cortes' ? 'active' : ''}" id="panel-tab-cortes">
          
          <!-- FILTROS RÁPIDOS NO TOPO DA ABA (Nicho + Duração) -->
          <div class="darkcuts-card" style="padding: 12px; display: flex; flex-direction: column; gap: 10px; background: #0a0f20; border-color: rgba(168, 85, 247, 0.25);">
            
            <!-- Linha 1: Nicho -->
            <div>
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
                <span style="font-size: 10.5px; font-weight: 800; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px;">Nicho Ativo:</span>
                <span style="font-size: 11px; font-weight: 800; color: #c084fc;">${nicheIcons[selectedNiche] || selectedNiche}</span>
              </div>
              <div style="display: flex; flex-wrap: wrap; gap: 6px;">
                <button class="btn-quick-niche ${selectedNiche === 'futebol' ? 'active' : ''}" data-niche="futebol">⚽ Futebol</button>
                <button class="btn-quick-niche ${selectedNiche === 'podcast' ? 'active' : ''}" data-niche="podcast">🎙️ Podcasts</button>
                <button class="btn-quick-niche ${selectedNiche === 'series' ? 'active' : ''}" data-niche="series">🎬 Séries/Filmes</button>
                <button class="btn-quick-niche ${selectedNiche === 'politica' ? 'active' : ''}" data-niche="politica">🏛️ Política</button>
                <button class="btn-quick-niche ${selectedNiche === 'financas' ? 'active' : ''}" data-niche="financas">💼 Finanças</button>
                <button class="btn-quick-niche ${selectedNiche === 'gringo' ? 'active' : ''}" data-niche="gringo">🇺🇸 Gringo</button>
              </div>
            </div>

            <!-- Linha 2: Duração dos cortes -->
            <div style="border-top: 1px solid rgba(255,255,255,0.06); padding-top: 8px; display: flex; align-items: center; justify-content: space-between;">
              <span style="font-size: 10.5px; font-weight: 800; color: #94a3b8; text-transform: uppercase;">Duração Máxima:</span>
              <div style="display: flex; gap: 6px;">
                <button class="btn-quick-duration ${maxDuration === 30 ? 'active' : ''}" data-duration="30">⚡ 30s</button>
                <button class="btn-quick-duration ${maxDuration === 60 ? 'active' : ''}" data-duration="60">🔥 60s</button>
                <button class="btn-quick-duration ${maxDuration === 90 ? 'active' : ''}" data-duration="90">💎 90s</button>
              </div>
            </div>

          </div>

          <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 2px;">
            <span style="font-size: 12px; font-weight: 800; color: #fff;">🔥 CORTES MINERADOS (${videoData.clips ? videoData.clips.length : 0} GANCHOS):</span>
            <span style="font-size: 11px; color: #22d3ee; font-weight: 700;">Clique em ▶️ p/ pular no vídeo</span>
          </div>

          <!-- Lista de Cortes Minerados -->
          <div style="display: flex; flex-direction: column; gap: 14px;" id="clips-list-container">
            ${videoData.clips && videoData.clips.length > 0 ? videoData.clips.map(clip => `
              <div class="clip-card">
                <div class="clip-card-header">
                  <div style="display: flex; align-items: center; gap: 8px;">
                    <span class="clip-rank-badge">#${clip.rank}</span>
                    <span style="font-size: 11px; font-weight: 800; color: #c084fc;">${clip.type}</span>
                  </div>
                  <span class="clip-score-badge" style="background: rgba(34, 197, 94, 0.15); color: #4ade80; border: 1px solid rgba(34, 197, 94, 0.35); font-size: 10.5px; padding: 2px 7px; border-radius: 6px; font-weight: 800;">
                    ${clip.isHeatmap ? '🔥 Pico YouTube' : (clip.isChapter ? '📍 Capítulo' : '📊 Retenção')} ${clip.score}%
                  </span>
                </div>

                <div class="clip-timing-row">
                  <span>⏱️ ${clip.startFormatted} até ${clip.endFormatted}</span>
                  <span style="color: #94a3b8; font-size: 11px;">(${clip.durationFormatted})</span>
                </div>

                <!-- TÍTULO EDITÁVEL DO CORTE -->
                <div style="margin-bottom: 6px;">
                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 3px;">
                    <span style="font-size: 10px; font-weight: 800; color: #22d3ee; text-transform: uppercase;">✏️ Título no Vídeo (Editável):</span>
                    <span style="font-size: 9.5px; color: #94a3b8;">Aparece no topo do Reels</span>
                  </div>
                  <input type="text" 
                    class="clip-title-input" 
                    data-title-clip-id="${clip.id}" 
                    value="${clip.titleSuggested}" 
                    placeholder="Digite o título do corte..."
                    style="background: #040814; border: 1px solid rgba(168, 85, 247, 0.45); color: #ffffff; padding: 7px 10px; border-radius: 7px; font-size: 11.5px; font-weight: 700; width: 100%; box-sizing: border-box; outline: none; transition: all 0.2s;"
                  >
                </div>

                <!-- GANCHO APENAS PARA LEGENDA/COPY (NÃO SAI NO VÍDEO) -->
                <div class="clip-hook-quote" style="margin-bottom: 8px;">
                  <div style="font-size: 9px; color: #a855f7; font-weight: 800; text-transform: uppercase; margin-bottom: 2px;">💬 Gancho p/ Legenda do Post (Não aparece no vídeo):</div>
                  ${clip.hook}
                </div>

                <!-- BOTÃO PRINCIPAL: BAIXAR VÍDEO REELS (9:16 MP4) -->
                <button class="btn-clip-action btn-clip-reels" data-record-reels="${clip.id}" style="width: 100%; margin-bottom: 6px; padding: 10px 12px; font-size: 12px;">
                  <span>🎬 Baixar Vídeo Reels (9:16 MP4)</span>
                </button>

                <div class="clip-actions-grid" style="margin-bottom: 6px;">
                  <button class="btn-clip-action btn-clip-preview" data-seek-seconds="${clip.startSec}">
                    <span>▶️ Pular Player Aqui</span>
                  </button>
                  <button class="btn-clip-action btn-clip-cutter" data-cutter-clip="${clip.id}" title="Recortar em HD com 1 clique">
                    <span>⚡ Recortar HD Online</span>
                  </button>
                </div>

                <div class="clip-actions-grid">
                  <button class="btn-clip-action" data-copy-copy="${clip.id}" title="Copiar título, copy e hashtags">
                    <span>📋 Copiar Título + Copy</span>
                  </button>
                  <button class="btn-clip-action" data-download-txt="${clip.id}" style="background: rgba(255, 255, 255, 0.04); color: #94a3b8;" title="Baixar relatório em texto (.txt)">
                    <span>📄 Roteiro (.txt)</span>
                  </button>
                </div>
              </div>
            `).join('') : `
              <div style="background: rgba(255,255,255,0.03); border: 1px dashed rgba(255,255,255,0.15); border-radius: 12px; padding: 26px 16px; text-align: center;">
                <div style="font-size: 32px; margin-bottom: 8px;">🎬</div>
                <div style="font-size: 14px; font-weight: 800; color: #fff; margin-bottom: 6px;">Nenhum vídeo em reprodução</div>
                <div style="font-size: 11.5px; color: #94a3b8; line-height: 1.5; margin-bottom: 14px;">Abra qualquer vídeo de futebol, podcast ou cena no YouTube para que o DarkCuts minere os cortes na hora!</div>
                <button class="darkcuts-tab-btn active" data-target="tab-radar" style="width: auto; display: inline-flex; margin: 0 auto; padding: 8px 16px; font-size: 11.5px;">
                  🌐 Abrir Radar de Mineração
                </button>
              </div>
            `}
          </div>

        </div>

        <!-- ABA 2: RADAR DE SUGESTÃO DE CONTEÚDO VIRAL & MINERAÇÃO -->
        <div class="darkcuts-panel ${activeTab === 'tab-radar' ? 'active' : ''}" id="panel-tab-radar">
          
          <!-- BANNER PRINCIPAL COM BUSCA E ESCANEAMENTO -->
          <div class="darkcuts-card" style="border-color: rgba(6, 182, 212, 0.4); padding: 12px; background: #080d1e;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
              <div style="display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 800; color: #22d3ee;">
                <span>🌐 SUGESTÃO DE CONTEÚDO REAL:</span>
              </div>
              <span style="font-size: 10px; background: rgba(34, 197, 94, 0.15); color: #4ade80; border: 1px solid rgba(34, 197, 94, 0.35); padding: 2px 7px; border-radius: 99px; font-weight: 800;">
                ● IA ATIVA
              </span>
            </div>
            
            <p style="font-size: 11px; color: #94a3b8; margin: 0 0 10px; line-height: 1.4;">
              Vídeos reais prontos para minerar cortes com alta retenção e pautas comprovadas para canais Dark:
            </p>

            <div style="display: flex; flex-direction: column; gap: 8px;">
              <input type="text" id="radar-filter-input" placeholder="🔍 Filtrar por tema, canal ou time..." value="${radarSearchQuery}" style="background: #040814; border: 1px solid rgba(255,255,255,0.15); color: #fff; padding: 9px 12px; border-radius: 8px; font-size: 11.5px; outline: none; width: 100%; box-sizing: border-box;">

              <button id="btn-scan-current-page" style="background: linear-gradient(135deg, #7c3aed 0%, #06b6d4 100%); border: none; color: #fff; font-weight: 800; padding: 9px 12px; border-radius: 8px; font-size: 11.5px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; transition: all 0.2s;">
                <span>⚡ Escanear Vídeos Visíveis Desta Página</span>
              </button>
            </div>
          </div>

          <!-- SELETOR DE NICHOS DO RADAR -->
          <div style="display: flex; flex-direction: column; gap: 6px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <span style="font-size: 10.5px; font-weight: 800; color: #94a3b8; text-transform: uppercase;">Nicho das Sugestões:</span>
              <span style="font-size: 11px; font-weight: 800; color: #22d3ee;">${radarSelectedNiche.toUpperCase()}</span>
            </div>
            <div style="display: flex; flex-wrap: wrap; gap: 5px;">
              <button class="radar-niche-pill ${radarSelectedNiche === 'futebol' ? 'active' : ''}" data-radar-niche="futebol">⚽ Futebol</button>
              <button class="radar-niche-pill ${radarSelectedNiche === 'podcast' ? 'active' : ''}" data-radar-niche="podcast">🎙️ Podcasts</button>
              <button class="radar-niche-pill ${radarSelectedNiche === 'series' ? 'active' : ''}" data-radar-niche="series">🎬 Séries</button>
              <button class="radar-niche-pill ${radarSelectedNiche === 'politica' ? 'active' : ''}" data-radar-niche="politica">🏛️ Política</button>
              <button class="radar-niche-pill ${radarSelectedNiche === 'financas' ? 'active' : ''}" data-radar-niche="financas">💼 Finanças</button>
              <button class="radar-niche-pill ${radarSelectedNiche === 'curiosidades' ? 'active' : ''}" data-radar-niche="curiosidades">🧠 Curiosidades</button>
              <button class="radar-niche-pill ${radarSelectedNiche === 'lutas' ? 'active' : ''}" data-radar-niche="lutas">🥊 Lutas/UFC</button>
              <button class="radar-niche-pill ${radarSelectedNiche === 'gringo' ? 'active' : ''}" data-radar-niche="gringo">🇺🇸 Gringo</button>
            </div>
          </div>

          <!-- SUB-TABS: VÍDEOS vs PAUTAS -->
          <div style="display: flex; gap: 6px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 4px;">
            <button class="darkcuts-tab-btn ${radarCurrentView === 'videos' ? 'active' : ''}" data-radar-view="videos" style="flex: 1; padding: 7px 10px; font-size: 11px;">
              📺 Vídeos Sugeridos (${radarVideos.length})
            </button>
            <button class="darkcuts-tab-btn ${radarCurrentView === 'pautas' ? 'active' : ''}" data-radar-view="pautas" style="flex: 1; padding: 7px 10px; font-size: 11px;">
              💡 Pautas & Roteiros (${radarPautas.length})
            </button>
            ${radarScannedVideos.length > 0 ? `
              <button class="darkcuts-tab-btn ${radarCurrentView === 'scanned' ? 'active' : ''}" data-radar-view="scanned" style="flex: 1; padding: 7px 10px; font-size: 11px; border-color: #22d3ee; color: #22d3ee;">
                ⚡ Desta Página (${radarScannedVideos.length})
              </button>
            ` : ''}
          </div>

          <!-- CONTEÚDO DA SUB-TAB -->
          ${radarCurrentView === 'pautas' ? `
            <div style="display: flex; flex-direction: column; gap: 12px;">
              ${radarPautas.map(p => `
                <div class="radar-category-box" style="display: flex; flex-direction: column; gap: 8px;">
                  <div style="font-size: 12.5px; font-weight: 800; color: #fff; line-height: 1.35;">
                    ${p.title}
                  </div>
                  <div class="clip-hook-quote" style="margin: 0; font-size: 11.5px;">
                    ${p.hook}
                  </div>
                  <div style="font-size: 11px; color: #94a3b8; line-height: 1.4;">
                    🎯 <b>Estratégia:</b> ${p.strategy}
                  </div>
                  <div style="font-size: 10.5px; color: #a855f7; font-weight: 700;">
                    🎵 <b>Áudio Recomendado:</b> ${p.soundHint}
                  </div>
                  <button class="btn-clip-action" data-copy-pauta-full="${encodeURIComponent(`${p.title}\n\nGancho: ${p.hook}\n\nEstratégia: ${p.strategy}`)}" style="width: 100%; margin-top: 2px;">
                    <span>📋 Copiar Estrutura Desta Pauta</span>
                  </button>
                </div>
              `).join('')}
            </div>
          ` : `
            <div style="display: flex; flex-direction: column; gap: 14px;">
              ${radarVideos && radarVideos.length > 0 ? radarVideos.map(v => `
                <div class="radar-video-card">
                  <div class="radar-video-thumb-container">
                    <img src="https://i.ytimg.com/vi/${v.id}/hqdefault.jpg" class="radar-video-thumb" alt="${v.title}" onerror="this.src='https://i.ytimg.com/vi/${v.id}/mqdefault.jpg'">
                    <span class="radar-video-score">🔥 ${v.score}% Viral</span>
                    <span class="radar-video-duration">${v.duration}</span>
                  </div>

                  <div class="radar-video-body">
                    <div class="radar-video-title">${v.title}</div>
                    
                    <div class="radar-video-meta">
                      <span style="color: #cbd5e1; font-weight: 700;">📺 ${v.channel}</span>
                      <span style="color: #38bdf8; font-weight: 700;">👁️ ${v.views}</span>
                    </div>

                    <div class="radar-video-dark-idea">
                      ${v.darkIdea}
                    </div>

                    <div style="display: flex; gap: 6px; margin-top: 4px;">
                      <button class="radar-btn-mine" data-mine-video-id="${v.id}" style="flex: 1;">
                        ▶️ Minerar Este Vídeo
                      </button>
                      <button class="radar-btn-copy-idea" data-copy-idea="${encodeURIComponent(v.darkIdea)}" title="Copiar ideia de corte">
                        📋 Pauta
                      </button>
                      <a href="https://www.youtube.com/watch?v=${v.id}" target="_blank" class="radar-btn-copy-idea" style="text-decoration: none;" title="Abrir vídeo em nova aba">
                        ↗
                      </a>
                    </div>
                  </div>
                </div>
              `).join('') : `
                <div style="background: rgba(255,255,255,0.03); border: 1px dashed rgba(255,255,255,0.15); border-radius: 12px; padding: 24px 16px; text-align: center;">
                  <div style="font-size: 28px; margin-bottom: 6px;">🔎</div>
                  <div style="font-size: 13px; font-weight: 800; color: #fff; margin-bottom: 4px;">Nenhum vídeo encontrado para o filtro</div>
                  <div style="font-size: 11px; color: #94a3b8;">Tente limpar a pesquisa ou clique em "Escanear Vídeos Desta Página" para puxar os vídeos da tela atual!</div>
                </div>
              `}
            </div>
          `}

          <!-- FERRAMENTA EXTRA: BUSCADOR DIRETO NO YOUTUBE -->
          <div class="darkcuts-card" style="margin-top: 10px; border-color: rgba(255,255,255,0.1); background: #070a14;">
            <div style="display: flex; align-items: center; gap: 6px; font-size: 11px; font-weight: 800; color: #94a3b8; margin-bottom: 6px;">
              <span>🔎 BUSCA EXTERNA NO YOUTUBE:</span>
            </div>
            <div style="display: flex; gap: 6px;">
              <input type="text" id="radar-search-input" placeholder="Buscar no YouTube..." style="background: #040814; border: 1px solid rgba(255,255,255,0.15); color: #fff; padding: 8px 10px; border-radius: 6px; font-size: 11px; flex: 1; outline: none;" value="${videoData.cleanTitle !== 'Vídeo Viral' ? videoData.cleanTitle : ''}">
              <select id="radar-search-order" style="background: #040814; border: 1px solid rgba(255,255,255,0.15); color: #cbd5e1; padding: 8px; border-radius: 6px; font-size: 10.5px; outline: none;">
                <option value="views">🔥 Mais Vistos</option>
                <option value="today">⚡ Últimas 24h</option>
                <option value="week">📈 Nesta Semana</option>
              </select>
              <button id="radar-search-btn" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #fff; font-weight: 800; padding: 8px 10px; border-radius: 6px; font-size: 11px; cursor: pointer;">
                Ir ↗
              </button>
            </div>
          </div>

        </div>

      </div>

      <!-- Footer da Barra Lateral -->
      <div class="darkcuts-footer-card">
        DarkCuts Pro v2.0 • FerramentasWeb Studio • Licença Vitalícia Ativa
      </div>
    `;

    bindSidebarEvents();
  }

  // Associa eventos e botões da interface
  function bindSidebarEvents() {
    // 1. Fechar Sidebar
    const closeBtn = document.getElementById('darkcuts-close-btn');
    if (closeBtn) closeBtn.addEventListener('click', toggleSidebar);

    // 2. Alternar Abas (Cortes vs Radar)
    document.querySelectorAll('.darkcuts-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        activeTab = btn.getAttribute('data-target');
        renderSidebar();
      });
    });

    // 3. Seleção Rápida de Nicho (re-calcula cortes IMEDIATAMENTE)
    document.querySelectorAll('.btn-quick-niche').forEach(btn => {
      btn.addEventListener('click', () => {
        selectedNiche = btn.getAttribute('data-niche');
        userNicheOverride = true;
        mineViralClips();
        renderSidebar();
        renderTriggerButton();
      });
    });

    // 4. Seleção Rápida de Duração (30s, 60s, 90s)
    document.querySelectorAll('.btn-quick-duration').forEach(btn => {
      btn.addEventListener('click', () => {
        maxDuration = parseInt(btn.getAttribute('data-duration'), 10);
        mineViralClips();
        renderSidebar();
        renderTriggerButton();
      });
    });

    // 5. Pular Player do YouTube para o segundo exato
    document.querySelectorAll('[data-seek-seconds]').forEach(btn => {
      btn.addEventListener('click', () => {
        const sec = parseInt(btn.getAttribute('data-seek-seconds'), 10);
        seekYouTubePlayer(sec);
        btn.innerHTML = '<span>✅ Pulou no Vídeo!</span>';
        setTimeout(() => { btn.innerHTML = '<span>▶️ Pular Player Aqui</span>'; }, 2000);
      });
    });

    // 6. Copiar Título, Copy e Hashtags
    document.querySelectorAll('[data-copy-copy]').forEach(btn => {
      btn.addEventListener('click', () => {
        const clipId = btn.getAttribute('data-copy-copy');
        const clip = videoData.clips.find(c => c.id === clipId);
        if (clip) {
          navigator.clipboard.writeText(clip.copyForSocial).then(() => {
            btn.innerHTML = '<span>✅ Pacote Copiado com Sucesso!</span>';
            setTimeout(() => { btn.innerHTML = '<span>📋 Copiar Título + Copy + Hashtags p/ TikTok/Shorts</span>'; }, 2000);
          });
        }
      });
    });

    // 6.5. Atualização do Título do Corte em Tempo Real
    document.querySelectorAll('[data-title-clip-id]').forEach(input => {
      input.addEventListener('input', (e) => {
        const clipId = input.getAttribute('data-title-clip-id');
        const clip = videoData.clips.find(c => c.id === clipId);
        if (clip) {
          clip.titleSuggested = e.target.value.trim() || 'CORTE VIRAL';
        }
      });
    });

    // 7. Gravar e Baixar Vídeo Reels (9:16 MP4)
    document.querySelectorAll('[data-record-reels]').forEach(btn => {
      btn.addEventListener('click', () => {
        const clipId = btn.getAttribute('data-record-reels');
        const clip = videoData.clips.find(c => c.id === clipId);
        if (clip) {
          recordAndDownloadReelsClip(clip);
        }
      });
    });

    // 8. Recortar em HD Online (1 Clique)
    document.querySelectorAll('[data-cutter-clip]').forEach(btn => {
      btn.addEventListener('click', () => {
        const clipId = btn.getAttribute('data-cutter-clip');
        const clip = videoData.clips.find(c => c.id === clipId);
        if (clip) {
          openOnlineCutter(clip);
        }
      });
    });

    // 9. Baixar Pacote de Roteiro (.txt)
    document.querySelectorAll('[data-download-txt]').forEach(btn => {
      btn.addEventListener('click', () => {
        const clipId = btn.getAttribute('data-download-txt');
        const clip = videoData.clips.find(c => c.id === clipId);
        if (clip) {
          downloadClipPackage(clip);
          btn.innerHTML = '<span>✅ Roteiro Baixado!</span>';
          setTimeout(() => { btn.innerHTML = '<span>📄 Roteiro (.txt)</span>'; }, 2000);
        }
      });
    });

    // 10. Seletor de Nicho do Radar
    document.querySelectorAll('[data-radar-niche]').forEach(btn => {
      btn.addEventListener('click', () => {
        radarSelectedNiche = btn.getAttribute('data-radar-niche');
        radarCurrentView = 'videos';
        renderSidebar();
      });
    });

    // 11. Alternar Sub-abas do Radar (Vídeos vs Pautas vs Da Página)
    document.querySelectorAll('[data-radar-view]').forEach(btn => {
      btn.addEventListener('click', () => {
        radarCurrentView = btn.getAttribute('data-radar-view');
        renderSidebar();
      });
    });

    // 12. Filtro em Tempo Real no Radar
    const filterInput = document.getElementById('radar-filter-input');
    if (filterInput) {
      filterInput.addEventListener('input', (e) => {
        radarSearchQuery = e.target.value;
        renderSidebar();
        const nextInput = document.getElementById('radar-filter-input');
        if (nextInput) {
          nextInput.focus();
          nextInput.setSelectionRange(nextInput.value.length, nextInput.value.length);
        }
      });
    }

    // 13. Escanear Vídeos Desta Página do YouTube
    const scanBtn = document.getElementById('btn-scan-current-page');
    if (scanBtn) {
      scanBtn.addEventListener('click', () => {
        scanBtn.innerHTML = '<span>⏳ Escaneando página...</span>';
        setTimeout(() => {
          const found = scanVisibleYouTubeVideos();
          if (found && found.length > 0) {
            radarScannedVideos = found;
            radarCurrentView = 'scanned';
            renderSidebar();
            showDarkCutsToast(`⚡ ${found.length} vídeos reais capturados desta página!`, '#10b981');
          } else {
            showDarkCutsToast('Nenhum vídeo extra encontrado nesta tela do YouTube. Abra a página inicial ou um canal!', '#f59e0b');
            renderSidebar();
          }
        }, 300);
      });
    }

    // 14. Minerar Vídeo Selecionado no Radar
    document.querySelectorAll('[data-mine-video-id]').forEach(btn => {
      btn.addEventListener('click', () => {
        const vidId = btn.getAttribute('data-mine-video-id');
        if (vidId) {
          showDarkCutsToast('⚡ Carregando vídeo e minerando cortes...', '#06b6d4');
          activeTab = 'tab-cortes';
          window.location.href = `https://www.youtube.com/watch?v=${vidId}`;
        }
      });
    });

    // 15. Copiar Ideia de Corte do Radar
    document.querySelectorAll('[data-copy-idea]').forEach(btn => {
      btn.addEventListener('click', () => {
        const raw = btn.getAttribute('data-copy-idea');
        const idea = decodeURIComponent(raw || '');
        if (idea) {
          navigator.clipboard.writeText(idea).then(() => {
            showDarkCutsToast('📋 Pauta e ideia de corte copiada!', '#10b981');
          });
        }
      });
    });

    // 16. Copiar Estrutura Completa da Pauta
    document.querySelectorAll('[data-copy-pauta-full]').forEach(btn => {
      btn.addEventListener('click', () => {
        const raw = btn.getAttribute('data-copy-pauta-full');
        const pauta = decodeURIComponent(raw || '');
        if (pauta) {
          navigator.clipboard.writeText(pauta).then(() => {
            showDarkCutsToast('📋 Estrutura da pauta copiada!', '#10b981');
          });
        }
      });
    });

    // 17. Busca Externa Direta no YouTube
    const searchBtn = document.getElementById('radar-search-btn');
    const searchInput = document.getElementById('radar-search-input');
    const searchOrder = document.getElementById('radar-search-order');
    if (searchBtn && searchInput) {
      searchBtn.addEventListener('click', () => {
        const query = searchInput.value.trim();
        if (!query) return;

        let sp = 'CAM%253D'; // mais visualizados
        if (searchOrder && searchOrder.value === 'today') sp = 'EgIIAg%253D%253D'; // últimas 24h
        if (searchOrder && searchOrder.value === 'week') sp = 'EgIIAw%253D%253D'; // semana

        const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}&sp=${sp}`;
        window.open(url, '_blank');
      });
    }
  }

  // Pula a reprodução do player oficial do YouTube
  function seekYouTubePlayer(seconds) {
    const video = document.querySelector('video');
    if (video) {
      video.currentTime = seconds;
      video.play().catch(() => {});
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  // Notificação Toast Visual Flutuante
  function showDarkCutsToast(message, bgColor = '#10b981') {
    const oldToast = document.getElementById('darkcuts-toast');
    if (oldToast) oldToast.remove();

    const toast = document.createElement('div');
    toast.id = 'darkcuts-toast';
    toast.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: ${bgColor};
      color: #ffffff;
      padding: 12px 20px;
      border-radius: 10px;
      font-size: 12.5px;
      font-weight: 800;
      box-shadow: 0 10px 30px rgba(0,0,0,0.5);
      z-index: 2147483647;
      display: flex;
      align-items: center;
      gap: 8px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      animation: darkcutsPopIn 0.25s ease;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => { if (toast && toast.parentNode) toast.remove(); }, 4000);
  }

  // Abre cortador web externo com link no segundo exato
  function openOnlineCutter(clip) {
    const ytUrl = `https://www.youtube.com/watch?v=${videoData.id}&t=${clip.startSec}s`;
    const cutterUrl = `https://ytcutter.com/`;
    const copyText = `Vídeo: ${ytUrl}\nInício: ${clip.startFormatted} (${clip.startSec}s)\nFim: ${clip.endFormatted} (${clip.endSec}s)\nTítulo: ${clip.titleSuggested}`;
    
    navigator.clipboard.writeText(copyText).then(() => {
      showDarkCutsToast('⏱️ Link e minutagem copiados! Abrindo cortador HD...', '#06b6d4');
      window.open(cutterUrl, '_blank');
    }).catch(() => {
      window.open(cutterUrl, '_blank');
    });
  }

  // Estado global de gravação do Reels
  let activeRecording = null;

  function showRecordingProgressModal(clip) {
    hideRecordingProgressModal();

    const overlay = document.createElement('div');
    overlay.id = 'darkcuts-modal-overlay';
    overlay.innerHTML = `
      <div id="darkcuts-recording-modal">
        <div style="font-size: 38px; line-height: 1; margin-bottom: 2px;">🎬</div>
        <div style="font-size: 18px; font-weight: 800; color: #fff; line-height: 1.3;">
          Gravando Vídeo Reels (9:16)
        </div>
        <div style="font-size: 12.5px; color: #c084fc; font-weight: 700; line-height: 1.35; padding: 0 10px;">
          ${clip.titleSuggested}
        </div>
        <div style="font-size: 11px; color: #94a3b8; line-height: 1.4;">
          Capturando trecho de <b style="color: #22d3ee;">${clip.startFormatted}</b> até <b style="color: #22d3ee;">${clip.endFormatted}</b> com áudio original e layout vertical para TikTok/Shorts.
        </div>

        <div class="recording-progress-bar-container">
          <div class="recording-progress-bar-fill" id="recording-progress-fill" style="width: 0%;"></div>
        </div>

        <div style="display: flex; justify-content: space-between; font-size: 11.5px; color: #cbd5e1; font-weight: 700; padding: 0 4px;">
          <span id="recording-time-text">0.0s / ${clip.duration}s</span>
          <span id="recording-percent-text" style="color: #22d3ee;">0%</span>
        </div>

        <div style="display: flex; gap: 10px; margin-top: 6px;">
          <button class="btn-modal-finish" id="btn-modal-finish-now" style="flex: 1;">
            ⏹️ Concluir & Baixar Agora
          </button>
          <button class="btn-modal-cancel" id="btn-modal-cancel-rec">
            ❌ Cancelar
          </button>
        </div>

        <div style="font-size: 10.5px; color: #64748b; font-style: italic; line-height: 1.35;">
          💡 O player está reproduzindo o corte na tela para gravação com fidelidade máxima de imagem e som.
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    const finishBtn = document.getElementById('btn-modal-finish-now');
    const cancelBtn = document.getElementById('btn-modal-cancel-rec');

    if (finishBtn) {
      finishBtn.addEventListener('click', () => {
        if (activeRecording && activeRecording.isRecording) {
          activeRecording.stopAndExport();
        }
      });
    }

    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => {
        if (activeRecording) {
          activeRecording.cancel();
        }
      });
    }
  }

  function updateRecordingProgressModal(elapsed, total) {
    const totalSafe = Math.max(1, Number(total) || 1);
    const pct = Math.min(100, Math.max(0, Math.round((elapsed / totalSafe) * 100)));
    const fill = document.getElementById('recording-progress-fill');
    const timeText = document.getElementById('recording-time-text');
    const pctText = document.getElementById('recording-percent-text');

    if (fill) fill.style.width = pct + '%';
    if (timeText) timeText.textContent = `${elapsed.toFixed(1)}s / ${totalSafe.toFixed(0)}s`;
    if (pctText) pctText.textContent = `${pct}%`;
  }

  function hideRecordingProgressModal() {
    const existing = document.getElementById('darkcuts-modal-overlay');
    if (existing) existing.remove();
  }

  // Grava o vídeo diretamente em 9:16 com áudio e exporta o arquivo .mp4 real
  function recordAndDownloadReelsClip(clip) {
    const video = document.querySelector('video');
    if (!video) {
      alert('DarkCuts: Nenhum player de vídeo do YouTube encontrado nesta aba!');
      return;
    }

    if (activeRecording && activeRecording.isRecording) {
      alert('Já existe uma gravação de corte em andamento!');
      return;
    }

    // Abre modal de progresso
    showRecordingProgressModal(clip);

    // Canvas 9:16 vertical padrão Shorts/Reels (720x1280)
    const canvas = document.createElement('canvas');
    canvas.width = 720;
    canvas.height = 1280;
    const ctx = canvas.getContext('2d');

    // Captura stream visual do Canvas (30 FPS)
    const canvasStream = canvas.captureStream(30);

    // Captura o áudio original do player do YouTube
    let audioTracks = [];
    try {
      const vidStream = (typeof video.captureStream === 'function') 
        ? video.captureStream() 
        : (typeof video.mozCaptureStream === 'function' ? video.mozCaptureStream() : null);
      if (vidStream && vidStream.getAudioTracks().length > 0) {
        audioTracks = vidStream.getAudioTracks();
      }
    } catch (e) {
      console.warn('[DarkCuts] Áudio direto não disponível:', e);
    }

    const combinedStream = new MediaStream([...canvasStream.getVideoTracks(), ...audioTracks]);

    // Seleção de MimeType suportado pelo navegador
    const mimeCandidates = [
      'video/mp4;codecs=avc1,mp4a.40.2',
      'video/mp4;codecs=avc1',
      'video/mp4',
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm'
    ];
    let selectedMime = mimeCandidates.find(m => {
      try { return MediaRecorder.isTypeSupported(m); } catch (e) { return false; }
    }) || 'video/webm';

    let mediaRecorder = null;
    try {
      mediaRecorder = new MediaRecorder(combinedStream, {
        mimeType: selectedMime,
        videoBitsPerSecond: 3500000 // 3.5 Mbps de qualidade
      });
    } catch (err) {
      console.warn('[DarkCuts] Fallback para MediaRecorder padrão:', err);
      mediaRecorder = new MediaRecorder(combinedStream);
      selectedMime = mediaRecorder.mimeType || 'video/webm';
    }

    const recordedChunks = [];
    mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        recordedChunks.push(event.data);
      }
    };

    let animFrameId = null;
    let isRecording = true;
    let cancelled = false;

    // Helper p/ quebrar texto no Canvas de forma elegante
    function wrapText(context, text, x, y, maxWidth, lineHeight, maxLines = 3) {
      const words = (text || '').split(' ');
      let line = '';
      let currentY = y;
      let lineCount = 0;

      for (let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = context.measureText(testLine);
        if (metrics.width > maxWidth && n > 0) {
          lineCount++;
          if (lineCount >= maxLines) {
            context.fillText(line.trim() + '...', x, currentY);
            return currentY;
          }
          context.fillText(line.trim(), x, currentY);
          line = words[n] + ' ';
          currentY += lineHeight;
        } else {
          line = testLine;
        }
      }
      context.fillText(line.trim(), x, currentY);
      return currentY;
    }

    // Desenha cada quadro no formato 9:16 com elementos magnéticos de canal Dark
    function drawReelsFrame() {
      // 1. Fundo com gradiente escuro de canal Dark
      const grad = ctx.createLinearGradient(0, 0, 0, 1280);
      grad.addColorStop(0, '#060a17');
      grad.addColorStop(0.3, '#0b1329');
      grad.addColorStop(0.7, '#0b1329');
      grad.addColorStop(1, '#03060f');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 720, 1280);

      // 2. Desenho do Vídeo Centralizado (16:9)
      const vWidth = 720;
      const vAspect = (video.videoHeight && video.videoWidth) 
        ? (video.videoHeight / video.videoWidth) 
        : (9 / 16);
      const vHeight = Math.round(vWidth * vAspect);
      const vY = Math.round((1280 - vHeight) / 2);

      try {
        ctx.drawImage(video, 0, vY, vWidth, vHeight);
      } catch (err) {}

      // Bordas Luminosas do Vídeo
      ctx.strokeStyle = '#a855f7';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, vY); ctx.lineTo(720, vY);
      ctx.moveTo(0, vY + vHeight); ctx.lineTo(720, vY + vHeight);
      ctx.stroke();

      // 3. TOPO: Badge e Título Viral em Destaque
      ctx.fillStyle = 'rgba(124, 58, 237, 0.9)';
      ctx.beginPath();
      if (ctx.roundRect) {
        ctx.roundRect(240, 75, 240, 32, 16);
      } else {
        ctx.rect(240, 75, 240, 32);
      }
      ctx.fill();

      ctx.font = 'bold 12.5px sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText(`🔥 CORTE #${clip.rank} • ${selectedNiche.toUpperCase()}`, 360, 96);

      // Título Viral Limpo e Impactante (Sem parênteses, sem poluição)
      let cleanDisplayTitle = (clip.titleSuggested || videoData.title)
        .replace(/\s*\([^)]*\)\s*/g, ' ')
        .replace(/\s*\[[^\]]*\]\s*/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

      ctx.font = '900 32px "Impact", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.textAlign = 'center';
      ctx.lineWidth = 6;
      ctx.strokeStyle = '#000000';
      ctx.fillStyle = '#ffffff';

      // Quebra o título em até 3 linhas e centraliza verticalmente no topo
      const titleWords = cleanDisplayTitle.split(' ');
      const titleLines = [];
      let currentLine = '';
      for (let n = 0; n < titleWords.length; n++) {
        const testStr = currentLine ? currentLine + ' ' + titleWords[n] : titleWords[n];
        if (ctx.measureText(testStr).width > 640 && currentLine) {
          titleLines.push(currentLine);
          currentLine = titleWords[n];
          if (titleLines.length >= 3) break;
        } else {
          currentLine = testStr;
        }
      }
      if (currentLine && titleLines.length < 3) titleLines.push(currentLine);

      const titleLineHeight = 40;
      const titleCenterY = 250 - ((titleLines.length - 1) * titleLineHeight / 2);
      titleLines.forEach((tLine, idx) => {
        const yPos = titleCenterY + (idx * titleLineHeight);
        ctx.strokeText(tLine, 360, yPos);
        ctx.fillText(tLine, 360, yPos);
      });

      // 4. RODAPÉ: CTA DE ALTO IMPACTO (CURTA • COMENTE • COMPARTILHE)
      // O gancho foi completamente removido do vídeo para ficar limpo
      const ctaBoxY = vY + vHeight + 55;
      if (ctaBoxY < 1140) {
        // Card de Vidro com Borda Neon Ciano
        ctx.fillStyle = 'rgba(8, 14, 32, 0.94)';
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.85)';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        if (ctx.roundRect) {
          ctx.roundRect(45, ctaBoxY, 630, 135, 18);
        } else {
          ctx.rect(45, ctaBoxY, 630, 135);
        }
        ctx.fill();
        ctx.stroke();

        // Linha Principal em Destaque: CURTA • COMENTE • COMPARTILHE
        ctx.font = '900 24px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.lineWidth = 4;
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.85)';
        ctx.strokeText('❤️ CURTA  •  💬 COMENTE  •  ↗️ COMPARTILHE', 360, ctaBoxY + 52);
        ctx.fillText('❤️ CURTA  •  💬 COMENTE  •  ↗️ COMPARTILHE', 360, ctaBoxY + 52);

        // Linha Divisória
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(90, ctaBoxY + 76);
        ctx.lineTo(630, ctaBoxY + 76);
        ctx.stroke();

        // Linha Secundária: Incentive o Follow e Salvar
        ctx.font = 'bold 15px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        ctx.fillStyle = '#22d3ee';
        ctx.fillText('👉 SALVE ESTE VÍDEO & SIGA PARA MAIS CORTES!', 360, ctaBoxY + 108);
      }

      // Marca d\'água discreta na base
      ctx.font = 'bold 12px sans-serif';
      ctx.fillStyle = '#64748b';
      ctx.textAlign = 'center';
      ctx.fillText('🎬 CORTES EXCLUSIVOS • @DARKCUTS', 360, 1235);

      // 5. Barra de Progresso no Rodapé do Vídeo
      const duration = Math.max(1, clip.duration);
      const elapsed = Math.max(0, video.currentTime - clip.startSec);
      const progressFraction = Math.min(1, Math.max(0, elapsed / duration));

      ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.fillRect(0, 1272, 720, 8);

      const barGrad = ctx.createLinearGradient(0, 0, 720, 0);
      barGrad.addColorStop(0, '#7c3aed');
      barGrad.addColorStop(0.5, '#a855f7');
      barGrad.addColorStop(1, '#06b6d4');
      ctx.fillStyle = barGrad;
      ctx.fillRect(0, 1272, Math.round(720 * progressFraction), 8);
    }

    function renderLoop() {
      if (!isRecording) return;
      drawReelsFrame();

      const elapsed = Math.max(0, video.currentTime - clip.startSec);
      updateRecordingProgressModal(elapsed, clip.duration);

      if (video.currentTime >= clip.endSec || video.ended) {
        stopAndExport();
        return;
      }

      animFrameId = requestAnimationFrame(renderLoop);
    }

    function stopAndExport() {
      if (!isRecording) return;
      isRecording = false;
      if (animFrameId) cancelAnimationFrame(animFrameId);

      if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
      }
    }

    function cancel() {
      cancelled = true;
      isRecording = false;
      if (animFrameId) cancelAnimationFrame(animFrameId);
      if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
      }
      hideRecordingProgressModal();
      activeRecording = null;
      showDarkCutsToast('Gravação cancelada.', '#ef4444');
    }

    mediaRecorder.onstop = () => {
      hideRecordingProgressModal();
      activeRecording = null;

      if (cancelled) return;

      if (recordedChunks.length === 0) {
        alert('Erro ao gravar: nenhum frame de vídeo foi capturado.');
        return;
      }

      const mimeForBlob = selectedMime.includes('mp4') ? 'video/mp4' : 'video/webm';
      const blob = new Blob(recordedChunks, { type: mimeForBlob });
      const url = URL.createObjectURL(blob);

      const cleanTitle = (clip.titleSuggested || 'Corte_Viral')
        .replace(/[^a-zA-Z0-9À-ÿ_-]/g, '_')
        .replace(/_+/g, '_')
        .substring(0, 35);
      const filename = `DarkCut_${clip.rank}_REELS_9x16_${cleanTitle}.mp4`;

      // Dispara download do arquivo de vídeo MP4
      try {
        if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
          chrome.runtime.sendMessage({ action: 'download', url, filename }, (res) => {
            if (chrome.runtime.lastError || (res && !res.success)) {
              // Fallback DOM caso o service worker não consiga
              const a = document.createElement('a');
              a.href = url;
              a.download = filename;
              document.body.appendChild(a);
              a.click();
              a.remove();
              setTimeout(() => URL.revokeObjectURL(url), 10000);
            }
          });
          showDarkCutsToast(`🎬 Vídeo Reels 9:16 (${filename}) baixado com sucesso!`, '#10b981');
          return;
        }
      } catch (e) {}

      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);

      showDarkCutsToast(`🎬 Vídeo Reels 9:16 (${filename}) baixado com sucesso!`, '#10b981');
    };

    activeRecording = {
      isRecording: true,
      stopAndExport,
      cancel
    };

    // Pula para o início do corte e inicia reprodução
    video.currentTime = clip.startSec;
    if (video.paused) {
      video.play().catch(() => {});
    }

    // Inicia gravação após seek
    const startRecordingNow = () => {
      try {
        mediaRecorder.start(200); // 200ms chunks
        renderLoop();
      } catch (err) {
        console.error('[DarkCuts] Erro ao iniciar MediaRecorder:', err);
        hideRecordingProgressModal();
        alert('Erro ao iniciar gravação do vídeo: ' + err.message);
      }
    };

    if (Math.abs(video.currentTime - clip.startSec) < 0.5) {
      startRecordingNow();
    } else {
      video.addEventListener('seeked', function onSeek() {
        video.removeEventListener('seeked', onSeek);
        startRecordingNow();
      }, { once: true });
    }
  }

  // Gera o download do pacote do roteiro em texto
  function downloadClipPackage(clip) {
    const content = `=====================================================
DARKCUTS PRO - PACOTE DE ROTEIRO & CORTE VIRAL
=====================================================
Vídeo Original: ${videoData.title}
Canal: ${videoData.channel}
Link YouTube no Ponto: https://www.youtube.com/watch?v=${videoData.id}&t=${clip.startSec}s

-----------------------------------------------------
DETALHES DO CORTE SELECIONADO:
-----------------------------------------------------
Nicho: ${selectedNiche.toUpperCase()}
Score Viral: ${clip.score}/100 (${clip.type})
Início no Vídeo: ${clip.startFormatted} (${clip.startSec} segundos)
Fim no Vídeo: ${clip.endFormatted} (${clip.endSec} segundos)
Duração Exata: ${clip.durationFormatted}

-----------------------------------------------------
GANCHO INICIAL DE RETENÇÃO (PRIMEIROS 3 SEGUNDOS):
-----------------------------------------------------
${clip.hook}

-----------------------------------------------------
TÍTULO VIRAL SUGERIDO:
-----------------------------------------------------
${clip.titleSuggested}

-----------------------------------------------------
LEGENDA / COPY COMPLETA PARA TIKTOK, REELS & SHORTS:
-----------------------------------------------------
${clip.copyForSocial}
=====================================================
Instrução de Edição:
1. Você pode baixar o vídeo vertical 9:16 direto pelo DarkCuts.
2. Ou recortar de ${clip.startFormatted} até ${clip.endFormatted} no seu editor favorito.
3. Poste no TikTok, Reels e Shorts com a copy e hashtags acima!
=====================================================`;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const filename = `DarkCut_${clip.rank}_${selectedNiche.toUpperCase()}_${clip.startFormatted.replace(':', 'm')}s.txt`;

    try {
      if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ action: 'download', url, filename });
        return;
      }
    } catch (e) {}

    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  function toggleSidebar() {
    let bar = document.getElementById('darkcuts-sidebar');
    if (!bar) {
      if (isWatchPage()) {
        extractVideoDetails();
      } else {
        activeTab = 'tab-radar';
      }
      renderSidebar();
      bar = document.getElementById('darkcuts-sidebar');
      if (bar) bar.classList.add('active');
      return;
    }

    if (bar.classList.contains('active')) {
      bar.classList.remove('active');
    } else {
      if (isWatchPage()) {
        extractVideoDetails();
      } else {
        activeTab = 'tab-radar';
      }
      renderSidebar();
      bar.classList.add('active');
    }
  }

  // Monitor SPA do YouTube
  function checkYouTubeNavigation() {
    const currentUrl = window.location.href;
    const newId = extractYouTubeVideoId(currentUrl);

    // Garante que o botão flutuante NUNCA saia da tela
    if (!document.getElementById('darkcuts-trigger-btn')) {
      renderTriggerButton();
    }

    if (currentUrl !== lastUrl || (newId && newId !== currentVideoId)) {
      lastUrl = currentUrl;

      if (newId) {
        currentVideoId = newId;
        userNicheOverride = false; // reseta override para re-detectar automaticamente no novo vídeo

        // Aguarda carregar dados do player do YouTube
        setTimeout(() => {
          if (isWatchPage()) {
            extractVideoDetails();
            renderTriggerButton();
            const bar = document.getElementById('darkcuts-sidebar');
            if (bar && bar.classList.contains('active')) {
              renderSidebar();
            }
          }
        }, 700);

        // Segundo passe para garantir que a duração do vídeo foi carregada
        setTimeout(() => {
          if (isWatchPage()) {
            extractVideoDetails();
            renderTriggerButton();
            const bar = document.getElementById('darkcuts-sidebar');
            if (bar && bar.classList.contains('active')) {
              renderSidebar();
            }
          }
        }, 2000);
      } else {
        currentVideoId = null;
        renderTriggerButton();
      }
    }
  }

  function init() {
    // 1. Renderiza o botão flutuante imediatamente na tela
    renderTriggerButton();

    // 2. Se já for página de vídeo, minera na hora
    if (isWatchPage()) {
      currentVideoId = extractYouTubeVideoId(window.location.href);
      extractVideoDetails();
      renderTriggerButton();

      // Segundo passe após 2s para dados completos do player
      setTimeout(() => {
        extractVideoDetails();
        renderTriggerButton();
      }, 2000);
    }

    // 3. Listeners de navegação nativos do YouTube (SPA)
    window.addEventListener('yt-navigate-finish', checkYouTubeNavigation);
    window.addEventListener('yt-page-data-updated', checkYouTubeNavigation);
    window.addEventListener('spfdone', checkYouTubeNavigation);
    window.addEventListener('popstate', checkYouTubeNavigation);
    window.addEventListener('load', checkYouTubeNavigation);

    // 4. Polling frequente para garantir persistência contínua
    setInterval(checkYouTubeNavigation, 600);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  setTimeout(init, 300);

})();
