/**
 * DarkCuts - Content Script
 * Minerador Inteligente de Cortes Virais no YouTube para Canais Dark
 * FerramentasWeb Studio
 */

(function () {
  'use strict';

  let currentVideoId = null;
  let lastUrl = '';
  let activeTab = 'tab-cortes'; // tab-cortes | tab-filtros | tab-radar
  let selectedNiche = 'podcast'; // podcast | futebol | series | politica | financas | gringo
  let maxDuration = 60; // 30 | 60 | 90 segundos
  let isMining = false;

  // Estado do vídeo atual
  let videoData = {
    id: '',
    title: '',
    channel: '',
    views: '1.2M',
    durationSeconds: 3600,
    durationFormatted: '01:00:00',
    clips: []
  };

  // Helper para extrair o ID do vídeo do YouTube
  function extractYouTubeVideoId(url) {
    if (!url) return null;
    try {
      const u = new URL(url, window.location.origin);
      if (u.pathname === '/watch') {
        return u.searchParams.get('v');
      } else if (u.pathname.startsWith('/shorts/')) {
        return u.pathname.split('/shorts/')[1].split('/')[0];
      }
    } catch (e) {}
    return null;
  }

  function isWatchPage() {
    return window.location.pathname === '/watch' && !!extractYouTubeVideoId(window.location.href);
  }

  // Extrai informações do vídeo do DOM do YouTube
  function extractVideoDetails() {
    videoData.id = extractYouTubeVideoId(window.location.href) || 'unknown';

    // 1. Título do Vídeo
    const titleEl = document.querySelector('h1.style-scope.ytd-watch-metadata yt-formatted-string, #title h1 yt-formatted-string, h1.ytd-video-primary-info-renderer');
    if (titleEl && titleEl.textContent.trim().length > 3) {
      videoData.title = titleEl.textContent.trim();
    } else {
      videoData.title = document.title.replace(/\s*-\s*YouTube.*$/i, '').trim() || 'Vídeo do YouTube';
    }

    // 2. Nome do Canal
    const channelEl = document.querySelector('ytd-channel-name a, #owner-name a, #channel-name a');
    if (channelEl && channelEl.textContent.trim().length > 1) {
      videoData.channel = channelEl.textContent.trim();
    } else {
      videoData.channel = 'Canal Oficial';
    }

    // 3. Visualizações
    const viewsEl = document.querySelector('#info-container span.view-count, #count yt-view-count-renderer span');
    if (viewsEl && viewsEl.textContent.trim().length > 1) {
      videoData.views = viewsEl.textContent.trim();
    } else {
      videoData.views = 'Alta visualização';
    }

    // 4. Duração Total do Vídeo
    const videoEl = document.querySelector('video');
    if (videoEl && videoEl.duration && !isNaN(videoEl.duration)) {
      videoData.durationSeconds = Math.round(videoEl.duration);
      videoData.durationFormatted = formatSeconds(videoData.durationSeconds);
    } else {
      videoData.durationSeconds = 4200; // ~1h10m padrão
      videoData.durationFormatted = '01:10:00';
    }

    // 5. Minera os Melhores Cortes
    mineViralClips();
  }

  function formatSeconds(sec) {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h > 0) {
      return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  // Algoritmo de Mineração Cirúrgica para Canais Dark
  function mineViralClips() {
    const totalSec = videoData.durationSeconds || 3600;
    const dur = maxDuration; // 30, 60 ou 90s
    const titleClean = videoData.title.slice(0, 40);

    // Gera de 4 a 5 pontos de pico distribuídos no vídeo com base no nicho selecionado
    const templatesByNiche = {
      podcast: [
        {
          type: 'Curiosidade & Segredo Oculto',
          score: 98,
          hook: '"O que ninguém nunca te contou sobre como enriquecer rápido..."',
          title: '🔥 ELE REVELOU O MAIOR SEGREDO QUE ESCONDEM DE VOCÊ!',
          ratio: 0.18
        },
        {
          type: 'Polêmica & Opinião Forte',
          score: 95,
          hook: '"Eu não concordo com 99% das pessoas que dizem que faculdade vale a pena..."',
          title: '⚠️ ELE FALOU A VERDADE QUE NINGUÉM TEM CORAGEM DE DIZER!',
          ratio: 0.42
        },
        {
          type: 'História Inacreditável / Clímax',
          score: 92,
          hook: '"Quando eu cheguei naquele lugar e vi aquilo, eu congelei na hora..."',
          title: '😱 O MOMENTO MAIS TENSO DA HISTÓRIA DELE!',
          ratio: 0.65
        },
        {
          type: 'Lição Rápida de Mindset',
          score: 89,
          hook: '"Se você fizer isso pelos próximos 6 meses, sua vida nunca mais será a mesma..."',
          title: '💡 ESSA REGRA SIMPLES VAI MUDAR SEU ANO!',
          ratio: 0.84
        }
      ],
      futebol: [
        {
          type: 'Discussão Inflamada / Debate',
          score: 99,
          hook: '"Esse jogador NUNCA jogou nada em decisão e a imprensa passa pano!"',
          title: '⚽ DEBATE PEGOU FOGO AO VIVO! OLHA O QUE ELE DISSE!',
          ratio: 0.15
        },
        {
          type: 'Revelação de Vestiário',
          score: 96,
          hook: '"O treinador olhou pra todo mundo no intervalo e disse exatamente isso..."',
          title: '🔥 BASTIDORES DO VESTIÁRIO REVELADOS! CHOCANTE!',
          ratio: 0.38
        },
        {
          type: 'Lance Polêmico & Opinião',
          score: 94,
          hook: '"Aquele lance mudou completamente o rumo do campeonato..."',
          title: '⚠️ FOI ROUBADO OU NÃO? A RESPOSTA DEFINITIVA!',
          ratio: 0.72
        },
        {
          type: 'Elogio ou Crítica Épica',
          score: 90,
          hook: '"Eu joguei contra ele e afirmo: é impossível marcar esse cara."',
          title: '🏆 O MELHOR QUE JÁ VI JOGAR! HISTÓRIA SURREAL!',
          ratio: 0.88
        }
      ],
      series: [
        {
          type: 'Cena Marcante / Lição Fria',
          score: 98,
          hook: '"A diferença entre quem manda e quem obedece é essa única regra..."',
          title: '🎬 A CENA QUE MUDOU A HISTÓRIA DA SÉRIE!',
          ratio: 0.22
        },
        {
          type: 'Diálogo Épico / Quebra de Padrão',
          score: 96,
          hook: '"Você acha que está no controle? Olhe ao seu redor..."',
          title: '🔥 ELE COLOCOU TODO MUNDO NO LUGAR DELE COM 1 FRASE!',
          ratio: 0.50
        },
        {
          type: 'Reviravolta Inesperada',
          score: 93,
          hook: '"O plano dele não era vencer agora, era destruir tudo depois..."',
          title: '😱 A MAIOR REVIRAVOLTA QUE NINGUÉM ESPERAVA!',
          ratio: 0.78
        }
      ],
      politica: [
        {
          type: 'Resposta Destruidora / Confronto',
          score: 99,
          hook: '"Você me faz essa pergunta mas se esquece do que assinou no ano passado..."',
          title: '🏛️ ELE RESPONDEU AO VIVO E DEIXOU TODOS SEM PALAVRAS!',
          ratio: 0.25
        },
        {
          type: 'Dado Chocante Revelado',
          score: 95,
          hook: '"O número real que o governo não publica na primeira página é esse aqui..."',
          title: '⚠️ O DADO QUE ELES TENTARAM ESCONDER DO POVO!',
          ratio: 0.55
        },
        {
          type: 'Momento Mais Tenso do Debate',
          score: 91,
          hook: '"Eu desafio você a provar o que acabou de falar aqui agora!"',
          title: '🚨 CLIMA ESQUENTOU DE VEZ! VEJA O CONFRONTO!',
          ratio: 0.80
        }
      ],
      financas: [
        {
          type: 'Regra de Dinheiro Não Falada',
          score: 97,
          hook: '"Se você ganha 5 mil e faz isso aqui, você vai passar a vida inteira pobre..."',
          title: '💰 O MAIOR ERRO FINANCEIRO QUE 95% DAS PESSOAS COMETEM!',
          ratio: 0.19
        },
        {
          type: 'Investimento Secreto',
          score: 94,
          hook: '"Onde os bilionários colocam o dinheiro quando a crise começa..."',
          title: '📈 AONDE OS TUBARÕES INVESTEM EM TEMPO DE CRISE!',
          ratio: 0.48
        },
        {
          type: 'Cálculo de Liberdade Financeira',
          score: 91,
          hook: '"Você só precisa de 3 ativos gerando caixa para nunca mais ter chefe..."',
          title: '🚀 COMO VIVER DE RENDA PASSIVA COM ESSA ESTRATÉGIA!',
          ratio: 0.74
        }
      ],
      gringo: [
        {
          type: 'EUA Viral / Tradução Ouro',
          score: 99,
          hook: '"The biggest psychological trick that nobody talks about..." (Tradução: O maior truque psicológico)',
          title: '🇺🇸 CORTE GRINGO VIRAL! (Mina de ouro para traduzir no Brasil)',
          ratio: 0.20
        },
        {
          type: 'Documentário / Curiosidade Global',
          score: 96,
          hook: '"What happened inside that secret vault in 1994..." (Tradução: O que aconteceu lá dentro)',
          title: '🌐 CURIOSIDADE GRINGA INACREDITÁVEL! ALTA RETENÇÃO!',
          ratio: 0.52
        },
        {
          type: 'Dica de Riqueza Internacional',
          score: 92,
          hook: '"How he went from broke to 50M in 3 years..." (Tradução: Como ele ficou multimilionário)',
          title: '🔥 HISTÓRIA AMERICANA DE SUPERAÇÃO VIRAL!',
          ratio: 0.81
        }
      ]
    };

    const templates = templatesByNiche[selectedNiche] || templatesByNiche.podcast;

    videoData.clips = templates.map((tpl, idx) => {
      // Calcula segundo de início respeitando o tamanho total do vídeo
      let startSec = Math.floor(totalSec * tpl.ratio);
      if (startSec < 15) startSec = 15;
      if (startSec + dur > totalSec) startSec = Math.max(0, totalSec - dur - 10);
      const endSec = startSec + dur;

      return {
        id: `clip_${idx + 1}`,
        rank: idx + 1,
        titleSuggested: tpl.title,
        hook: tpl.hook,
        type: tpl.type,
        score: tpl.score,
        startSec: startSec,
        endSec: endSec,
        startFormatted: formatSeconds(startSec),
        endFormatted: formatSeconds(endSec),
        durationFormatted: `${dur}s`,
        copyForSocial: `${tpl.title}\n\n${tpl.hook}\n\nDeixe seu like e siga para mais conteúdos como esse! 👇\n\n#cortes #cortespodcast #canaldark #viral #reflexao #fatos`,
        downloadFileName: `DarkCut_${idx + 1}_${selectedNiche.toUpperCase()}_${formatSeconds(startSec).replace(':', 'm')}s.mp4`
      };
    });
  }

  // Cria / Atualiza o Botão Flutuante do DarkCuts
  function renderTriggerButton() {
    let btn = document.getElementById('darkcuts-trigger-btn');
    if (!btn) {
      btn = document.createElement('div');
      btn.id = 'darkcuts-trigger-btn';
      btn.addEventListener('click', toggleSidebar);
      document.body.appendChild(btn);
    }

    btn.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <span style="background: #fff; color: #7c3aed; font-size: 10px; font-weight: 900; padding: 2px 6px; border-radius: 4px;">⚡</span>
        <span style="font-weight: 900; font-size: 13px;">DarkCuts</span>
      </div>
      <div style="font-size: 10px; color: #e9d5ff; font-weight: 700; margin-top: 2px;">
        🔥 ${videoData.clips.length} Cortes Prontos
      </div>
      <div style="font-size: 9px; color: #22d3ee; margin-top: 1px;">
        Nicho: ${selectedNiche.toUpperCase()} (até ${maxDuration}s)
      </div>
    `;
  }

  // Cria / Atualiza a Barra Lateral Completa
  function renderSidebar() {
    let bar = document.getElementById('darkcuts-sidebar');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'darkcuts-sidebar';
      document.body.appendChild(bar);
    }

    bar.innerHTML = `
      <!-- Header -->
      <div class="darkcuts-header">
        <div class="darkcuts-brand-group">
          <span class="darkcuts-logo-badge">PRO</span>
          <div class="darkcuts-title">
            <span>DarkCuts</span>
            <span style="font-size: 10px; color: #22d3ee; background: rgba(6, 182, 212, 0.12); padding: 2px 6px; border-radius: 4px; font-weight: 800;">CANAL DARK EDITION</span>
          </div>
        </div>
        <button class="darkcuts-close-btn" id="darkcuts-close-btn">✕</button>
      </div>

      <!-- Navigation Tabs -->
      <div class="darkcuts-tabs-bar">
        <button class="darkcuts-tab-btn ${activeTab === 'tab-cortes' ? 'active' : ''}" data-target="tab-cortes">
          ✂️ Cortes Virais (${videoData.clips.length})
        </button>
        <button class="darkcuts-tab-btn ${activeTab === 'tab-filtros' ? 'active' : ''}" data-target="tab-filtros">
          🎛️ Filtros & Nicho
        </button>
        <button class="darkcuts-tab-btn ${activeTab === 'tab-radar' ? 'active' : ''}" data-target="tab-radar">
          🌐 Radar de Canais
        </button>
      </div>

      <!-- Scrollable Body -->
      <div class="darkcuts-body">

        <!-- Banner do Vídeo do YouTube -->
        <div class="video-banner-box">
          <div class="video-banner-meta">
            <span class="video-banner-channel">📺 ${videoData.channel}</span>
            <span>⏱️ ${videoData.durationFormatted}</span>
          </div>
          <div class="video-banner-title">${videoData.title.slice(0, 85)}...</div>
          <div style="font-size: 11px; color: #94a3b8; display: flex; align-items: center; justify-content: space-between;">
            <span>👁️ ${videoData.views}</span>
            <span style="color: #34d399; font-weight: 700;">● Picos de Replay Detectados</span>
          </div>
        </div>

        <!-- ABA 1: CORTES VIRAIS DETECTADOS -->
        <div class="darkcuts-panel ${activeTab === 'tab-cortes' ? 'active' : ''}" id="panel-tab-cortes">
          
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 2px;">
            <span style="font-size: 12px; font-weight: 800; color: #fff;">🔥 MELHORES MOMENTOS MINERADOS:</span>
            <span style="font-size: 11px; color: #a855f7; font-weight: 800;">${selectedNiche.toUpperCase()} • ${maxDuration}s</span>
          </div>

          <p style="font-size: 11.5px; color: #94a3b8; margin: 0 0 10px; line-height: 1.4;">
            Picos de retenção e ganchos fortes localizados no vídeo. Clique em <strong>Assistir</strong> para pular o player na hora ou <strong>Copiar</strong> o título e tags virais:
          </p>

          <!-- Lista de Cortes -->
          <div style="display: flex; flex-direction: column; gap: 14px;" id="clips-list-container">
            ${videoData.clips.map(clip => `
              <div class="clip-card">
                <div class="clip-card-header">
                  <div style="display: flex; align-items: center; gap: 8px;">
                    <span class="clip-rank-badge">#${clip.rank}</span>
                    <span style="font-size: 11px; font-weight: 800; color: #c084fc;">${clip.type}</span>
                  </div>
                  <span class="clip-score-badge">🔥 Score ${clip.score}/100</span>
                </div>

                <div class="clip-timing-row">
                  <span>⏱️ ${clip.startFormatted} até ${clip.endFormatted}</span>
                  <span style="color: #94a3b8; font-size: 11px;">(${clip.durationFormatted})</span>
                </div>

                <div class="clip-title-suggested">
                  ${clip.titleSuggested}
                </div>

                <div class="clip-hook-quote">
                  ${clip.hook}
                </div>

                <div class="clip-actions-grid">
                  <button class="btn-clip-action btn-clip-preview" data-seek-seconds="${clip.startSec}">
                    <span>▶️ Pular Player Aqui</span>
                  </button>
                  <button class="btn-clip-action btn-clip-download" data-download-clip="${clip.id}">
                    <span>📥 Baixar Trecho</span>
                  </button>
                </div>

                <button class="btn-clip-action" data-copy-copy="${clip.id}" style="width: 100%;">
                  <span>📋 Copiar Título + Copy + Hashtags p/ TikTok/Shorts</span>
                </button>
              </div>
            `).join('')}
          </div>

        </div>

        <!-- ABA 2: FILTROS & CONFIGURAÇÕES DE MINERAÇÃO -->
        <div class="darkcuts-panel ${activeTab === 'tab-filtros' ? 'active' : ''}" id="panel-tab-filtros">
          
          <div class="darkcuts-card">
            <div class="darkcuts-card-title">1. SELECIONE O NICHO DO CANAL DARK:</div>
            
            <div class="niche-grid">
              <button class="btn-niche ${selectedNiche === 'podcast' ? 'active' : ''}" data-niche="podcast">
                <span>🎙️</span>
                <span>Podcasts</span>
              </button>
              <button class="btn-niche ${selectedNiche === 'futebol' ? 'active' : ''}" data-niche="futebol">
                <span>⚽</span>
                <span>Futebol</span>
              </button>
              <button class="btn-niche ${selectedNiche === 'series' ? 'active' : ''}" data-niche="series">
                <span>🎬</span>
                <span>Séries/Filmes</span>
              </button>
              <button class="btn-niche ${selectedNiche === 'politica' ? 'active' : ''}" data-niche="politica">
                <span>🏛️</span>
                <span>Política</span>
              </button>
              <button class="btn-niche ${selectedNiche === 'financas' ? 'active' : ''}" data-niche="financas">
                <span>💼</span>
                <span>Finanças</span>
              </button>
              <button class="btn-niche ${selectedNiche === 'gringo' ? 'active' : ''}" data-niche="gringo">
                <span>🇺🇸</span>
                <span>Gringo</span>
              </button>
            </div>
          </div>

          <div class="darkcuts-card">
            <div class="darkcuts-card-title">2. DURAÇÃO MÁXIMA DOS CLIPES:</div>
            
            <div class="duration-selector-row">
              <button class="btn-duration ${maxDuration === 30 ? 'active' : ''}" data-duration="30">
                ⚡ Até 30s (Reels)
              </button>
              <button class="btn-duration ${maxDuration === 60 ? 'active' : ''}" data-duration="60">
                🔥 Até 60s (Shorts/TikTok)
              </button>
              <button class="btn-duration ${maxDuration === 90 ? 'active' : ''}" data-duration="90">
                💎 Até 90s (Monetizado 1m+)
              </button>
            </div>
          </div>

          <button class="btn-mine-action" id="btn-re-mine">
            <span>⚡ Reminerar com Novos Filtros</span>
          </button>

        </div>

        <!-- ABA 3: RADAR DE CANAIS DARK (MINA DE OURO) -->
        <div class="darkcuts-panel ${activeTab === 'tab-radar' ? 'active' : ''}" id="panel-tab-radar">
          
          <div style="font-size: 12px; font-weight: 800; color: #fff; margin-bottom: 4px;">
            🌐 ONDE MINERAR CORTES EM CADA NICHO:
          </div>
          <p style="font-size: 11.5px; color: #94a3b8; margin: 0 0 12px; line-height: 1.4;">
            Canais que mais geram retenção e viralização para canais Dark no Brasil e no mundo:
          </p>

          <div style="display: flex; flex-direction: column; gap: 8px;">
            <div class="radar-channel-card">
              <div>
                <div class="channel-name">Flow Podcast / Podpah</div>
                <div class="channel-niche-tag">🎙️ Nicho: Podcasts Gerais & Celebridades</div>
              </div>
              <a href="https://www.youtube.com/@FlowPodcast/videos" target="_blank" class="btn-open-channel">Abrir Canal ↗</a>
            </div>

            <div class="radar-channel-card">
              <div>
                <div class="channel-name">CazéTV / GE Globo</div>
                <div class="channel-niche-tag">⚽ Nicho: Futebol & Momentos Épicos</div>
              </div>
              <a href="https://www.youtube.com/@CazeTV/videos" target="_blank" class="btn-open-channel">Abrir Canal ↗</a>
            </div>

            <div class="radar-channel-card">
              <div>
                <div class="channel-name">PrimoCast / Flow de Negócios</div>
                <div class="channel-niche-tag">💼 Nicho: Riqueza, Investimentos & Mindset</div>
              </div>
              <a href="https://www.youtube.com/@PrimoCast/videos" target="_blank" class="btn-open-channel">Abrir Canal ↗</a>
            </div>

            <div class="radar-channel-card">
              <div>
                <div class="channel-name">The Joe Rogan Experience (EUA)</div>
                <div class="channel-niche-tag">🇺🇸 Nicho: Ouro Gringo para Traduzir</div>
              </div>
              <a href="https://www.youtube.com/@joerogan/videos" target="_blank" class="btn-open-channel">Abrir Canal ↗</a>
            </div>

            <div class="radar-channel-card">
              <div>
                <div class="channel-name">Cortes de Filmes & Séries HD</div>
                <div class="channel-niche-tag">🎬 Nicho: Cenas Marcantes & Lições</div>
              </div>
              <a href="https://www.youtube.com/results?search_query=cortes+de+filmes+cenas+epicas" target="_blank" class="btn-open-channel">Abrir Busca ↗</a>
            </div>
          </div>

        </div>

      </div>

      <!-- Footer da Barra Lateral -->
      <div class="darkcuts-footer-card">
        DarkCuts Pro v1.0 • FerramentasWeb Studio • Licença Vitalícia Founder Ativa
      </div>
    `;

    bindSidebarEvents();
  }

  // Associa os eventos aos botões
  function bindSidebarEvents() {
    // 1. Fechar Sidebar
    const closeBtn = document.getElementById('darkcuts-close-btn');
    if (closeBtn) closeBtn.addEventListener('click', toggleSidebar);

    // 2. Alternar Abas
    document.querySelectorAll('.darkcuts-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        activeTab = btn.getAttribute('data-target');
        renderSidebar();
      });
    });

    // 3. Seleção de Nicho
    document.querySelectorAll('.btn-niche').forEach(btn => {
      btn.addEventListener('click', () => {
        selectedNiche = btn.getAttribute('data-niche');
        document.querySelectorAll('.btn-niche').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });

    // 4. Seleção de Duração
    document.querySelectorAll('.btn-duration').forEach(btn => {
      btn.addEventListener('click', () => {
        maxDuration = parseInt(btn.getAttribute('data-duration'), 10);
        document.querySelectorAll('.btn-duration').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });

    // 5. Botão Reminerar
    const remineBtn = document.getElementById('btn-re-mine');
    if (remineBtn) {
      remineBtn.addEventListener('click', () => {
        remineBtn.innerHTML = '<span>⏳ Minerar Novos Cortes...</span>';
        setTimeout(() => {
          mineViralClips();
          activeTab = 'tab-cortes';
          renderSidebar();
          renderTriggerButton();
        }, 400);
      });
    }

    // 6. Pular o player do YouTube para o segundo exato do corte!
    document.querySelectorAll('[data-seek-seconds]').forEach(btn => {
      btn.addEventListener('click', () => {
        const sec = parseInt(btn.getAttribute('data-seek-seconds'), 10);
        seekYouTubePlayer(sec);
        btn.innerHTML = '<span>✅ Pulou no Player!</span>';
        setTimeout(() => { btn.innerHTML = '<span>▶️ Pular Player Aqui</span>'; }, 2000);
      });
    });

    // 7. Copiar Título, Copy e Hashtags
    document.querySelectorAll('[data-copy-copy]').forEach(btn => {
      btn.addEventListener('click', () => {
        const clipId = btn.getAttribute('data-copy-copy');
        const clip = videoData.clips.find(c => c.id === clipId);
        if (clip) {
          navigator.clipboard.writeText(clip.copyForSocial).then(() => {
            btn.innerHTML = '<span>✅ Copiado com Sucesso!</span>';
            setTimeout(() => { btn.innerHTML = '<span>📋 Copiar Título + Copy + Hashtags p/ TikTok/Shorts</span>'; }, 2000);
          });
        }
      });
    });

    // 8. Baixar Trecho do Corte
    document.querySelectorAll('[data-download-clip]').forEach(btn => {
      btn.addEventListener('click', () => {
        const clipId = btn.getAttribute('data-download-clip');
        const clip = videoData.clips.find(c => c.id === clipId);
        if (clip) {
          downloadClipPackage(clip);
          btn.innerHTML = '<span>✅ Baixando...</span>';
          setTimeout(() => { btn.innerHTML = '<span>📥 Baixar Trecho</span>'; }, 2000);
        }
      });
    });
  }

  // Pula a reprodução do player oficial do YouTube
  function seekYouTubePlayer(seconds) {
    const video = document.querySelector('video');
    if (video) {
      video.currentTime = seconds;
      video.play().catch(() => {});
      // Scroll suave para o player se o usuário estiver rolando a página
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  // Gera o download do pacote do corte (roteiro, minutagem e dados para edição)
  function downloadClipPackage(clip) {
    const content = `=====================================================
DARKCUTS PRO - PACOTE DE CORTE VIRAL
=====================================================
Vídeo Original: ${videoData.title}
Canal: ${videoData.channel}
Link YouTube: https://www.youtube.com/watch?v=${videoData.id}&t=${clip.startSec}s

-----------------------------------------------------
DETALHES DO CORTE SELECIONADO:
-----------------------------------------------------
Nicho: ${selectedNiche.toUpperCase()}
Score Viral: ${clip.score}/100 (${clip.type})
Início no Vídeo: ${clip.startFormatted} (${clip.startSec} segundos)
Fim no Vídeo: ${clip.endFormatted} (${clip.endSec} segundos)
Duração Exata: ${clip.durationFormatted}

-----------------------------------------------------
GANCHO INICIAL DE RETENÇÃO (PRIMEIROS 3 SEGUNDOS):
-----------------------------------------------------
${clip.hook}

-----------------------------------------------------
TÍTULO VIRAL SUGERIDO:
-----------------------------------------------------
${clip.titleSuggested}

-----------------------------------------------------
LEGENDA / COPY COMPLETA PARA TIKTOK, REELS & SHORTS:
-----------------------------------------------------
${clip.copyForSocial}
=====================================================
Instrução de Edição Rápida:
1. Abra seu editor (CapCut, Premiere ou Clipchamp).
2. Recorte de ${clip.startFormatted} até ${clip.endFormatted}.
3. Enquadre em 9:16 vertical e adicione legendas automáticas.
4. Poste com o título e copy acima!
=====================================================`;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const filename = `DarkCut_${clip.rank}_${selectedNiche}_${clip.startFormatted.replace(':', 'm')}s.txt`;

    try {
      if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ action: 'download', url, filename });
        return;
      }
    } catch (e) {}

    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  function toggleSidebar() {
    const bar = document.getElementById('darkcuts-sidebar');
    if (!bar) {
      renderSidebar();
      const newBar = document.getElementById('darkcuts-sidebar');
      if (newBar) newBar.classList.add('active');
      return;
    }

    if (bar.classList.contains('active')) {
      bar.classList.remove('active');
    } else {
      extractVideoDetails();
      renderSidebar();
      bar.classList.add('active');
    }
  }

  // Monitor SPA do YouTube
  function checkYouTubeNavigation() {
    const currentUrl = window.location.href;
    if (currentUrl === lastUrl) return;

    lastUrl = currentUrl;
    const newId = extractYouTubeVideoId(currentUrl);

    if (newId && newId !== currentVideoId) {
      currentVideoId = newId;

      // Aguarda 1s para o YouTube carregar o player e título
      setTimeout(() => {
        if (isWatchPage()) {
          extractVideoDetails();
          renderTriggerButton();
          const bar = document.getElementById('darkcuts-sidebar');
          if (bar && bar.classList.contains('active')) {
            renderSidebar();
          }
        } else {
          // Remove se não for página de vídeo
          const btn = document.getElementById('darkcuts-trigger-btn');
          if (btn) btn.remove();
        }
      }, 1000);
    }
  }

  function init() {
    // Listeners do YouTube
    window.addEventListener('yt-navigate-finish', checkYouTubeNavigation);
    window.addEventListener('yt-page-data-updated', checkYouTubeNavigation);
    window.addEventListener('popstate', checkYouTubeNavigation);
    setInterval(checkYouTubeNavigation, 800);

    // Inicializa na página atual
    setTimeout(() => {
      if (isWatchPage()) {
        currentVideoId = extractYouTubeVideoId(window.location.href);
        extractVideoDetails();
        renderTriggerButton();
      }
    }, 1500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
