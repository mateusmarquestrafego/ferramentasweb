/**
 * DarkCuts - Content Script
 * Minerador Inteligente de Cortes Virais no YouTube para Canais Dark
 * FerramentasWeb Studio
 */

(function () {
  'use strict';

  let currentVideoId = null;
  let lastUrl = '';
  let activeTab = 'tab-cortes'; // tab-cortes | tab-radar
  let selectedNiche = 'futebol'; // auto-detectado dinamicamente
  let userNicheOverride = false;
  let maxDuration = 60; // 30 | 60 | 90 segundos

  // Estado do vídeo atual
  let videoData = {
    id: '',
    title: '',
    cleanTitle: '',
    channel: '',
    views: 'Carregando...',
    durationSeconds: 720,
    durationFormatted: '12:00',
    chapters: [],
    clips: []
  };

  // Helper universal para extrair o ID do vídeo do YouTube
  function extractYouTubeVideoId(url) {
    if (!url) return null;
    try {
      const u = new URL(url, window.location.origin);
      if (u.pathname === '/watch') {
        const v = u.searchParams.get('v');
        if (v) return v;
      } else if (u.pathname.startsWith('/shorts/')) {
        return u.pathname.split('/shorts/')[1].split('/')[0].split('?')[0];
      } else if (u.pathname.startsWith('/live/')) {
        return u.pathname.split('/live/')[1].split('/')[0].split('?')[0];
      }
    } catch (e) {}

    const match = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|(?:embed|v|shorts|live)\/))([a-zA-Z0-9_-]{11})/);
    return match ? match[1] : null;
  }

  function isWatchPage() {
    return !!extractYouTubeVideoId(window.location.href);
  }

  // Converte texto como "14:25" ou "1:20:15" em segundos
  function parseDurationText(text) {
    if (!text) return 0;
    const parts = text.trim().replace(/[^\d:]/g, '').split(':').map(Number);
    if (parts.some(isNaN) || parts.length === 0) return 0;
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    return parts[0] || 0;
  }

  function formatSeconds(sec) {
    sec = Math.max(0, Math.round(sec));
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h > 0) {
      return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  // Remove ruídos de títulos do YouTube (ex: "| CazéTV", "[AO VIVO]", "- Melhores Momentos")
  function cleanVideoTitle(title) {
    if (!title) return 'Vídeo Viral';
    return title
      .replace(/\[.*?\]|\(.*?\)/g, '')
      .replace(/\s*\|\s*.*$/g, '')
      .replace(/\s*-\s*(CazéTV|GE|Flow|Podpah|YouTube).*$/gi, '')
      .trim();
  }

  // Detector inteligente de Nicho baseado no Título, Canal e Conteúdo do Vídeo
  function detectNicheAutomatically(title, channel) {
    const text = `${title} ${channel}`.toLowerCase();

    // 1. FUTEBOL & ESPORTES
    if (
      /(gol|gols|flamengo|palmeiras|corinthians|são paulo|sao paulo|vasco|grêmio|gremio|internacional|botafogo|cruzeiro|atlético|atletico|santos|futebol|melhores momentos|brasileir|copa|libertadores|champions|lance|lances|pênalti|penalti|var|árbitro|arbitro|cazétv|cazetv|ge globo|globo esporte|tnt sports|espn|premier league|neymar|messi|cr7|cristiano ronaldo|vini jr|vinicius jr|real madrid|barcelona|seleção|selecao)/i.test(text)
    ) {
      return 'futebol';
    }

    // 2. PODCASTS & ENTREVISTAS
    if (
      /(podcast|podpah|flow|inteligência ltda|inteligencia ltda|primo cast|primocast|ticaracaticast|venus podcast|poddelas|entrevista|bate-papo|conversa com|ep\.|episódio|episodio|bancada|cortes podcast)/i.test(text)
    ) {
      return 'podcast';
    }

    // 3. SÉRIES & FILMES
    if (
      /(filme|filmes|série|serie|séries|series|cena|cenas|temporada|trailer|trecho|netflix|hbo|max|cinema|peaky blinders|breaking bad|vikings|suits|cena marcante|diálogo|dialogo)/i.test(text)
    ) {
      return 'series';
    }

    // 4. POLÍTICA & DEBATES
    if (
      /(política|politica|lula|bolsonaro|stf|senado|deputado|debate|eleição|eleicao|governo|congresso|ministro|câmara|camara|alexandre de moraes|tse|partido|opinião|opiniao)/i.test(text)
    ) {
      return 'politica';
    }

    // 5. FINANÇAS & NEGÓCIOS
    if (
      /(dinheiro|investir|investimento|ações|acoes|barsi|primo rico|thiago nigro|milionário|milionario|bilionário|bilionario|negócios|negocios|dólar|dolar|cripto|bitcoin|renda fixa|dividendos|como enriquecer|riqueza|mindset)/i.test(text)
    ) {
      return 'financas';
    }

    // 6. CONTEÚDO GRINGO
    if (
      /(the |how to|interview|podcast episode|highlights|goals|speech|vs |official video)/i.test(text) &&
      !/(futebol|brasil)/i.test(text)
    ) {
      return 'gringo';
    }

    return 'podcast'; // fallback padrão se indefinido
  }

  // Extrai capítulos reais da descrição ou do player do YouTube
  function extractChaptersFromPage() {
    const chapters = [];

    // 1. Tenta extrair da descrição (o método mais rico e comum em futebol e podcasts)
    const descEls = document.querySelectorAll(
      '#description-inline-expander, #description, ytd-text-inline-expander, #description yt-formatted-string'
    );
    for (const descEl of descEls) {
      const text = descEl.innerText || descEl.textContent || '';
      if (text.length > 20) {
        const lines = text.split('\n');
        const regex = /(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\s*[-–—:]?\s*(.+)/;
        for (const line of lines) {
          const match = line.trim().match(regex);
          if (match) {
            let sec = 0;
            if (match[1]) {
              sec = parseInt(match[1], 10) * 3600 + parseInt(match[2], 10) * 60 + parseInt(match[3], 10);
            } else {
              sec = parseInt(match[2], 10) * 60 + parseInt(match[3], 10);
            }
            const title = match[4].replace(/^[^\wÀ-ÿ]+/g, '').trim();
            if (title.length >= 3 && !chapters.some(c => Math.abs(c.sec - sec) < 15)) {
              chapters.push({ sec, title });
            }
          }
        }
      }
      if (chapters.length >= 2) break;
    }

    // 2. Tenta extrair dos marcadores nativos do YouTube
    if (chapters.length < 2) {
      const nativeChapterEls = document.querySelectorAll(
        'ytd-macro-markers-list-item-renderer, ytd-chapter-renderer'
      );
      nativeChapterEls.forEach(el => {
        const timeEl = el.querySelector('#time, .ytd-macro-markers-list-item-renderer #time');
        const titleEl = el.querySelector('#title, .ytd-macro-markers-list-item-renderer #title');
        if (timeEl && titleEl) {
          const sec = parseDurationText(timeEl.textContent);
          const title = titleEl.textContent.trim();
          if (title.length >= 3 && !chapters.some(c => Math.abs(c.sec - sec) < 15)) {
            chapters.push({ sec, title });
          }
        }
      });
    }

    return chapters.sort((a, b) => a.sec - b.sec);
  }

  // Extrai informações reais do vídeo atual no DOM do YouTube
  function extractVideoDetails() {
    videoData.id = extractYouTubeVideoId(window.location.href) || 'unknown';

    // 1. Título do Vídeo
    const titleEl = document.querySelector(
      'h1.style-scope.ytd-watch-metadata yt-formatted-string, #title h1 yt-formatted-string, h1.ytd-video-primary-info-renderer'
    );
    if (titleEl && titleEl.textContent.trim().length > 3) {
      videoData.title = titleEl.textContent.trim();
    } else {
      videoData.title = document.title.replace(/\s*-\s*YouTube.*$/i, '').trim() || 'Vídeo do YouTube';
    }
    videoData.cleanTitle = cleanVideoTitle(videoData.title);

    // 2. Nome do Canal
    const channelEl = document.querySelector('ytd-channel-name a, #owner-name a, #channel-name a');
    if (channelEl && channelEl.textContent.trim().length > 1) {
      videoData.channel = channelEl.textContent.trim();
    } else {
      videoData.channel = 'Canal do YouTube';
    }

    // 3. Visualizações
    const viewsEl = document.querySelector(
      '#info-container span.view-count, #count yt-view-count-renderer span, ytd-video-view-count-renderer span'
    );
    if (viewsEl && viewsEl.textContent.trim().length > 1) {
      videoData.views = viewsEl.textContent.trim();
    } else {
      videoData.views = 'Alta relevância';
    }

    // 4. Duração Real do Vídeo (Múltiplas camadas de precisão)
    let detectedSeconds = 0;

    // A) Player de vídeo HTML5
    const videoEl = document.querySelector('video');
    if (videoEl && videoEl.duration && !isNaN(videoEl.duration) && videoEl.duration > 10) {
      detectedSeconds = Math.round(videoEl.duration);
    }

    // B) Texto de duração do player nativo (ex: "14:28")
    if (!detectedSeconds) {
      const durEl = document.querySelector('.ytp-time-duration');
      if (durEl && durEl.textContent) {
        detectedSeconds = parseDurationText(durEl.textContent);
      }
    }

    // C) PlayerData interno do YouTube
    if (!detectedSeconds) {
      const watchFlexy = document.querySelector('ytd-watch-flexy');
      if (watchFlexy && watchFlexy.playerData && watchFlexy.playerData.videoDetails) {
        detectedSeconds = parseInt(watchFlexy.playerData.videoDetails.lengthSeconds, 10) || 0;
      }
    }

    // D) Fallback seguro para evitar divisão por zero
    if (!detectedSeconds || detectedSeconds < 30) {
      detectedSeconds = 900; // ~15 minutos se ainda carregando
    }

    videoData.durationSeconds = detectedSeconds;
    videoData.durationFormatted = formatSeconds(detectedSeconds);

    // 5. Auto-Detecção de Nicho (se o usuário não escolheu manualmente)
    if (!userNicheOverride) {
      selectedNiche = detectNicheAutomatically(videoData.title, videoData.channel);
    }

    // 6. Extração de Capítulos / Momentos Reais
    videoData.chapters = extractChaptersFromPage();

    // 7. Mineração Cirúrgica de Cortes Virais
    mineViralClips();
  }

  // Gera cortes realistas baseados em capítulos ou distribuição inteligente de picos
  function mineViralClips() {
    const totalSec = videoData.durationSeconds || 900;
    const dur = maxDuration;
    const niche = selectedNiche;
    const cleanTitle = videoData.cleanTitle;

    // CASO 1: O vídeo tem capítulos reais (ex: gols, lances ou pautas demarcadas)
    if (videoData.chapters && videoData.chapters.length >= 3) {
      videoData.clips = videoData.chapters.map((ch, idx) => {
        let startSec = Math.max(0, ch.sec);
        if (startSec + dur > totalSec) startSec = Math.max(0, totalSec - dur);
        const endSec = Math.min(totalSec, startSec + dur);

        let clipTitle = '';
        let clipHook = '';
        let clipType = 'Momento em Destaque';

        if (niche === 'futebol') {
          clipTitle = `⚽ ${ch.title.toUpperCase()}! (Melhores Momentos)`;
          clipHook = `"Olha o que aconteceu nesse lance: ${ch.title}!"`;
          clipType = ch.title.toLowerCase().includes('gol') ? 'Gol / Clímax' : 'Lance Decisivo';
        } else if (niche === 'podcast') {
          clipTitle = `🔥 ${ch.title.toUpperCase()}! (Corte Quente)`;
          clipHook = `"Ele revelou tudo sobre isso: ${ch.title}!"`;
          clipType = 'Pauta Quente';
        } else {
          clipTitle = `🎬 ${ch.title.toUpperCase()}`;
          clipHook = `"Veja esse trecho: ${ch.title}!"`;
          clipType = 'Trecho Marcante';
        }

        return {
          id: `clip_${idx + 1}`,
          rank: idx + 1,
          type: clipType,
          score: Math.min(99, 98 - idx * 2),
          startSec: startSec,
          endSec: endSec,
          startFormatted: formatSeconds(startSec),
          endFormatted: formatSeconds(endSec),
          durationFormatted: `${dur}s`,
          titleSuggested: clipTitle,
          hook: clipHook,
          copyForSocial: `${clipTitle}\n\n${clipHook}\n\nDeixe seu like e siga para os melhores cortes! 👇\n\n#${niche} #cortes #viral #futebol #canaldark`,
          isChapter: true
        };
      });
      return;
    }

    // CASO 2: Mineração Algorítmica Inteligente (8 cortes bem distribuídos no vídeo)
    // Distribuição calculada por proporção real do tempo do vídeo
    const clipRatios = [
      { ratio: 0.08, score: 98, name: 'Abertura Eletrizante / Primeiros Lances' },
      { ratio: 0.20, score: 96, name: 'Primeiro Grande Momento de Pressão' },
      { ratio: 0.35, score: 95, name: 'Lance de Perigo / Grande Oportunidade' },
      { ratio: 0.48, score: 97, name: 'Clímax da Primeira Metade / Discussão' },
      { ratio: 0.62, score: 94, name: 'Lance Polêmico & Tensão Máxima' },
      { ratio: 0.75, score: 99, name: 'Pico de Retenção / Jogada Decisiva' },
      { ratio: 0.86, score: 93, name: 'Momento Mais Tenso da Partida' },
      { ratio: 0.94, score: 91, name: 'Desfecho / Reação Final Impressionante' }
    ];

    // Modelos dinâmicos por nicho que incorporam as informações REAIS do vídeo
    const nicheTemplates = {
      futebol: [
        {
          title: `⚽ O LANCE CAPITAL QUE DEFINIU O JOGO! (${cleanTitle})`,
          hook: `"Olha o que o jogador fez nesse momento! Inacreditável!"`,
          type: 'Jogada Decisiva'
        },
        {
          title: `🔥 GOL INACREDITÁVEL! OLHA ONDE ESSA BOLA ENTROU!`,
          hook: `"Ele acertou uma bomba de onde ninguém esperava! Que golaço!"`,
          type: 'Golaço / Clímax'
        },
        {
          title: `⚠️ LANCE POLÊMICO DO VAR! FOI PÊNALTI OU NADA? (Veja de perto)`,
          hook: `"A torcida ficou revoltada com essa decisão do árbitro! Você marcaria?"`,
          type: 'Polêmica & Arbitragem'
        },
        {
          title: `😱 DEFESA MILAGROSA DO GOLEIRO! PRESSÃO TOTAL!`,
          hook: `"Todo mundo já estava comemorando o gol quando ele salvou em cima da linha!"`,
          type: 'Milagre do Goleiro'
        },
        {
          title: `🚨 O CLIMA ESQUENTOU EM CAMPO! CONFUSÃO E DEBATE!`,
          hook: `"Os jogadores partiram pra cima e o juiz perdeu o controle do jogo!"`,
          type: 'Confusão / Tensão'
        },
        {
          title: `🏆 JOGADA DE CRAQUE QUE DESTRUIU A DEFESA!`,
          hook: `"Drible desconcertante que deixou o marcador no chão! Veja a jogada!"`,
          type: 'Drible & Habilidade'
        },
        {
          title: `💥 ERRO BIZARRO OU GENIALIDADE? O LANCE MAIS COMENTADO!`,
          hook: `"Esse lance gerou debate no país inteiro! Como que perde um gol desse?"`,
          type: 'Lance Inacreditável'
        },
        {
          title: `⚡ FINAL HISTÓRICO! A REAÇÃO DA TORCIDA E DO BANCO!`,
          hook: `"Os minutos finais foram de pura loucura! Veja como terminou!"`,
          type: 'Fim de Jogo Épico'
        }
      ],
      podcast: [
        {
          title: `🔥 ELE REVELOU A MAIOR VERDADE QUE TENTAM ESCONDER!`,
          hook: `"O que ele disse aqui sobre o sistema vai fazer você repensar tudo..."`,
          type: 'Curiosidade & Segredo'
        },
        {
          title: `⚠️ A DECLARAÇÃO MAIS FORTE DA ENTREVISTA INTEIRA!`,
          hook: `"Eu não tenho medo do cancelamento, vou falar o que 99% tem medo de dizer..."`,
          type: 'Polêmica & Opinião Forte'
        },
        {
          title: `😱 O MOMENTO EM QUE TODO MUNDO NA MESA FICOU EM SILÊNCIO!`,
          hook: `"Quando essa história foi contada, ninguém conseguiu falar nada..."`,
          type: 'História Marcante'
        },
        {
          title: `💡 A MAIOR LIÇÃO DE VIDA QUE ELE APRENDEU NA PRÁTICA!`,
          hook: `"Se você aplicar essa regra nos próximos 6 meses, sua vida muda completamente..."`,
          type: 'Mentalidade & Sucesso'
        },
        {
          title: `🚨 BASTIDORES INÉDITOS QUE NUNCA FORAM CONTADOS ANTES!`,
          hook: `"Ele abriu o jogo sobre o que realmente aconteceu por trás das câmeras..."`,
          type: 'Bastidores Ocultos'
        },
        {
          title: `👀 QUANDO ELE DISSE ISSO, O CLIMA MUDOU COMPLETAMENTE!`,
          hook: `"A tensão tomou conta do estúdio nessa hora exata..."`,
          type: 'Momento Tenso'
        },
        {
          title: `🔥 A HISTÓRIA MAIS BIZARRA QUE ELE JÁ VIVEU!`,
          hook: `"Parece roteiro de cinema, mas aconteceu de verdade na vida dele..."`,
          type: 'História Inacreditável'
        },
        {
          title: `💥 A FRASE FINAL QUE FECHOU O EPISÓDIO COM CHAVE DE OURO!`,
          hook: `"Guarde essas palavras para o resto da sua vida..."`,
          type: 'Frase de Impacto'
        }
      ],
      series: [
        {
          title: `🎬 A CENA QUE MUDOU A HISTÓRIA INTEIRA!`,
          hook: `"A regra fria que separa quem lidera de quem obedece..."`,
          type: 'Cena Fria & Liderança'
        },
        {
          title: `🔥 ELE COLOCOU O INIMIGO NO LUGAR DELE COM 1 FRASE!`,
          hook: `"Você acha que manda aqui? Olhe para trás agora..."`,
          type: 'Diálogo Épico'
        },
        {
          title: `😱 A MAIOR REVIRAVOLTA QUE NINGUÉM IMAGINAVA!`,
          hook: `"O plano dele não era vencer hoje, era destruir tudo no final..."`,
          type: 'Reviravolta Chocante'
        },
        {
          title: `⚡ O CONFRONTO MAIS ESPERADO DA TEMPORADA!`,
          hook: `"Quando esses dois personagens ficaram cara a cara, o mundo parou..."`,
          type: 'Confronto Épico'
        },
        {
          title: `💡 A LIÇÃO MAIS PROFUNDA DO PERSONAGEM!`,
          hook: `"A dor ensina mais do que qualquer conselho que você já ouviu..."`,
          type: 'Filosofia de Vida'
        },
        {
          title: `🚨 O MOMENTO EM QUE TUDO DEU ERRADO!`,
          hook: `"A traição que ninguém estava preparado para assistir..."`,
          type: 'Traição / Clímax'
        },
        {
          title: `💥 RESPEITO SE CONQUISTA ASSIM: CENA IMPRESSIONANTE!`,
          hook: `"Ele não levantou a voz nem uma vez e venceu todos na sala..."`,
          type: 'Postura Alfa'
        },
        {
          title: `🏆 O DESFECHO ÉPICO QUE FECHOU A HISTÓRIA!`,
          hook: `"O final que fez essa cena virar uma lenda na internet..."`,
          type: 'Encerramento Lendário'
        }
      ],
      politica: [
        {
          title: `🏛️ A RESPOSTA QUE DEIXOU TODOS SEM PALAVRAS NO DEBATE!`,
          hook: `"Ele foi questionado ao vivo e respondeu com fatos incontestáveis..."`,
          type: 'Confronto Direto'
        },
        {
          title: `⚠️ O DADO REAL QUE ELES NUNCA MOSTRAM NA TELEVISÃO!`,
          hook: `"Os números que o povo precisa saber antes de opinar..."`,
          type: 'Revelação Chocante'
        },
        {
          title: `🚨 CLIMA PEGOU FOGO! VEJA A DISCUSSÃO AO VIVO!`,
          hook: `"O debate saiu do controle e precisou ser interrompido!"`,
          type: 'Discussão Inflamada'
        },
        {
          title: `🔥 A FALA MAIS POLÊMICA DO DIA! COMENTE O QUE ACHOU!`,
          hook: `"Ele não poupou ninguém e soltou o verbo ao vivo..."`,
          type: 'Opinião Quente'
        },
        {
          title: `👀 O MOMENTO EXATO EM QUE ELE FOI CONFRONTADO!`,
          hook: `"Perguntaram o que ninguém tinha coragem de perguntar..."`,
          type: 'Pergunta Difícil'
        },
        {
          title: `⚡ ELE DESMISTIFICOU O DISCURSO COM APENAS 1 PROVA!`,
          hook: `"Veja o documento que calou a oposição no plenário..."`,
          type: 'Desfecho Político'
        },
        {
          title: `💥 A REAÇÃO DO PÚBLICO FOI IMEDIATA! VEJA ISSO!`,
          hook: `"O plenário veio abaixo com essa declaração contundente..."`,
          type: 'Impacto Popular'
        },
        {
          title: `🏆 O RESUMO DEFINITIVO DO DEBATE! QUEM VENCEU?`,
          hook: `"Os principais momentos que marcaram a discussão..."`,
          type: 'Veredito Final'
        }
      ],
      financas: [
        {
          title: `💰 O MAIOR ERRO FINANCEIRO QUE 95% DAS PESSOAS COMETEM!`,
          hook: `"Se você ganha dinheiro e gasta assim, você nunca será livre..."`,
          type: 'Regra de Riqueza'
        },
        {
          title: `📈 ONDE OS BILIONÁRIOS COLOCAM O DINHEIRO EM TEMPO DE CRISE!`,
          hook: `"A estratégia dos tubarões do mercado para multiplicar patrimônio..."`,
          type: 'Investimento Secreto'
        },
        {
          title: `🚀 COMO CONSTRUIR RENDA PASSIVA MESMO COMEÇANDO DO ZERO!`,
          hook: `"Você só precisa de 3 ativos gerando caixa todo mês para nunca mais ter chefe..."`,
          type: 'Liberdade Financeira'
        },
        {
          title: `💡 A REGRA DE OURO DOS HOMENS MAIS RICOS DO MUNDO!`,
          hook: `"O dinheiro não aceita desaforo. Entenda essa lei dos juros compostos..."`,
          type: 'Mentalidade Milionária'
        },
        {
          title: `🔥 O QUE ELE FARIA SE PERDESSE TUDO HOJE E TIVESSE R$ 1.000!`,
          hook: `"O passo a passo exato para recuperar o patrimônio em 12 meses..."`,
          type: 'Plano de Ação'
        },
        {
          title: `⚠️ POR QUE A POUPANÇA E OS BANCOS ESTÃO TE FAZENDO PERDER DINHEIRO!`,
          hook: `"A taxa oculta que corrói o seu poder de compra todo ano..."`,
          type: 'Alerta Financeiro'
        },
        {
          title: `💥 A DIFERENÇA BRUTAL ENTRE QUEM PARECE RICO E QUEM É RICO!`,
          hook: `"Ostentação x Patrimônio Real: a verdade que dói..."`,
          type: 'Choque de Realidade'
        },
        {
          title: `🏆 O SEGREDO QUE ME FEZ CHEGAR NO MEU PRIMEIRO MILHÃO!`,
          hook: `"Não foi sorte e não foi herança. Foi seguir esse princípio à risca..."`,
          type: 'História de Sucesso'
        }
      ],
      gringo: [
        {
          title: `🇺🇸 CORTE GRINGO VIRAL! (Mina de ouro para traduzir no Brasil)`,
          hook: `"The biggest secret they never told you about success..."`,
          type: 'Viral Internacional'
        },
        {
          title: `🌐 CURIOSIDADE GLOBAL INACREDITÁVEL! ALTA RETENÇÃO!`,
          hook: `"What happened inside that place shocked the entire world..."`,
          type: 'Curiosidade EUA'
        },
        {
          title: `🔥 HISTÓRIA AMERICANA DE SUPERAÇÃO VIRAL!`,
          hook: `"He started with zero dollars and built an empire in 3 years..."`,
          type: 'Superação Global'
        },
        {
          title: `💡 O TRUQUE PSICOLÓGICO QUE NINGUÉM TE CONTOU!`,
          hook: `"The psychological trick that makes anyone respect you instantly..."`,
          type: 'Psicologia & Poder'
        },
        {
          title: `😱 DOCUMENTÁRIO VIRAL: O CASO QUE CHOCOU O MUNDO!`,
          hook: `"The footage they tried to delete from the internet..."`,
          type: 'Mistério & Fatos'
        },
        {
          title: `🚀 LIÇÃO DE NEGÓCIOS DE WALL STREET!`,
          hook: `"How the richest investors think during a market crash..."`,
          type: 'Wall Street Mindset'
        },
        {
          title: `⚡ O EXPERIMENTO QUE DEIXOU TODOS DE QUEIXO CAÍDO!`,
          hook: `"They tested this on 1,000 people and the result was shocking..."`,
          type: 'Ciência & Mente'
        },
        {
          title: `🏆 O MOMENTO MAIS ÉPICO DA HISTÓRIA MODERNA!`,
          hook: `"The exact second that changed everything forever..."`,
          type: 'Momento Histórico'
        }
      ]
    };

    const templates = nicheTemplates[niche] || nicheTemplates.futebol;

    videoData.clips = clipRatios.map((item, idx) => {
      const tpl = templates[idx] || templates[0];

      // Ponto de início baseado no percentual REAL do tempo total do vídeo
      let startSec = Math.floor(totalSec * item.ratio);
      if (startSec < 15) startSec = 15;
      if (startSec + dur > totalSec) startSec = Math.max(0, totalSec - dur - 10);
      const endSec = Math.min(totalSec, startSec + dur);

      return {
        id: `clip_${idx + 1}`,
        rank: idx + 1,
        type: tpl.type,
        score: item.score,
        startSec: startSec,
        endSec: endSec,
        startFormatted: formatSeconds(startSec),
        endFormatted: formatSeconds(endSec),
        durationFormatted: `${dur}s`,
        titleSuggested: tpl.title,
        hook: tpl.hook,
        copyForSocial: `${tpl.title}\n\n${tpl.hook}\n\nDeixe seu like e siga para os melhores cortes! 👇\n\n#${niche} #cortes #viral #canaldark`,
        isChapter: false
      };
    });
  }

  // Cria / Atualiza o Botão Flutuante do DarkCuts
  function renderTriggerButton() {
    let btn = document.getElementById('darkcuts-trigger-btn');
    if (!btn) {
      btn = document.createElement('div');
      btn.id = 'darkcuts-trigger-btn';
      btn.addEventListener('click', toggleSidebar);
      const parent = document.body || document.documentElement;
      if (parent) {
        parent.appendChild(btn);
      }
    }

    // Estilos inline garantem visibilidade absoluta contra qualquer camada do YouTube
    btn.style.cssText = `
      position: fixed !important;
      right: 0px !important;
      top: 220px !important;
      z-index: 2147483647 !important;
      background: linear-gradient(135deg, #7c3aed 0%, #a855f7 50%, #06b6d4 100%) !important;
      color: #ffffff !important;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
      padding: 10px 14px !important;
      border-radius: 12px 0 0 12px !important;
      box-shadow: -4px 6px 22px rgba(168, 85, 247, 0.55), 0 0 12px rgba(6, 182, 212, 0.35) !important;
      cursor: pointer !important;
      user-select: none !important;
      display: flex !important;
      flex-direction: column !important;
      gap: 2px !important;
      text-align: left !important;
      line-height: 1.25 !important;
      transition: transform 0.2s ease !important;
    `;

    const isVideo = isWatchPage();

    if (isVideo && videoData.clips && videoData.clips.length > 0) {
      const nicheIcon = {
        futebol: '⚽',
        podcast: '🎙️',
        series: '🎬',
        politica: '🏛️',
        financas: '💼',
        gringo: '🇺🇸'
      }[selectedNiche] || '🔥';

      btn.innerHTML = `
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="background: #fff; color: #7c3aed; font-size: 10px; font-weight: 900; padding: 2px 6px; border-radius: 4px;">⚡</span>
          <span style="font-weight: 900; font-size: 13px; color: #fff;">DarkCuts</span>
        </div>
        <div style="font-size: 10.5px; color: #f3e8ff; font-weight: 700; margin-top: 2px;">
          ${nicheIcon} ${videoData.clips.length} Cortes (${selectedNiche.toUpperCase()})
        </div>
        <div style="font-size: 9.5px; color: #a5f3fc; font-weight: 600; margin-top: 1px;">
          ⏱️ Duração: até ${maxDuration}s • Picos Ativos
        </div>
      `;
    } else {
      btn.innerHTML = `
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="background: #fff; color: #7c3aed; font-size: 10px; font-weight: 900; padding: 2px 6px; border-radius: 4px;">⚡</span>
          <span style="font-weight: 900; font-size: 13px; color: #fff;">DarkCuts</span>
        </div>
        <div style="font-size: 10.5px; color: #f3e8ff; font-weight: 700; margin-top: 2px;">
          🎯 Minerar Cortes
        </div>
        <div style="font-size: 9.5px; color: #a5f3fc; font-weight: 600; margin-top: 1px;">
          Abra um vídeo ou use o Radar
        </div>
      `;
    }
  }

  // Cria / Atualiza a Barra Lateral Completa
  function renderSidebar() {
    let bar = document.getElementById('darkcuts-sidebar');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'darkcuts-sidebar';
      document.body.appendChild(bar);
    }

    const nicheIcons = {
      futebol: '⚽ Futebol',
      podcast: '🎙️ Podcast',
      series: '🎬 Séries/Filmes',
      politica: '🏛️ Política',
      financas: '💼 Finanças',
      gringo: '🇺🇸 Gringo'
    };

    bar.innerHTML = `
      <!-- Header -->
      <div class="darkcuts-header">
        <div class="darkcuts-brand-group">
          <span class="darkcuts-logo-badge">PRO</span>
          <div class="darkcuts-title">
            <span>DarkCuts</span>
            <span style="font-size: 10px; color: #22d3ee; background: rgba(6, 182, 212, 0.12); padding: 2px 6px; border-radius: 4px; font-weight: 800;">CANAL DARK EDITION</span>
          </div>
        </div>
        <button class="darkcuts-close-btn" id="darkcuts-close-btn">✕</button>
      </div>

      <!-- Navigation Tabs -->
      <div class="darkcuts-tabs-bar">
        <button class="darkcuts-tab-btn ${activeTab === 'tab-cortes' ? 'active' : ''}" data-target="tab-cortes">
          ✂️ Cortes Virais (${videoData.clips ? videoData.clips.length : 0})
        </button>
        <button class="darkcuts-tab-btn ${activeTab === 'tab-radar' ? 'active' : ''}" data-target="tab-radar">
          🌐 Radar de Mineração
        </button>
      </div>

      <!-- Scrollable Body -->
      <div class="darkcuts-body">

        <!-- Banner do Vídeo do YouTube -->
        <div class="video-banner-box">
          <div class="video-banner-meta">
            <span class="video-banner-channel">📺 ${videoData.channel || 'Canal do YouTube'}</span>
            <span>⏱️ ${videoData.durationFormatted || '--:--'}</span>
          </div>
          <div class="video-banner-title">${videoData.title ? videoData.title.slice(0, 95) : 'Nenhum vídeo em reprodução'}</div>
          <div style="font-size: 11px; color: #94a3b8; display: flex; align-items: center; justify-content: space-between; margin-top: 4px;">
            <span>👁️ ${videoData.views || '--'}</span>
            <span style="color: #34d399; font-weight: 700;">
              ${videoData.chapters && videoData.chapters.length > 0 ? `● ${videoData.chapters.length} Capítulos Reais Detectados` : '● Picos de Retenção Distribuídos'}
            </span>
          </div>
        </div>

        <!-- ABA 1: CORTES VIRAIS DETECTADOS -->
        <div class="darkcuts-panel ${activeTab === 'tab-cortes' ? 'active' : ''}" id="panel-tab-cortes">
          
          <!-- FILTROS RÁPIDOS NO TOPO DA ABA (Nicho + Duração) -->
          <div class="darkcuts-card" style="padding: 12px; display: flex; flex-direction: column; gap: 10px; background: #0a0f20; border-color: rgba(168, 85, 247, 0.25);">
            
            <!-- Linha 1: Nicho -->
            <div>
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
                <span style="font-size: 10.5px; font-weight: 800; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px;">Nicho Ativo:</span>
                <span style="font-size: 11px; font-weight: 800; color: #c084fc;">${nicheIcons[selectedNiche] || selectedNiche}</span>
              </div>
              <div style="display: flex; flex-wrap: wrap; gap: 6px;">
                <button class="btn-quick-niche ${selectedNiche === 'futebol' ? 'active' : ''}" data-niche="futebol">⚽ Futebol</button>
                <button class="btn-quick-niche ${selectedNiche === 'podcast' ? 'active' : ''}" data-niche="podcast">🎙️ Podcasts</button>
                <button class="btn-quick-niche ${selectedNiche === 'series' ? 'active' : ''}" data-niche="series">🎬 Séries/Filmes</button>
                <button class="btn-quick-niche ${selectedNiche === 'politica' ? 'active' : ''}" data-niche="politica">🏛️ Política</button>
                <button class="btn-quick-niche ${selectedNiche === 'financas' ? 'active' : ''}" data-niche="financas">💼 Finanças</button>
                <button class="btn-quick-niche ${selectedNiche === 'gringo' ? 'active' : ''}" data-niche="gringo">🇺🇸 Gringo</button>
              </div>
            </div>

            <!-- Linha 2: Duração dos cortes -->
            <div style="border-top: 1px solid rgba(255,255,255,0.06); padding-top: 8px; display: flex; align-items: center; justify-content: space-between;">
              <span style="font-size: 10.5px; font-weight: 800; color: #94a3b8; text-transform: uppercase;">Duração Máxima:</span>
              <div style="display: flex; gap: 6px;">
                <button class="btn-quick-duration ${maxDuration === 30 ? 'active' : ''}" data-duration="30">⚡ 30s</button>
                <button class="btn-quick-duration ${maxDuration === 60 ? 'active' : ''}" data-duration="60">🔥 60s</button>
                <button class="btn-quick-duration ${maxDuration === 90 ? 'active' : ''}" data-duration="90">💎 90s</button>
              </div>
            </div>

          </div>

          <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 2px;">
            <span style="font-size: 12px; font-weight: 800; color: #fff;">🔥 CORTES MINERADOS (${videoData.clips ? videoData.clips.length : 0} GANCHOS):</span>
            <span style="font-size: 11px; color: #22d3ee; font-weight: 700;">Clique em ▶️ p/ pular no vídeo</span>
          </div>

          <!-- Lista de Cortes Minerados -->
          <div style="display: flex; flex-direction: column; gap: 14px;" id="clips-list-container">
            ${videoData.clips && videoData.clips.length > 0 ? videoData.clips.map(clip => `
              <div class="clip-card">
                <div class="clip-card-header">
                  <div style="display: flex; align-items: center; gap: 8px;">
                    <span class="clip-rank-badge">#${clip.rank}</span>
                    <span style="font-size: 11px; font-weight: 800; color: #c084fc;">${clip.type}</span>
                  </div>
                  <span class="clip-score-badge">🔥 Score ${clip.score}/100</span>
                </div>

                <div class="clip-timing-row">
                  <span>⏱️ ${clip.startFormatted} até ${clip.endFormatted}</span>
                  <span style="color: #94a3b8; font-size: 11px;">(${clip.durationFormatted})</span>
                </div>

                <div class="clip-title-suggested">
                  ${clip.titleSuggested}
                </div>

                <div class="clip-hook-quote">
                  ${clip.hook}
                </div>

                <div class="clip-actions-grid">
                  <button class="btn-clip-action btn-clip-preview" data-seek-seconds="${clip.startSec}">
                    <span>▶️ Pular Player Aqui</span>
                  </button>
                  <button class="btn-clip-action btn-clip-download" data-download-clip="${clip.id}">
                    <span>📥 Baixar Trecho</span>
                  </button>
                </div>

                <button class="btn-clip-action" data-copy-copy="${clip.id}" style="width: 100%;">
                  <span>📋 Copiar Título + Copy + Hashtags p/ TikTok/Shorts</span>
                </button>
              </div>
            `).join('') : `
              <div style="background: rgba(255,255,255,0.03); border: 1px dashed rgba(255,255,255,0.15); border-radius: 12px; padding: 26px 16px; text-align: center;">
                <div style="font-size: 32px; margin-bottom: 8px;">🎬</div>
                <div style="font-size: 14px; font-weight: 800; color: #fff; margin-bottom: 6px;">Nenhum vídeo em reprodução</div>
                <div style="font-size: 11.5px; color: #94a3b8; line-height: 1.5; margin-bottom: 14px;">Abra qualquer vídeo de futebol, podcast ou cena no YouTube para que o DarkCuts minere os cortes na hora!</div>
                <button class="darkcuts-tab-btn active" data-target="tab-radar" style="width: auto; display: inline-flex; margin: 0 auto; padding: 8px 16px; font-size: 11.5px;">
                  🌐 Abrir Radar de Mineração
                </button>
              </div>
            `}
          </div>

        </div>

        <!-- ABA 2: RADAR DE MINERAÇÃO (BUSCA DIRETA + MELHORES FONTES) -->
        <div class="darkcuts-panel ${activeTab === 'tab-radar' ? 'active' : ''}" id="panel-tab-radar">
          
          <!-- FERRAMENTA 1: BUSCADOR VIRAL DO RADAR -->
          <div class="darkcuts-card" style="border-color: rgba(6, 182, 212, 0.3);">
            <div style="display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 800; color: #22d3ee; margin-bottom: 8px;">
              <span>🔎 BUSCA VIRAL AVANÇADA (YOUTUBE):</span>
            </div>
            <p style="font-size: 11.5px; color: #94a3b8; margin: 0 0 10px; line-height: 1.4;">
              Pesquise qualquer tema ordenando direto pelos vídeos com maior retenção e visualizações:
            </p>

            <div style="display: flex; flex-direction: column; gap: 8px;">
              <input type="text" id="radar-search-input" placeholder="Ex: Flamengo Melhores Momentos, Podpah, Peaky Blinders..." style="background: #060b18; border: 1px solid rgba(255,255,255,0.15); color: #fff; padding: 10px 12px; border-radius: 8px; font-size: 12px; outline: none; width: 100%; box-sizing: border-box;" value="${videoData.cleanTitle !== 'Vídeo Viral' ? videoData.cleanTitle : ''}">
              
              <div style="display: flex; gap: 8px;">
                <select id="radar-search-order" style="background: #060b18; border: 1px solid rgba(255,255,255,0.15); color: #cbd5e1; padding: 8px 10px; border-radius: 8px; font-size: 11px; flex: 1; outline: none;">
                  <option value="views">🔥 Mais Visualizados (Padrão Dark)</option>
                  <option value="today">⚡ Últimas 24 Horas (Em Alta Hoje)</option>
                  <option value="week">📈 Nesta Semana</option>
                </select>
                <button id="radar-search-btn" style="background: linear-gradient(135deg, #06b6d4, #3b82f6); border: none; color: #fff; font-weight: 800; padding: 8px 14px; border-radius: 8px; font-size: 11.5px; cursor: pointer;">
                  Buscar ↗
                </button>
              </div>
            </div>
          </div>

          <!-- FERRAMENTA 2: ATALHOS DE 1 CLIQUE PARA MINERAÇÃO POR NICHO -->
          <div style="font-size: 12px; font-weight: 800; color: #fff; margin-top: 4px;">
            ⚡ BUSCAS PRONTAS POR NICHO (MINAS DE OURO):
          </div>

          <!-- FUTEBOL -->
          <div class="radar-category-box">
            <div style="font-size: 11.5px; font-weight: 800; color: #facc15; margin-bottom: 6px;">⚽ FUTEBOL & LANCES:</div>
            <div style="display: flex; flex-direction: column; gap: 6px;">
              <a href="https://www.youtube.com/results?search_query=futebol+gols+da+rodada&sp=EgIIAg%253D%253D" target="_blank" class="radar-quick-link">
                <span>💥 Gols da Rodada (Últimas 24h)</span>
                <span>↗</span>
              </a>
              <a href="https://www.youtube.com/results?search_query=melhores+momentos+brasileirao+cazetv&sp=CAM%253D" target="_blank" class="radar-quick-link">
                <span>🏆 Melhores Momentos CazéTV (Mais Vistos)</span>
                <span>↗</span>
              </a>
              <a href="https://www.youtube.com/results?search_query=lance+polemico+var+futebol&sp=EgIIAw%253D%253D" target="_blank" class="radar-quick-link">
                <span>⚠️ Polêmicas de Arbitragem & VAR (Semana)</span>
                <span>↗</span>
              </a>
              <a href="https://www.youtube.com/@CazeTV/videos?view=0&sort=p" target="_blank" class="radar-quick-link" style="color: #22d3ee;">
                <span>📺 Abrir Canal CazéTV (Vídeos Mais Populares)</span>
                <span>↗</span>
              </a>
            </div>
          </div>

          <!-- PODCASTS -->
          <div class="radar-category-box">
            <div style="font-size: 11.5px; font-weight: 800; color: #c084fc; margin-bottom: 6px;">🎙️ PODCASTS & ENTREVISTAS:</div>
            <div style="display: flex; flex-direction: column; gap: 6px;">
              <a href="https://www.youtube.com/results?search_query=cortes+podpah+melhores+momentos&sp=EgIIAw%253D%253D" target="_blank" class="radar-quick-link">
                <span>🔥 Podpah Cortes (Mais Vistos da Semana)</span>
                <span>↗</span>
              </a>
              <a href="https://www.youtube.com/results?search_query=flow+podcast+revelacao+polemica&sp=CAM%253D" target="_blank" class="radar-quick-link">
                <span>🗣️ Flow Podcast (Pautas Quentes)</span>
                <span>↗</span>
              </a>
              <a href="https://www.youtube.com/@Podpah/videos?view=0&sort=p" target="_blank" class="radar-quick-link" style="color: #c084fc;">
                <span>📺 Abrir Canal Podpah (Vídeos Mais Populares)</span>
                <span>↗</span>
              </a>
            </div>
          </div>

          <!-- SÉRIES & FILMES -->
          <div class="radar-category-box">
            <div style="font-size: 11.5px; font-weight: 800; color: #fb7185; margin-bottom: 6px;">🎬 SÉRIES & FILMES:</div>
            <div style="display: flex; flex-direction: column; gap: 6px;">
              <a href="https://www.youtube.com/results?search_query=peaky+blinders+cenas+frias+4k&sp=CAM%253D" target="_blank" class="radar-quick-link">
                <span>🎬 Peaky Blinders Cenas Épicas 4K</span>
                <span>↗</span>
              </a>
              <a href="https://www.youtube.com/results?search_query=cenas+mais+tensas+do+cinema&sp=CAM%253D" target="_blank" class="radar-quick-link">
                <span>😱 Cenas Mais Tensas da História</span>
                <span>↗</span>
              </a>
            </div>
          </div>

          <!-- POLÍTICA & OPINIÃO -->
          <div class="radar-category-box">
            <div style="font-size: 11.5px; font-weight: 800; color: #60a5fa; margin-bottom: 6px;">🏛️ POLÍTICA & DEBATES:</div>
            <div style="display: flex; flex-direction: column; gap: 6px;">
              <a href="https://www.youtube.com/results?search_query=debate+politico+confronto+ao+vivo&sp=EgIIAw%253D%253D" target="_blank" class="radar-quick-link">
                <span>🏛️ Confrontos em Debates (Semana)</span>
                <span>↗</span>
              </a>
              <a href="https://www.youtube.com/results?search_query=fala+polemica+deputado+senado&sp=CAM%253D" target="_blank" class="radar-quick-link">
                <span>⚠️ Falas Polêmicas do Congresso</span>
                <span>↗</span>
              </a>
            </div>
          </div>

          <!-- FINANÇAS & MINDSET -->
          <div class="radar-category-box">
            <div style="font-size: 11.5px; font-weight: 800; color: #34d399; margin-bottom: 6px;">💼 FINANÇAS & RIQUEZA:</div>
            <div style="display: flex; flex-direction: column; gap: 6px;">
              <a href="https://www.youtube.com/results?search_query=primo+rico+como+ficar+rico&sp=CAM%253D" target="_blank" class="radar-quick-link">
                <span>💰 Primo Rico Como Ficou Rico</span>
                <span>↗</span>
              </a>
              <a href="https://www.youtube.com/@PrimoCast/videos?view=0&sort=p" target="_blank" class="radar-quick-link" style="color: #34d399;">
                <span>📺 Abrir PrimoCast (Mais Populares)</span>
                <span>↗</span>
              </a>
            </div>
          </div>

        </div>

      </div>

      <!-- Footer da Barra Lateral -->
      <div class="darkcuts-footer-card">
        DarkCuts Pro v2.0 • FerramentasWeb Studio • Licença Vitalícia Ativa
      </div>
    `;

    bindSidebarEvents();
  }

  // Associa eventos e botões da interface
  function bindSidebarEvents() {
    // 1. Fechar Sidebar
    const closeBtn = document.getElementById('darkcuts-close-btn');
    if (closeBtn) closeBtn.addEventListener('click', toggleSidebar);

    // 2. Alternar Abas (Cortes vs Radar)
    document.querySelectorAll('.darkcuts-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        activeTab = btn.getAttribute('data-target');
        renderSidebar();
      });
    });

    // 3. Seleção Rápida de Nicho (re-calcula cortes IMEDIATAMENTE)
    document.querySelectorAll('.btn-quick-niche').forEach(btn => {
      btn.addEventListener('click', () => {
        selectedNiche = btn.getAttribute('data-niche');
        userNicheOverride = true;
        mineViralClips();
        renderSidebar();
        renderTriggerButton();
      });
    });

    // 4. Seleção Rápida de Duração (30s, 60s, 90s)
    document.querySelectorAll('.btn-quick-duration').forEach(btn => {
      btn.addEventListener('click', () => {
        maxDuration = parseInt(btn.getAttribute('data-duration'), 10);
        mineViralClips();
        renderSidebar();
        renderTriggerButton();
      });
    });

    // 5. Pular Player do YouTube para o segundo exato
    document.querySelectorAll('[data-seek-seconds]').forEach(btn => {
      btn.addEventListener('click', () => {
        const sec = parseInt(btn.getAttribute('data-seek-seconds'), 10);
        seekYouTubePlayer(sec);
        btn.innerHTML = '<span>✅ Pulou no Vídeo!</span>';
        setTimeout(() => { btn.innerHTML = '<span>▶️ Pular Player Aqui</span>'; }, 2000);
      });
    });

    // 6. Copiar Título, Copy e Hashtags
    document.querySelectorAll('[data-copy-copy]').forEach(btn => {
      btn.addEventListener('click', () => {
        const clipId = btn.getAttribute('data-copy-copy');
        const clip = videoData.clips.find(c => c.id === clipId);
        if (clip) {
          navigator.clipboard.writeText(clip.copyForSocial).then(() => {
            btn.innerHTML = '<span>✅ Pacote Copiado com Sucesso!</span>';
            setTimeout(() => { btn.innerHTML = '<span>📋 Copiar Título + Copy + Hashtags p/ TikTok/Shorts</span>'; }, 2000);
          });
        }
      });
    });

    // 7. Baixar Trecho do Corte
    document.querySelectorAll('[data-download-clip]').forEach(btn => {
      btn.addEventListener('click', () => {
        const clipId = btn.getAttribute('data-download-clip');
        const clip = videoData.clips.find(c => c.id === clipId);
        if (clip) {
          downloadClipPackage(clip);
          btn.innerHTML = '<span>✅ Baixando...</span>';
          setTimeout(() => { btn.innerHTML = '<span>📥 Baixar Trecho</span>'; }, 2000);
        }
      });
    });

    // 8. Busca Dinâmica no Radar
    const searchBtn = document.getElementById('radar-search-btn');
    const searchInput = document.getElementById('radar-search-input');
    const searchOrder = document.getElementById('radar-search-order');
    if (searchBtn && searchInput) {
      searchBtn.addEventListener('click', () => {
        const query = searchInput.value.trim();
        if (!query) return;

        let sp = 'CAM%253D'; // mais visualizados
        if (searchOrder && searchOrder.value === 'today') sp = 'EgIIAg%253D%253D'; // últimas 24h
        if (searchOrder && searchOrder.value === 'week') sp = 'EgIIAw%253D%253D'; // semana

        const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}&sp=${sp}`;
        window.open(url, '_blank');
      });
    }
  }

  // Pula a reprodução do player oficial do YouTube
  function seekYouTubePlayer(seconds) {
    const video = document.querySelector('video');
    if (video) {
      video.currentTime = seconds;
      video.play().catch(() => {});
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  // Gera o download do pacote do corte
  function downloadClipPackage(clip) {
    const content = `=====================================================
DARKCUTS PRO - PACOTE DE CORTE VIRAL
=====================================================
Vídeo Original: ${videoData.title}
Canal: ${videoData.channel}
Link YouTube no Ponto: https://www.youtube.com/watch?v=${videoData.id}&t=${clip.startSec}s

-----------------------------------------------------
DETALHES DO CORTE SELECIONADO:
-----------------------------------------------------
Nicho: ${selectedNiche.toUpperCase()}
Score Viral: ${clip.score}/100 (${clip.type})
Início no Vídeo: ${clip.startFormatted} (${clip.startSec} segundos)
Fim no Vídeo: ${clip.endFormatted} (${clip.endSec} segundos)
Duração Exata: ${clip.durationFormatted}

-----------------------------------------------------
GANCHO INICIAL DE RETENÇÃO (PRIMEIROS 3 SEGUNDOS):
-----------------------------------------------------
${clip.hook}

-----------------------------------------------------
TÍTULO VIRAL SUGERIDO:
-----------------------------------------------------
${clip.titleSuggested}

-----------------------------------------------------
LEGENDA / COPY COMPLETA PARA TIKTOK, REELS & SHORTS:
-----------------------------------------------------
${clip.copyForSocial}
=====================================================
Instrução de Edição:
1. Abra seu editor (CapCut, Premiere ou Clipchamp).
2. Recorte de ${clip.startFormatted} até ${clip.endFormatted}.
3. Enquadre em 9:16 vertical e adicione legendas automáticas.
4. Poste com o título e copy acima!
=====================================================`;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const filename = `DarkCut_${clip.rank}_${selectedNiche.toUpperCase()}_${clip.startFormatted.replace(':', 'm')}s.txt`;

    try {
      if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ action: 'download', url, filename });
        return;
      }
    } catch (e) {}

    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  function toggleSidebar() {
    let bar = document.getElementById('darkcuts-sidebar');
    if (!bar) {
      if (isWatchPage()) {
        extractVideoDetails();
      } else {
        activeTab = 'tab-radar';
      }
      renderSidebar();
      bar = document.getElementById('darkcuts-sidebar');
      if (bar) bar.classList.add('active');
      return;
    }

    if (bar.classList.contains('active')) {
      bar.classList.remove('active');
    } else {
      if (isWatchPage()) {
        extractVideoDetails();
      } else {
        activeTab = 'tab-radar';
      }
      renderSidebar();
      bar.classList.add('active');
    }
  }

  // Monitor SPA do YouTube
  function checkYouTubeNavigation() {
    const currentUrl = window.location.href;
    const newId = extractYouTubeVideoId(currentUrl);

    // Garante que o botão flutuante NUNCA saia da tela
    if (!document.getElementById('darkcuts-trigger-btn')) {
      renderTriggerButton();
    }

    if (currentUrl !== lastUrl || (newId && newId !== currentVideoId)) {
      lastUrl = currentUrl;

      if (newId) {
        currentVideoId = newId;
        userNicheOverride = false; // reseta override para re-detectar automaticamente no novo vídeo

        // Aguarda carregar dados do player do YouTube
        setTimeout(() => {
          if (isWatchPage()) {
            extractVideoDetails();
            renderTriggerButton();
            const bar = document.getElementById('darkcuts-sidebar');
            if (bar && bar.classList.contains('active')) {
              renderSidebar();
            }
          }
        }, 700);

        // Segundo passe para garantir que a duração do vídeo foi carregada
        setTimeout(() => {
          if (isWatchPage()) {
            extractVideoDetails();
            renderTriggerButton();
            const bar = document.getElementById('darkcuts-sidebar');
            if (bar && bar.classList.contains('active')) {
              renderSidebar();
            }
          }
        }, 2000);
      } else {
        currentVideoId = null;
        renderTriggerButton();
      }
    }
  }

  function init() {
    // 1. Renderiza o botão flutuante imediatamente na tela
    renderTriggerButton();

    // 2. Se já for página de vídeo, minera na hora
    if (isWatchPage()) {
      currentVideoId = extractYouTubeVideoId(window.location.href);
      extractVideoDetails();
      renderTriggerButton();

      // Segundo passe após 2s para dados completos do player
      setTimeout(() => {
        extractVideoDetails();
        renderTriggerButton();
      }, 2000);
    }

    // 3. Listeners de navegação nativos do YouTube (SPA)
    window.addEventListener('yt-navigate-finish', checkYouTubeNavigation);
    window.addEventListener('yt-page-data-updated', checkYouTubeNavigation);
    window.addEventListener('spfdone', checkYouTubeNavigation);
    window.addEventListener('popstate', checkYouTubeNavigation);
    window.addEventListener('load', checkYouTubeNavigation);

    // 4. Polling frequente para garantir persistência contínua
    setInterval(checkYouTubeNavigation, 600);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  setTimeout(init, 300);

})();
