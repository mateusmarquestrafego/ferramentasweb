document.addEventListener('DOMContentLoaded', () => {
  const hwidDisplay = document.getElementById('hwid-display');
  const copyHwidBtn = document.getElementById('copy-hwid-btn');

  function getHardwareFingerprint() {
    try {
      const raw = [
        screen.width + 'x' + screen.height,
        screen.colorDepth,
        navigator.hardwareConcurrency || 4,
        Intl.DateTimeFormat().resolvedOptions().timeZone
      ].join('###');

      let hash = 0;
      for (let i = 0; i < raw.length; i++) {
        hash = ((hash << 5) - hash) + raw.charCodeAt(i);
        hash |= 0;
      }
      return 'HWID_DC_' + Math.abs(hash).toString(16).toUpperCase();
    } catch (e) {
      return 'HWID_DC_CORE';
    }
  }

  const currentHwid = getHardwareFingerprint();
  if (hwidDisplay) hwidDisplay.textContent = currentHwid;

  if (copyHwidBtn) {
    copyHwidBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(currentHwid).then(() => {
        copyHwidBtn.textContent = 'Copiado!';
        setTimeout(() => { copyHwidBtn.textContent = 'Copiar'; }, 2000);
      });
    });
  }

  // Garante auto-ativação como Vitalício Founder
  chrome.storage.local.get(['darkcuts_is_pro'], (res) => {
    if (res.darkcuts_is_pro !== true) {
      chrome.storage.local.set({
        darkcuts_is_pro: true,
        darkcuts_plan: 'founder_vitalicio',
        darkcuts_license_key: 'DARKCUTS-VITALICIO-FOUNDER',
        darkcuts_hwid: currentHwid
      });
    }
  });
});
